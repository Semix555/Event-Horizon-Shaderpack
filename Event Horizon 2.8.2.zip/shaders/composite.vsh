#version 330 compatibility

/* ============================================================================
   composite.vsh  -  Event Horizon
   Fullscreen pass. Everything that is constant for the whole frame (light
   direction, light colour, horizon fade) is computed once per vertex and
   handed to the fragment shader as flat varyings.
   ============================================================================ */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/sky.glsl"

out vec2 texcoord;
flat out vec3  lightDirW;     // world-space direction TOWARDS the shadow light (sun by day, moon by night)
flat out vec3  lightColor;    // HDR colour of that light (already dimmed by rain)
flat out float horizonFade;   // 0 when the light touches the horizon, 1 above ~6 deg

void main() {
    gl_Position = ftransform();
    texcoord    = gl_MultiTexCoord0.xy;

    lightDirW   = lightDirWorld();
    lightColor  = directLightColor();
    // Iris swaps sun and moon as shadow light near the horizon. Fading to zero there
    // hides the swap, so there is no brightness pop at sunset or moonrise.
    horizonFade = smoothstep(0.0, 0.10, lightDirW.y);
}
