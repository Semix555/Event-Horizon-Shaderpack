#version 330 compatibility

/* ============================================================================
   composite3.fsh  -  Event Horizon: camera motion blur (option MOTION_BLUR)
   Every pixel is reprojected into the previous frame (previous matrices and camera position),
   the difference is the screen-space velocity. The scene is then averaged along that line.
   Moving and turning the camera both blur; the first-person hand stays sharp.
   The streak length is normalised to 60 fps, so it looks the same at 30 or 240 fps.
   The pass is skipped completely while the option is off (shaders.properties).
   ============================================================================ */

#include "/lib/settings.glsl"
#include "/lib/buffers.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4  gbufferPreviousModelView;
uniform mat4  gbufferPreviousProjection;
uniform vec3  previousCameraPosition;
uniform float frameTime;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

const float MB_MAX_LEN  = 0.06;   // longest streak, in screen heights
const float MB_DEADZONE = 1.0;    // streaks shorter than this many pixels are skipped (no shimmer when standing still)

void main() {
    ivec2 p      = ivec2(gl_FragCoord.xy);
    vec3  center = texelFetch(colortex0, p, 0).rgb;
    outColor = vec4(center, 1.0);

#ifdef MOTION_BLUR
    vec2  size = vec2(viewWidth, viewHeight);
    vec2  uv   = gl_FragCoord.xy / size;
    ivec2 pmax = ivec2(size) - 1;

    float d0 = texelFetch(depthtex0, p, 0).r;
    if (d0 < 0.56) return;                                            // hand

    // where was this surface point on the screen in the previous frame?
    vec3 feet     = viewToFeet(screenToView(uv, d0));
    vec3 prevFeet = feet + (cameraPosition - previousCameraPosition);
    vec4 prevClip = gbufferPreviousProjection * (gbufferPreviousModelView * vec4(prevFeet, 1.0));
    if (prevClip.w <= 0.0) return;
    vec2 vel = uv - (prevClip.xy / prevClip.w * 0.5 + 0.5);

    // half a frame of exposure, independent of the frame rate
    vel *= 0.5 * MB_STRENGTH * clamp((1.0 / 60.0) / max(frameTime, 1e-4), 0.25, 4.0);

    float len = length(vel * vec2(size.x / size.y, 1.0));             // in screen heights
    if (len * size.y < MB_DEADZONE) return;
    vel *= min(1.0, MB_MAX_LEN / len);

    float dither = ignAnimated(gl_FragCoord.xy);
    vec3  acc    = vec3(0.0);
    for (int i = 0; i < MB_SAMPLES; i++) {
        float t   = (float(i) + dither) / float(MB_SAMPLES) - 0.5;    // centred on the pixel
        vec2  suv = uv + vel * t;
        ivec2 sp  = clamp(ivec2(suv * size), ivec2(0), pmax);
        vec3  s   = texture(colortex0, suv).rgb;
        acc += (texelFetch(depthtex0, sp, 0).r < 0.56) ? center : s;  // never smear the hand into the world
    }
    outColor = vec4(acc / float(MB_SAMPLES), 1.0);
#endif
}
