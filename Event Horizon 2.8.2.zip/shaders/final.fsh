#version 330 compatibility

/* ============================================================================
   final.fsh  -  Event Horizon: bloom, tonemapping, colour grading
   Bloom needs no extra buffers: colortex0 gets a mip chain and the blurred levels are
   summed with a 4-tap filter per level (BLOOM_QUALITY = number of levels).
   ============================================================================ */

#include "/lib/settings.glsl"
#include "/lib/buffers.glsl"
#include "/lib/common.glsl"
#include "/lib/sky.glsl"

// Additional effects have their own passes (composite2 / 3 / 4) that are skipped while the effect is off.
// Naming the switches here, in a pass that always runs, keeps them listed in the settings menu.
#if defined(DEPTH_OF_FIELD) || defined(MOTION_BLUR) || defined(LENS_RAIN_DROPS)
#endif

// Tilt of the sun path = direction of the shadow light. The copy of this file in shaders/world1
// (the End) gets a steeper value from the build step, so the light - and with it the black hole -
// sits low over the horizon and the pillars cast long shadows.
const float sunPathRotation = -20.0;

#ifdef BLOOM
const bool colortex0MipmapEnabled = true;
#endif

uniform sampler2D colortex0;

layout(location = 0) out vec4 outColor;

#define BLOOM_LEVELS (BLOOM_QUALITY + 3)       // mips 2 .. (4 + quality)

vec3 bloomMips(vec2 uv) {
    vec3  sum  = vec3(0.0);
    float wsum = 0.0;
    for (int i = 0; i < BLOOM_LEVELS; i++) {
        float lod = float(i + 2);
        vec2  px  = exp2(lod) / vec2(viewWidth, viewHeight);   // one texel of this mip level in uv units
        vec3  s   = textureLod(colortex0, uv + px * vec2(-0.5, -0.5), lod).rgb
                  + textureLod(colortex0, uv + px * vec2( 0.5, -0.5), lod).rgb
                  + textureLod(colortex0, uv + px * vec2(-0.5,  0.5), lod).rgb
                  + textureLod(colortex0, uv + px * vec2( 0.5,  0.5), lod).rgb;
        float w = 1.0 / (1.0 + 0.5 * float(i));                // wide levels contribute a little less
        sum  += s * 0.25 * w;
        wsum += w;
    }
    return sum / wsum;
}

// Narkowicz ACES fit
vec3 acesFilm(vec3 x) {
    return saturate((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14));
}

void main() {
    vec2 uv = gl_FragCoord.xy / vec2(viewWidth, viewHeight);

    vec3 hdr;
#ifdef CHROMATIC_ABERRATION
    // Colour fringes only towards the screen edges: the offset grows with the CUBE of the distance
    // from the centre, so the middle of the screen (leaves, stars, zoomed-in views) stays clean
    // instead of splitting every contrast edge into red and blue pixels.
    vec2 cd = uv - 0.5;
    vec2 ca = cd * dot(cd, cd) * (0.008 * CHROMATIC_STRENGTH);
    hdr = vec3(textureLod(colortex0, uv + ca, 0.0).r,
               textureLod(colortex0, uv,      0.0).g,
               textureLod(colortex0, uv - ca, 0.0).b);
#else
    hdr = textureLod(colortex0, uv, 0.0).rgb;
#endif

#ifdef BLOOM
    vec3 bloom = bloomMips(uv);
    bloom *= smoothstep(0.35, 2.5, luma(bloom));               // favour real highlights over the average scene
    float bloomMul = 0.4 * BLOOM_INTENSITY;
#ifdef DIM_END
    bloomMul *= 1.0 + BH_GLOW;           // the black hole should glow
#endif
    hdr   += bloom * bloomMul;
#endif

    // exposure, brightened in caves and other places without sky light
    float exposure = 0.62 * EXPOSURE;
    float skyL     = float(eyeBrightnessSmooth.y) / 240.0;
    exposure *= hasSkylight ? mix(1.7, 1.0, smoothstep(0.0, 0.7, skyL)) : 1.0;
    exposure *= hasSkylight ? (1.0 + 0.15 * (1.0 - dayAmount()) * smoothstep(0.2, 0.8, skyL)) : 1.0;   // eyes adapt to the night

    vec3  col = acesFilm(hdr * exposure);
    float l   = luma(col);
    col = mix(vec3(l), col, SATURATION);

#ifdef VIGNETTE
    float v = length((uv - 0.5) * vec2(viewWidth / viewHeight, 1.0));
    col *= 1.0 - 0.35 * smoothstep(0.45, 1.05, v);
#endif

    col = toGamma(col);

#ifdef FILM_GRAIN
    col += (hash13(vec3(gl_FragCoord.xy, float(frameCounter % 128))) - 0.5) * 0.03;
#endif

    col += (ign(gl_FragCoord.xy) - 0.5) / 255.0;               // dither against banding
    outColor = vec4(col, 1.0);
}
