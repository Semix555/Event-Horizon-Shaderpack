#version 330 compatibility

/* ============================================================================
   gbuffers_entities.fsh  -  Event Horizon
   Used for: every mob, player, armor stand, item entity, boat, minecart ...
   Writes the G-buffer only; all lighting happens in the deferred/composite passes.

   Writes (same layout as gbuffers_textured):
     colortex0  RGB = linear albedo, A = coverage
     colortex1  RG = octahedral view-space normal, B = AO, A = material id / 4  (3 = particle id)
     colortex2  R = block light, G = sky light, B = emissive flag,
                A = 1.0  ENTITY FLAG  (particles write 0 here; composite.fsh uses it to give
                         entities their own lighting: soft wrap, clean sheen, no self-shadow acne)

   Hit flash: Iris does not draw the vanilla red overlay for shader packs; it hands the colour
   over as the uniform entityColor (rgb = overlay colour, a = strength, 0.3 for the red hurt
   flash, white and rising for a creeper about to blow). Without applying it in here, mobs never
   flash when they are hit.

   Required in shaders.properties, otherwise alpha blending corrupts the data buffers on
   semi-transparent entities (slime shell, ...):
     blend.gbuffers_entities.colortex1 = off
     blend.gbuffers_entities.colortex2 = off
   ============================================================================ */

#include "/lib/settings.glsl"
#include "/lib/buffers.glsl"
#include "/lib/common.glsl"

#define MAT_PARTICLE 3.0

// How strongly the hit flash shows. 1.0 = exactly the vanilla strength (about 30 % red).
#define HURT_FLASH_STRENGTH 1.0
// How much of the brightness the red tint takes away is given back (0 = none, 1 = all), so a
// hit mob turns reddish but does not turn dark.
#define HURT_KEEP_BRIGHTNESS 0.6

uniform sampler2D gtexture;
uniform vec4 entityColor;

in vec2 texcoord;
in vec2 lmcoord;   // 0..1, x = block light, y = sky light (remapped in the .vsh)
in vec4 glcolor;
in vec3 normal;    // view space
in vec3 viewPosV;  // view space

/* RENDERTARGETS: 0,1,2 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outNormal;
layout(location = 2) out vec4 outLight;

void main() {
    vec4 tex = texture(gtexture, texcoord) * glcolor;

    // Vanilla entity alpha cutoff
    if (tex.a < 0.1) discard;

    // ---- hit flash (done in gamma space BEFORE lighting, exactly like vanilla) --------------
    vec3  base  = tex.rgb;
    float flash = saturate(entityColor.a * HURT_FLASH_STRENGTH);
    vec3  col   = base;
    if (flash > 0.0) {
        col = mix(base, entityColor.rgb, flash);
        // The red mix removes green and blue and would darken the mob. Give part of that back,
        // but only when the mix actually got darker (the creeper's white flash must stay bright).
        float lumBase = luma(base);
        float lumMix  = luma(col);
        if (lumMix < lumBase) col *= mix(1.0, lumBase / max(lumMix, 1e-3), HURT_KEEP_BRIGHTNESS);
    }
    col = min(col, vec3(1.0));

    // Vanilla textures and vertex colours are gamma encoded -> linear for lighting
    vec3 albedo = toLinear(col);

    // ---- normal: make sure it faces the camera (thin double-sided parts show their back) -----
    // Independent of triangle winding: a visible flat face always has dot(n, toFragment) < 0.
    vec3 n = normalize(normal);
    if (dot(n, viewPosV) > 0.0) n = -n;

    // Full-bright parts (glowing eyes, glow squid, magma cube core) are submitted with
    // lightmap coordinates of 15/15. Flag them as emissive.
    float fullbright = smoothstep(0.97, 1.0, min(lmcoord.x, lmcoord.y));

    outColor  = vec4(albedo, tex.a);
    outNormal = vec4(octEncode(n), 1.0, MAT_PARTICLE / 4.0);
    outLight  = vec4(lmcoord, fullbright, 1.0);
}
