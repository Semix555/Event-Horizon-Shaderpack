#version 330 compatibility

/* ============================================================================
   gbuffers_water.fsh  -  Event Horizon
   Translucent terrain layer. Same G-buffer layout as the opaque passes.

   WATER (material id MAT_WATER, 2.0)
     colortex0  vec4(0)  -> fully transparent, the scene behind shows through untouched.
                            The composite pass shades the water (absorption, refraction,
                            foam, SSR) because it needs depthtex0 and depthtex1.
     colortex1  RG = octahedral view normal (with waves), B = tint.r, A = 2.0 / 4.0
     colortex2  R = block light, G = sky light, B = tint.g, A = tint.b
     tint = biome water colour, gamma encoded (decode with toLinear in the composite pass)

   GLASS / ICE / SLIME (material id MAT_TERRAIN)
     colortex0  untouched (alpha 0), the scene behind keeps its albedo
     colortex3  premultiplied glass colour + opacity, blended "over" (panes stack)
     colortex4  RG = octahedral view normal of the nearest pane, B = packed light levels, A = 1
     colortex1/2/5  untouched (alpha 0): opaque surface and water behind the glass stay readable
     colortex1  RG = normal, B = 1 (no AO), A = 1.0 / 4.0
     colortex2  R = block light, G = sky light, B = 0, A = 0

   shaders.properties needs (data buffers must be overwritten, not alpha blended):
     blend.gbuffers_water.colortex1 = off
     blend.gbuffers_water.colortex2 = off
     blend.gbuffers_water.colortex3 = ONE ONE_MINUS_SRC_ALPHA ONE ONE_MINUS_SRC_ALPHA
     blend.gbuffers_water.colortex4 = SRC_ALPHA ONE_MINUS_SRC_ALPHA SRC_ALPHA ONE_MINUS_SRC_ALPHA
     blend.gbuffers_water.colortex1/2/5 = SRC_ALPHA ONE_MINUS_SRC_ALPHA SRC_ALPHA ONE_MINUS_SRC_ALPHA
     separateAo = true
   ============================================================================ */

#include "/lib/settings.glsl"
#include "/lib/buffers.glsl"
#include "/lib/common.glsl"
#include "/lib/blocks.glsl"
#include "/lib/waves.glsl"

#ifndef ID_WATER
#define ID_WATER 10020
#endif

uniform sampler2D gtexture;

in vec2 texcoord;
in vec2 lmcoord;
in vec4 glcolor;
in vec3 normal;
in vec3 worldPos;
in float vertDist;
in vec3 vViewPos;
flat in int blockId;

/* RENDERTARGETS: 0,1,2,3,4,5 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outNormal;
layout(location = 2) out vec4 outLight;
layout(location = 3) out vec4 outGlass;     // glass layer: rgb = linear colour, a = opacity
layout(location = 4) out vec4 outGlassN;    // glass layer: rg = octahedral view normal, b = packed light levels, a = 1 (mask)
layout(location = 5) out vec4 outWaterZ;    // water surface: r = view distance along -z, a = 1

void main() {
    // View ray of this fragment (camera -> fragment), taken from the interpolated vertex
    // position: no per-pixel inverse projection needed, it is only used for the back-face test
    vec3 viewDir = normalize(vViewPos);

    vec3 n = normalize(normal);                  // geometric normal
    bool backFace = dot(n, viewDir) > 0.0;       // true when seen from below / inside

    // ------------------------------------------------------------------ water
    if (blockId == ID_WATER) {
#ifdef WATER_WAVES
        // World-space geometric normal decides what the surface does:
        //   flat / gently sloped (worldNormal.y high)  -> ocean waves
        //   steep faces, waterfalls, vertical flow     -> stretched, falling flow pattern
        // In between both are blended, so the ocean waves are damped on steep faces.
        vec3 nG = viewDirToWorld(n);
        if (nG.y > -0.3) {                                   // water seen from below keeps its flat normal
            float calm = smoothstep(0.55, 0.92, nG.y);
            vec3  nW   = nG;
    #ifdef WATERFALL_FLOW
            if (calm < 1.0) nW = flowNormal(worldPos, nG, frameTimeCounter * WAVE_SPEED, vertDist);
    #endif
            if (calm > 0.0) nW = normalize(mix(nW, waveNormal(worldPos.xz, vertDist), calm));
            n = normalize(mat3(gbufferModelView) * nW);
        }
#endif
        // Flip with the GEOMETRIC test so grazing wave normals never cause seams
        if (backFace) n = -n;

        vec3 tint = glcolor.rgb;   // biome water colour (gamma encoded)

        // Water writes alpha = 1 into colortex1 / 2 / 5, glass writes alpha = 0 (see below). With the
        // alpha blend set in shaders.properties that makes the water data survive a glass pane drawn
        // in front of it. Material "4 + colortex2.a = 1" means water (composite.fsh: readGBuffer),
        // block light is not stored for water (colortex2.r carries tint.b instead).
        outColor  = vec4(0.0);
        outGlass  = vec4(0.0);
        outGlassN = vec4(0.0);     // alpha 0 = the glass layer behind / in front of the water stays as it is
        outNormal = vec4(octEncode(n), tint.r, 1.0);
        outLight  = vec4(tint.b, lmcoord.y, tint.g, 1.0);
        outWaterZ = vec4(-vViewPos.z, 0.0, 0.0, 1.0);
        return;
    }

    // ------------------------------------------------- glass, ice, slime, ...
    vec4 tex = texture(gtexture, texcoord);
    if (tex.a < 0.02) discard;                   // fully clear texels (glass panes)

    if (backFace) n = -n;

    // colortex0 stays untouched (alpha 0): the opaque scene behind keeps its albedo, so composite.fsh can
    // shade it properly (sky, sun, shadows). The glass colour and opacity go to colortex3 instead.
    // The opaque G-buffer (colortex1 / 2) and a water surface behind the glass are left untouched:
    // alpha 0 + the alpha blend of shaders.properties = "keep what is there".
    // colortex3 is premultiplied and blended with "over" (shaders.properties): several panes stack, and a water
    // surface drawn later (alpha 0) leaves the layer alone, so a pane behind the water is not lost.
    vec2 lm = lmcoord;
    vec3 gcol = toLinear(tex.rgb * glcolor.rgb);
    if (blockId == ID_PORTAL) lm.x = 1.0;        // the portal glows: lit by full block light
    outColor  = vec4(0.0);
    outGlass  = vec4(gcol * tex.a, tex.a);
    // light levels are whole numbers 0..15: both fit in one channel (block * 16 + sky)
    outGlassN = vec4(octEncode(n), floor(lm.x * 15.0 + 0.5) * 16.0 + floor(lm.y * 15.0 + 0.5), 1.0);
    outNormal = vec4(0.0);
    outLight  = vec4(0.0);
    outWaterZ = vec4(0.0);
}
