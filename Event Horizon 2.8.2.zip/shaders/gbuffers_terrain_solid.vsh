#version 330 compatibility

/* ============================================================================
   gbuffers_terrain_solid.vsh  -  Event Horizon
   (solid blocks only: no foliage wind, see gbuffers_terrain.vsh for plants and leaves)
   Solid and cutout blocks: foliage wind, normal fix for plants, block id hand-off.

   shaders.properties needs:   separateAo = true
   (vertex colour = pure tint, ambient occlusion arrives in glcolor.a)

   Outputs to gbuffers_terrain.fsh:
     texcoord  atlas UV
     lmcoord   lightmap remapped to 0..1 (x = block light, y = sky light)
     glcolor   rgb = biome tint, a = ambient occlusion
     normal    view-space normal
     blockId   id from block.properties (see lib/blocks.glsl)
   ============================================================================ */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/blocks.glsl"

in vec4 mc_Entity;        // x = block id

out vec2 texcoord;
out vec2 lmcoord;
out vec4 glcolor;
out vec3 normal;
flat out int blockId;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

    // Vanilla lightmap UVs span [1/32, 31/32]; remap to a clean 0..1 range.
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    lmcoord = clamp((lmcoord - 0.03125) * 1.0666667, 0.0, 1.0);

    glcolor = gl_Color;
    blockId = int(mc_Entity.x + 0.5);   // unmapped blocks (-1) collapse to 0

    normal = normalize(gl_NormalMatrix * gl_Normal);

    bool plant   = (blockId == ID_PLANT);
    bool tallLow = (blockId == ID_TALL_LOWER);
    bool tallUp  = (blockId == ID_TALL_UPPER);
    bool leaves  = (blockId == ID_LEAVES);

    // Plants are lit as if facing up (soft top light, no dark back faces);
    // leaves get a 50 % blend so they keep some form shading.
    vec3 upView = normalize(gbufferModelView[1].xyz);
    if (plant || tallLow || tallUp) normal = upView;
    else if (leaves)                normal = normalize(mix(normal, upView, 0.5));

    vec3 feetPos = viewToFeet((gl_ModelViewMatrix * gl_Vertex).xyz);

    gl_Position = gl_ProjectionMatrix * (gbufferModelView * vec4(feetPos, 1.0));
}
