#version 330 compatibility

/* ============================================================================
   gbuffers_textured.vsh  -  Event Horizon
   Used for: particles (and whatever Iris routes to the "textured" program).

   Outputs to gbuffers_textured.fsh:
     texcoord  atlas UV
     lmcoord   vanilla lightmap remapped to 0..1  (x = block light, y = sky light)
     glcolor   vertex colour (particle tint, baked AO on other geometry)
     normal    view-space normal
   ============================================================================ */

uniform mat4 gbufferModelView;

out vec2 texcoord;
out vec2 lmcoord;
out vec4 glcolor;
out vec3 normal;

void main() {
    gl_Position = ftransform();

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

    // Vanilla lightmap UVs span [1/32, 31/32]. Remap to a clean 0..1 range so that
    // 0.0 = light level 0 and 1.0 = light level 15.
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    lmcoord = clamp((lmcoord - 0.03125) * 1.0666667, 0.0, 1.0);

    glcolor = gl_Color;

    // Particles are camera-facing billboards and carry no meaningful normal.
    // Using world "up" (expressed in view space) gives them natural top lighting
    // from the sun instead of flat, view-dependent shading.
    // gbufferModelView[1].xyz == mat3(gbufferModelView) * vec3(0.0, 1.0, 0.0)
    normal = normalize(gbufferModelView[1].xyz);
}
