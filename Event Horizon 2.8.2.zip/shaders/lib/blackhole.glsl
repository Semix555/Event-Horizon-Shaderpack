// ============================================================================
//  lib/blackhole.glsl  -  End sky with a raymarched Schwarzschild black hole
//  Requires settings.glsl + common.glsl (included first).
//  Entry point:  vec3 endSky(vec3 worldViewDir)  ->  linear HDR radiance
//
//  Dimension check: Iris loads shaders/world1/* only in the End, so a program that
//  lives in that folder IS the End check, no runtime test needed.
//
//  Options from settings.glsl: BLACK_HOLE (toggle), BH_STEPS (quality), BH_INTENSITY,
//  BH_DISK_COLOR_R/G/B, BH_HORIZON_SIZE, BH_DISK_TILT, BH_SPIN_SPEED,
//  BH_GLOW (bloom boost, see final.fsh).
//  Direction: the hole sits exactly where the shadow light is (lightDirWorld() from sky.glsl), so the
//  shadows of the pillars point away from it. Include sky.glsl before this file.
// ============================================================================
#ifndef BLACKHOLE_GLSL
#define BLACKHOLE_GLSL

// "OG End": the End sky of version 1.7. The nebula/aurora shells are switched off, which brings back the
// violet base colour and the violet/teal nebula that endBackground() keeps for the NEBULA-off case. The
// black hole, its disk and the stars are identical in both versions.
#ifdef OG_END
  #ifdef NEBULA
    #undef NEBULA
  #endif
#endif

// Requested names, mapped onto the options defined in settings.glsl
#define BLACK_HOLE_SIZE  BH_HORIZON_SIZE   // apparent size of the event horizon
#define DISK_BRIGHTNESS  BH_INTENSITY      // accretion disk brightness

// ---- scene constants, units: Schwarzschild radius Rs = 1 -----------------------------
#define BH_ISCO      3.0        // innermost stable orbit (3 Rs) = inner edge of the disk
#define BH_DISK_OUT  9.5        // outer edge of the disk
#define BH_B_CRIT    2.598076   // critical impact parameter 1.5*sqrt(3)*Rs: rays below it are captured

// ============================================================================
//  Background: nebula + aurora + stars (this is what gets bent by the lens)
// ============================================================================

// One layer of procedural stars. The direction sphere is scaled by `scale` and cut into unit
// cells; a cell may hold one star at a random position. The sphere slices each cell at a
// random depth, so stars come out in a natural mix of sizes and brightnesses.
vec3 starLayer(vec3 dir, float scale, float radius, float density, float brightness) {
    vec3 p    = dir * scale;
    vec3 cell = floor(p);
    vec3 f    = p - cell;
    if (hash13(cell) > density) return vec3(0.0);

    // star position kept inside [0.2, 0.8] so its disk never crosses the cell border
    vec3 sp = 0.2 + 0.6 * vec3(hash13(cell + 17.3), hash13(cell + 41.7), hash13(cell + 83.1));
    float s = 1.0 - smoothstep(0.0, radius, length(f - sp));
    s *= s;

    float h = hash13(cell + 5.9);
    vec3 tint = mix(vec3(0.65, 0.78, 1.0), vec3(1.0, 0.82, 0.62), hash13(cell + 9.1));
    float twinkle = 0.8 + 0.2 * sin(frameTimeCounter * (1.5 + 2.0 * h) + h * 60.0);
    return tint * s * brightness * (0.3 + 1.7 * h * h * h) * twinkle;
}

// ============================================================================
//  Cosmic nebula + aurora: 2-3 spherical shells with parallax
//  Options: NEBULA, NEBULA_LAYERS, NEBULA_INTENSITY, NEBULA_SPEED, NEBULA_BH_MASK
//
//  Every shell is a "UV map" of the view direction:  u = azimuth angle (phi), v = height (dir.y).
//  The noise is not sampled at atan(z,x) directly but on a CIRCLE (cos phi, sin phi) around the
//  vertical axis, so there is never a seam where the azimuth wraps around.
//  Curtain look = horizontal coordinate shifted by sines of height and time:
//        phi += sin(v * freq + u_time * speed) * intensity
//  Parallax: shell i sits at distance R_i, so a camera move c shifts its direction by c / R_i.
//  Each shell also rotates at its own speed, so the layers slide against each other.
// ============================================================================
#ifdef NEBULA
#define u_time (frameTimeCounter * NEBULA_SPEED)

// Gold of the gas streams, nudged towards the accretion disk colour so both belong together
vec3 nebulaGold() {
    vec3 disk = vec3(BH_DISK_COLOR_R, BH_DISK_COLOR_G, BH_DISK_COLOR_B);
    return mix(vec3(1.00, 0.72, 0.22), disk, 0.35);
}

// Gradient map: deep cosmic blue -> cyan -> emerald -> gold. Every shell samples its own
// range of it (dust: blue/cyan, aurora: cyan..emerald with a golden lower fringe, gas: gold).
vec3 nebulaGradient(float x) {
    x = saturate(x);
    vec3 deep    = vec3(0.012, 0.045, 0.200);
    vec3 cyan    = vec3(0.020, 0.420, 0.600);
    vec3 emerald = vec3(0.030, 0.880, 0.420);
    vec3 c = mix(deep, cyan,    smoothstep(0.00, 0.35, x));
    c      = mix(c,    emerald, smoothstep(0.35, 0.68, x));
    c      = mix(c,    nebulaGold(), smoothstep(0.68, 1.00, x));
    return c;
}

// Parallax direction of a shell at distance 1/invR. The camera offset saturates (about 500
// blocks), so the direction never degenerates on far End islands.
vec3 nebulaShellDir(vec3 dir, float invR) {
    vec3 cam = vec3(cameraPosition.x, 0.5 * cameraPosition.y, cameraPosition.z);
    cam /= 1.0 + length(cam) / 500.0;
    return normalize(dir - cam * invR);
}

// 3D simplex noise on a cylinder: (phi, h) -> seamless. azFreq = features around the circle,
// hFreq = features along the height (small hFreq = tall streaks), z = scrolling offset.
float nebulaNoise(float phi, float h, float azFreq, float hFreq, float z) {
    return snoise(vec3(cos(phi) * azFreq, sin(phi) * azFreq, h * hFreq + z));
}

// ---- shell 0: far space dust, soft blue/cyan clouds, almost still ------------------------
vec3 nebulaDust(vec3 dir, float t) {
    vec3  d   = nebulaShellDir(dir, 0.00006);
    float phi = atan(d.z, d.x) + t * 0.002;
    float h   = d.y;
    phi += 0.12 * sin(h * 3.0 + t * 0.05);                       // gentle shear

    float n1 = nebulaNoise(phi, h, 0.9, 1.4, t * 0.010);
    float n2 = nebulaNoise(phi, h, 2.1, 2.9, 7.3 - t * 0.015);
    float dens = smoothstep(-0.2, 0.9, 0.65 * n1 + 0.35 * n2);
    dens *= dens;
    float band = exp(-sq((h - 0.05) * 1.5));                     // broad band around the horizon

    return nebulaGradient(0.10 + 0.30 * dens + 0.06 * n2) * (dens * band * 0.20);
}

// ---- shell 1: aurora curtains, emerald with a golden lower fringe -------------------------
vec3 nebulaAurora(vec3 dir, float t) {
    vec3  d   = nebulaShellDir(dir, 0.0003);
    float phi = atan(d.z, d.x) + t * 0.005;
    float h   = d.y;

    // slow large-scale warp decides where the lower edge of the curtain runs
    float warp = nebulaNoise(phi, h, 0.7, 0.9, 20.0 + t * 0.020);

    // curtain folds: sine of height + time shifts the horizontal coordinate
    phi += 0.35 * sin(h * 5.0 + t * 0.28)
         + 0.14 * sin(h * 11.0 - t * 0.47 + 2.0 * phi)
         + 0.30 * warp;

    // rays: narrow in azimuth, tall in height = vertical bands; plus a fine striation
    float ray  = nebulaNoise(phi, h, 3.4, 0.55, t * 0.035);
    float rays = pow(saturate(0.5 + 0.5 * ray), 2.2);
    float fine = 0.65 + 0.35 * nebulaNoise(phi, h, 9.0, 1.2, 4.0 - t * 0.050);

    // vertical profile: crisp lower edge, long fade upwards
    float base    = 0.05 + 0.12 * warp;
    float lower   = smoothstep(base - 0.02, base + 0.07, h);
    float upper   = exp(-max(h - base, 0.0) * 2.6);
    float curtain = rays * fine * lower * upper;

    float hh = saturate((h - base) * 1.8);
    float x  = mix(0.88, 0.28, smoothstep(0.0, 1.0, hh)) + 0.08 * ray;
    return nebulaGradient(x) * (curtain * 0.40);
}

// ---- shell 2: golden gas streams, thin ridged filaments flowing diagonally ---------------
vec3 nebulaGas(vec3 dir, float t) {
    vec3  d   = nebulaShellDir(dir, 0.0009);
    float phi = atan(d.z, d.x) - t * 0.009;
    float h   = d.y;

    phi += 0.9 * h + 0.28 * sin(h * 4.0 + t * 0.22)
         + 0.20 * sin(2.0 * phi + h * 6.0 - t * 0.35);

    float w = nebulaNoise(phi, h, 1.1, 1.1, 40.0 + t * 0.020);
    float r1 = 1.0 - abs(nebulaNoise(phi + 0.3 * w, h, 1.6, 1.6, t * 0.030));
    float r2 = 1.0 - abs(nebulaNoise(phi, h, 3.6, 3.6, 13.0 - t * 0.045));
    float veins = pow(saturate(r1), 7.0) + 0.5 * pow(saturate(r2), 9.0);
    float haze  = smoothstep(-0.1, 0.8, w);
    float dens  = veins * (0.25 + 0.75 * haze);

    return nebulaGradient(0.66 + 0.34 * saturate(veins)) * (dens * 0.26);
}

// All shells together (before the black hole mask)
vec3 endNebula(vec3 dir) {
    float t = u_time;
    vec3 col = nebulaDust(dir, t);
    col += nebulaAurora(dir, t);
#if NEBULA_LAYERS >= 3
    col += nebulaGas(dir, t);
#endif
    return col * NEBULA_INTENSITY;
}

// ---- focus protection -----------------------------------------------------------------------
// Distance of the pixel to the black hole IN SCREEN SPACE (both directions projected with the real
// view/projection matrices, in units of screen height, aspect corrected). 0 at the horizon,
// fades the nebula in with smoothstep between 0.9 and NEBULA_BH_MASK shadow radii.
float nebulaFocusMask(vec3 dirPix, vec3 dirHole, float shadowAngle) {
    vec3 vp = mat3(gbufferModelView) * dirPix;
    vec3 vh = mat3(gbufferModelView) * dirHole;
    if (vp.z > -1e-3 || vh.z > -1e-3) return 1.0;                 // hole behind the camera

    vec2 proj = vec2(gbufferProjection[0][0], gbufferProjection[1][1]);
    vec2 sp = vp.xy / -vp.z * proj;                               // NDC
    vec2 sh = vh.xy / -vh.z * proj;
    float dist = length((sp - sh) * vec2(viewWidth / viewHeight, 1.0)) * 0.5;

    // apparent radius of the shadow in the same unit (screen heights)
    float rS = tan(shadowAngle) * 0.5 * gbufferProjection[1][1] / (-vh.z);
    float m = smoothstep(0.9 * rS, NEBULA_BH_MASK * rS, dist);
    return pow(m, 1.3);
}
#endif // NEBULA

// Undistorted End sky: nebula/aurora shells (or, with NEBULA off, the old violet nebula) + stars.
// nebulaMask = 0 hides the nebula (stars stay), used by the black hole focus protection.
vec3 endBackground(vec3 dir, float nebulaMask) {
    float t = frameTimeCounter;
#ifdef NEBULA
    // deep cosmic blue base instead of violet
    vec3 col = vec3(0.004, 0.010, 0.034) + vec3(0.004, 0.014, 0.030) * (0.5 + 0.5 * dir.y);
    if (nebulaMask > 0.002) col += endNebula(dir) * nebulaMask;
#else
    vec3 col = vec3(0.010, 0.005, 0.020) + vec3(0.016, 0.006, 0.030) * (0.5 + 0.5 * dir.y);

    float n1 = 0.5 + 0.5 * snoise(dir * 2.2 + vec3(0.0, t * 0.003, 0.0));
    float n2 = 0.5 + 0.5 * snoise(dir * 4.8 + 11.0);
    col += vec3(0.30, 0.09, 0.48) * pow(smoothstep(0.25, 0.95, n1), 2.2) * (0.35 + 0.65 * n2) * 0.30;
    col += vec3(0.04, 0.22, 0.20) * pow(smoothstep(0.45, 1.0, n2), 3.0) * n1 * 0.12;
#endif

    col += starLayer(dir,  62.0, 0.10, 0.60, 3.0);
    col += starLayer(dir, 130.0, 0.14, 0.50, 1.6);
    return col;
}
vec3 endBackground(vec3 dir) { return endBackground(dir, 1.0); }

#ifdef BLACK_HOLE
// ============================================================================
//  Black hole
// ============================================================================

struct BHFrame {
    vec3  d;    // unit direction from the viewer towards the hole
    vec3  n;    // accretion disk normal
    vec3  e1;   // in-plane axes (for the disk plasma coordinates)
    vec3  e2;
    float D;    // viewer distance from the hole in Rs (smaller = bigger on screen)
};

BHFrame bhFrame() {
    BHFrame f;
    f.d = lightDirWorld();     // same direction the shadow map is rendered from

    // "screen up" relative to the viewing axis
    vec3 upPerp = normalize(vec3(0.0, 1.0, 0.0) - f.d * f.d.y);

    // BH_DISK_TILT = angle between the line of sight and the disk plane.
    // 0 deg = edge-on, 90 deg = face-on. n leans away from d so the viewer sits ABOVE the
    // plane: the near rim of the disk appears below the hole, the lensed far side arcs over it.
    float tilt = radians(min(BH_DISK_TILT, 85.0));
    f.n  = normalize(-f.d * sin(tilt) + upPerp * cos(tilt));
    f.e1 = normalize(cross(f.n, f.d));
    f.e2 = cross(f.n, f.e1);

    // The size slider moves the viewer: closer = bigger horizon. Clamped so the viewer
    // always stays outside the disk's outer edge.
    f.D = clamp(30.0 / BLACK_HOLE_SIZE, 11.5, 70.0);
    return f;
}

// ----------------------------------------------------------------------------
//  Accretion disk emission at a point where a ray crosses the disk plane.
//  hit = point in the plane (hole at origin), rho = |hit|, rayDir = marching direction there.
//  Returns vec4(emitted HDR colour, opacity).
// ----------------------------------------------------------------------------
vec4 diskSample(vec3 hit, float rho, vec3 rayDir, BHFrame f, float t) {
    vec2 pl = vec2(dot(hit, f.e1), dot(hit, f.e2));          // in-plane coordinates

    // Keplerian differential rotation: omega ~ rho^-1.5, so inner gas laps outer gas and the
    // plasma noise gets sheared into spiral arms. We rotate the lookup coordinates by
    // -omega(rho) * t before sampling noise.
    float omega = 2.5 * BH_SPIN_SPEED * pow(rho, -1.5);
    float a  = omega * t;
    float ca = cos(a);
    float sa = sin(a);
    vec2  q  = mat2(ca, -sa, sa, ca) * pl;

    // animated plasma: three simplex octaves, each drifting in time at its own speed
    float n1 = snoise(vec3(q * 0.75,       t * 0.05));
    float n2 = snoise(vec3(q * 1.90 + 7.3, t * 0.09));
    float n3 = snoise(vec3(q * 4.60 - 3.1, t * 0.15));
    float plasma = clamp(0.5 + 0.5 * (0.55 * n1 + 0.30 * n2 + 0.15 * n3), 0.0, 1.0);
    plasma = pow(plasma, 1.3);
    float rings = 0.85 + 0.15 * sin(rho * 10.0 + 3.0 * n1);   // faint concentric banding

    // Thin-disk temperature profile T ~ rho^-0.75; brightness softened to ~T^2.5
    float temp = pow(BH_ISCO / rho, 0.75);
    float glow = pow(temp, 2.5) * 2.2;

    // Colour: user colour on the cool outer disk, white-hot near the inner edge
    vec3 userCol = vec3(BH_DISK_COLOR_R, BH_DISK_COLOR_G, BH_DISK_COLOR_B);
    vec3 hotCol  = mix(userCol, vec3(1.0, 0.94, 0.85), 0.7);
    vec3 col     = mix(userCol, hotCol, smoothstep(0.5, 1.0, temp));

    // Relativistic Doppler beaming + gravitational redshift.
    // Gas orbits at v = sqrt(Rs / (2 (rho - Rs))) in units of c (0.5 c at the ISCO).
    // rayDir is the BACKWARD-traced direction, so the photon travels along -rayDir to the viewer.
    vec3  radial = hit / rho;
    vec3  tang   = normalize(cross(f.n, radial));             // orbital direction
    float vOrb   = sqrt(0.5 / max(rho - 1.0, 0.5));
    float gam    = inversesqrt(1.0 - vOrb * vOrb);
    float cosA   = dot(tang, -rayDir);
    float delta  = 1.0 / (gam * (1.0 - vOrb * cosA));         // > 1 on the approaching side
    float grav   = sqrt(max(1.0 - 1.0 / rho, 0.01));          // gravitational redshift factor
    float shift  = clamp(delta * grav, 0.35, 2.4);
    col *= pow(vec3(shift), vec3(-0.55, 0.0, 0.7));           // blueshift / redshift tint
    float beam = pow(shift, 2.5);                             // beaming: bright side vs dim side

    float edge = smoothstep(BH_ISCO, BH_ISCO + 0.4, rho)
               * (1.0 - smoothstep(BH_DISK_OUT - 2.8, BH_DISK_OUT, rho));

    vec3  emit  = col * glow * beam * (0.35 + 1.25 * plasma) * rings * DISK_BRIGHTNESS * 1.9;
    float alpha = clamp(edge * (0.55 + 0.45 * plasma), 0.0, 0.96);
    return vec4(emit, alpha);
}

// ----------------------------------------------------------------------------
//  GRAVITATIONAL LENSING - how the raymarch works
//
//  Light follows null geodesics of the Schwarzschild metric. With u = 1/r and phi the angle
//  inside the orbital plane they obey
//        d2u/dphi2 + u = (3/2) Rs u^2
//  (the right-hand side is the relativistic correction; without it rays fly straight).
//
//  Binet's trick: a NEWTONIAN particle in a central force
//        a(x) = -(3/2) Rs h^2 x / |x|^5 ,    h = |x cross v|   (conserved)
//  traces exactly the same orbit shapes. So a light ray can be marched like an ordinary
//  particle:   v += a dt ;  x += v dt.   h equals the impact parameter b of the ray.
//
//  Checks:  weak field, a ray passing at distance b is deflected by 2 Rs / b
//           (integrate a over a straight line). Rays with b < 1.5 sqrt(3) Rs = BH_B_CRIT are
//           captured, rays just above it circle the photon sphere (r = 1.5 Rs) and form the
//           bright photon ring at the edge of the shadow.
//
//  Per pixel:
//   1. start at the viewer (-d * D) moving along the view ray,
//   2. each step: bend v towards the hole, advance, step length ~ radius (fine near the
//      hole, coarse far away; BH_STEPS also scales the step size for low quality presets),
//   3. every crossing of the disk plane samples the accretion disk (front-to-back blending,
//      so lensed secondary images of the disk appear automatically),
//   4. r < Rs: captured, black. Escape: the final direction samples the starfield, which is
//      what distorts the stars and creates the Einstein ring.
//
//  Far from the hole an analytic weak-field deflection replaces the march (cheap) and is
//  cross-faded in between so no seam is visible.
// ----------------------------------------------------------------------------
vec3 blackHoleSky(vec3 dir) {
    BHFrame f = bhFrame();
    float   t = frameTimeCounter;
    vec3 userCol = vec3(BH_DISK_COLOR_R, BH_DISK_COLOR_G, BH_DISK_COLOR_B);

    float cosT = dot(dir, f.d);                       // angle between pixel ray and the hole
    float sinT = sqrt(max(1.0 - cosT * cosT, 0.0));
    float b    = f.D * sinT;                          // impact parameter of the undeflected ray

    // w = 0: full raymarch (near the hole)   w = 1: analytic far field only
    float w = max(smoothstep(11.0, 16.0, b), 1.0 - smoothstep(-0.35, -0.10, cosT));

    // ---- far field: weak-field deflection, bends the ray towards the hole ---------------
    // First order for an observer at finite distance D (same force law as the march):
    //   alpha = (1 + cos(th) * (1 + sin^2(th) / 2)) / b
    // plus the approximate second-order term (15 pi / 16) / b^2, weighted by the path fraction.
    vec3 dirAna = dir;
    if (w > 0.0) {
        vec3  tang  = (f.d - dir * cosT) / max(sinT, 1e-4);   // unit tangent pointing at the hole
        float alpha = (1.0 + cosT * (1.0 + 0.5 * sinT * sinT)) / max(b, 1e-3)
                    + 0.5 * (1.0 + cosT) * 2.945 / max(b * b, 1e-3);
        alpha  = clamp(alpha, 0.0, 0.8);
        dirAna = normalize(dir * cos(alpha) + tang * sin(alpha));
    }

    // ---- near field: geodesic raymarch ---------------------------------------------------
    vec3  dirRay  = dir;
    vec3  glowCol = vec3(0.0);
    float trans   = 1.0;                              // transmittance through the disk layers

    if (w < 1.0) {
        vec3  pos  = -f.d * f.D;                      // viewer position, hole at the origin
        vec3  vel  = dir;
        float h    = length(cross(pos, vel));         // conserved angular momentum = b
        float h2   = h * h;
        float rEsc = f.D + 1.0;                       // beyond this, moving outward = escaped
        float qual = clamp(96.0 / float(BH_STEPS), 0.5, 3.5);
        bool  escaped = false;

        for (int i = 0; i < BH_STEPS; i++) {
            float r2 = dot(pos, pos);
            float r  = sqrt(r2);

            if (r < 1.0) break;                                       // inside the event horizon
            if (r > rEsc && dot(pos, vel) > 0.0) { escaped = true; break; }

            // step length ~ radius; dt compensates for the speed-up of v near the hole
            float stepLen = (0.05 + 0.08 * r) * qual;
            float dt      = stepLen / max(length(vel), 1e-3);

            // semi-implicit Euler: bend first, then move
            vel += (-1.5 * h2 / (r2 * r2 * r)) * pos * dt;            // Rs = 1
            vec3 prev = pos;
            pos += vel * dt;

            // accretion disk: did this step cross the disk plane?
            float s0 = dot(prev, f.n);
            float s1 = dot(pos,  f.n);
            if (s0 * s1 < 0.0 && trans > 0.01) {
                vec3  hit = mix(prev, pos, s0 / (s0 - s1));           // exact plane intersection
                float rho = length(hit);                              // hit lies in the plane
                if (rho > BH_ISCO && rho < BH_DISK_OUT) {
                    vec4 dk = diskSample(hit, rho, normalize(vel), f, t);
                    glowCol += trans * dk.a * dk.rgb;                 // front-to-back blending
                    trans   *= 1.0 - dk.a;
                }
            }
        }

        // budget used up far from the hole while moving outward: treat as escaped
        if (!escaped && dot(pos, pos) > 36.0 && dot(pos, vel) > 0.0) escaped = true;

        if (escaped) {
            vec3 vh = normalize(vel);

            // weak-field deflection still to come beyond the escape radius
            float rr   = length(pos);
            float aRem = (1.0 - sqrt(max(1.0 - h2 / (rr * rr), 0.0))) / max(h, 1e-3);
            vec3  perp = -(pos - vh * dot(pos, vh));                  // towards the hole
            perp = perp / max(length(perp), 1e-4);
            dirRay = normalize(vh * cos(aRem) + perp * sin(aRem));

            // photon ring: rays skimming the photon sphere pile up just outside the shadow
            vec3 ringCol = mix(userCol, vec3(1.0), 0.6);
            glowCol += trans * ringCol * exp(-max(h - BH_B_CRIT, 0.0) * 12.0) * 0.80 * DISK_BRIGHTNESS;
        } else {
            trans = 0.0;                                              // captured: black shadow
        }
    }

    // cross-fade between the marched and the analytic result
    vec3 dirFinal = normalize(mix(dirRay, dirAna, w));
    glowCol *= 1.0 - w;
    trans    = mix(trans, 1.0, w);

    // corona: a soft glow around the whole object (outside the shadow only) that blooms strongly
    float angH = acos(clamp(cosT, -1.0, 1.0));
    float Rapp = asin(min(BH_B_CRIT / f.D, 0.95));           // apparent radius of the shadow
    float xs   = max(angH - Rapp, 0.0) / max(Rapp, 1e-3);    // distance from its edge in shadow radii
    vec3 coronaCol = mix(userCol, vec3(1.0, 0.92, 0.75), 0.35);
    vec3 corona = coronaCol * (exp(-xs * 2.4) * 0.60 + exp(-xs * 0.55) * 0.12) * DISK_BRIGHTNESS
                * smoothstep(0.95 * Rapp, 1.04 * Rapp, angH);

    // nebula is faded out around the hole (screen space), the lensed stars stay
    float nebMask = 1.0;
#ifdef NEBULA
    nebMask = nebulaFocusMask(dir, f.d, Rapp);
#endif
    return glowCol + corona + endBackground(dirFinal, nebMask) * trans;
}
#endif // BLACK_HOLE

// Final End sky. With BLACK_HOLE disabled only the plain starfield + nebula is evaluated.
vec3 endSky(vec3 dir) {
#ifdef BLACK_HOLE
    return blackHoleSky(dir);
#else
    return endBackground(dir);
#endif
}
#endif
