// ============================================================================
//  lib/blocks.glsl  -  block / material ids + foliage wind
//  Requires settings.glsl + common.glsl first (uses frameTimeCounter, rainStrength).
//  The three options below are picked up by Iris and shown in the settings menu.
// ============================================================================
#define WAVING_FOLIAGE
#define WIND_STRENGTH 1.0   // [0.25 0.5 0.75 1.0 1.5 2.0]
#define WIND_SPEED 1.0      // [0.5 1.0 1.5 2.0]

#ifndef BLOCKS_GLSL
#define BLOCKS_GLSL

// Block ids delivered in mc_Entity.x (assigned in block.properties)
#define ID_PLANT        10001   // single plants: grass, ferns, flowers, crops, saplings ...
#define ID_LEAVES       10002   // all leaves
#define ID_EMISSIVE     10003   // torch, lantern, glowstone, sea lantern, shroomlight, lit lamps ...
#define ID_HOT          10004   // lava, magma block, fire, campfire flames
#define ID_TALL_LOWER   10005   // lower half of double plants (tall grass, large fern, sunflower ...)
#define ID_TALL_UPPER   10006   // upper half of double plants
#define ID_ORE          10007   // stone / deepslate ores with coloured spots (glow in the dark)
#define ID_ORE_COAL     10008   // coal ores: dark spots glow white-grey
#define ID_ORE_NGOLD    10009   // nether gold ore
#define ID_ORE_QUARTZ   10010   // nether quartz ore
#define ID_REFL_METAL   10011   // iron / gold / diamond / netherite / emerald blocks, iron doors ...
#define ID_REFL_QUARTZ  10012   // quartz blocks (polished, white Fresnel)
#define ID_REFL_COPPER  10013   // waxed, unoxidised copper (faint)
#define ID_REFL_OBSIDIAN 10014  // obsidian: glassy, dark, gentle reflection
#define ID_STEM_CRIMSON 10016   // crimson stem / hyphae: veins glow faintly red
#define ID_STEM_WARPED  10017   // warped stem / hyphae: veins glow faintly turquoise
#define ID_LAMP         10015   // full-block lamps (glowstone, sea lantern, froglights ...): dimmable glow
#define ID_PORTAL       10019   // nether portal: purple shadow, glows in the glass layer
#define ID_GLASS_TINT   10018   // stained glass, stained panes, tinted glass: cast a coloured shadow (shadow.fsh)

// Material ids, stored as (id / 4) in colortex1.a
#define MAT_TERRAIN  1.0
#define MAT_WATER    2.0
#define MAT_PARTICLE 3.0
#define MAT_FOLIAGE  4.0
// Entities (mobs, players, armor stands ...) are stored with the particle id (3) plus the flag
// colortex2.a = 1.0. composite.fsh turns that pair into MAT_ENTITY when it reads the G-buffer;
// 5 is never written to colortex1 (id / 4 would not fit into the 0..1 range).
#define MAT_ENTITY   5.0

// Colour filter of a piece of glass: what fraction of each colour channel gets through.
// lin = linear glass colour, alpha = texture opacity, k = strength (1 = normal).
//   hue    = the glass colour with its brightest channel scaled to 1
//   bright = dark glass (black stained, tinted) lets much less light through than light glass
// Used for the shadow (shadow.fsh) and for looking through the glass (composite.fsh): same colour in both.
vec3 glassFilter(vec3 lin, float alpha, float k) {
    float mx     = max(lin.r, max(lin.g, lin.b));
    vec3  hue    = lin / max(mx, 1e-4);
    float bright = smoothstep(0.0, 0.30, mx);
    float tone   = mix(0.10, 0.90, bright);                 // light that gets through at most
    vec3  full   = tone * mix(vec3(1.0), hue, 0.85);        // keep a hint of white: no fully pure colour
    return mix(vec3(1.0), full, saturate(alpha * 1.3 * k));
}

// Horizontal sway offset in blocks for a vertex at world position p.
// amp = sway amplitude in blocks for a fully free vertex (weight 1).
vec2 windSway(vec3 p, float amp) {
    float t = frameTimeCounter * WIND_SPEED * (1.0 + 1.5 * rainStrength);  // storms blow faster
    const vec2 dir = vec2(0.8, 0.6);                                       // prevailing wind direction

    // slow gust front travelling along the wind direction
    float gust = 0.5 + 0.5 * sin(dot(p.xz, dir) * 0.35 - t * 1.1);

    // fast local flutter, phase-shifted per position so neighbours never move in lockstep
    float flutter = sin(dot(p, vec3(1.9, 1.3, 2.3)) + t * 3.3);

    // mostly downwind, plus a little cross-wind jitter
    vec2 d = dir * (0.35 + 0.65 * gust) + vec2(-dir.y, dir.x) * flutter * 0.25;

    return d * amp * WIND_STRENGTH * (1.0 + 1.5 * rainStrength);
}
#endif
