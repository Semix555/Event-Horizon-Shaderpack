// Render-target formats. Include ONLY from fragment shaders.
//
//  colortex0  RGBA16F  HDR scene colour (albedo before the deferred pass)
//  colortex1  RGBA16   rg = octahedral view normal, b = AO, a = material id / 4
//  colortex2  RGBA8    r = block light, g = sky light, b = emissive, a = 1 for entities (water: tint.b; terrain: block reflectivity)
//  colortex3  RGBA16F  glass layer: rgb = glass colour, a = opacity (gbuffers_water)
//  colortex4  RGBA16F  glass layer: rg = view normal, b = packed light levels, a = mask (gbuffers_water)
//  colortex5  RGBA16F  water surface distance (r) + mask (a), survives glass in front of it
//
// The declarations live INSIDE a block comment on purpose: Iris reads "const int
// colortexNFormat = ..." directives out of comments, while the GLSL compiler never sees
// them (RGBA16F and friends are not GLSL identifiers and would fail to compile).
/*
const int colortex0Format = RGBA16F;
const int colortex1Format = RGBA16;
const int colortex2Format = RGBA8;
const int colortex3Format = RGBA16F;
const int colortex4Format = RGBA16F;
const int colortex5Format = RGBA16F;
*/
