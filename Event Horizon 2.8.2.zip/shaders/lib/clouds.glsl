// ============================================================================
//  lib/clouds.glsl  -  volumetric clouds + cloud shadows
//  Requires settings.glsl, common.glsl and sky.glsl first.
//
//  One flat cloud slab [CLOUD_HEIGHT, CLOUD_HEIGHT + CLOUD_THICKNESS] above the world.
//  The SAME density function drives
//    - the cloud raymarch in the sky (cloudLayer)            lit by sun / moon + sky ambient
//    - the shadows on the ground and in the air (cloudShadow) so shadows and clouds always match
//  and rain pushes the coverage up, so storms close the sky.
//
//  Speed: the noise uses one sin() per lattice point instead of a long integer-style hash, the
//  number of steps is small, far clouds use fewer octaves and no billow detail, and the light
//  march uses a single cheap sample. Only OpenGL 3.3 features (fine on macOS, 4.1 core).
// ============================================================================
#ifndef CLOUDS_GLSL
#define CLOUDS_GLSL

#define CLOUD_BASE_Y   float(CLOUD_HEIGHT)
#define CLOUD_THICK    float(CLOUD_THICKNESS)
#define CLOUD_EXT      0.07                  // extinction per block and unit density
#define CLOUD_FAR      5000.0                // clouds melt into the haze beyond this distance
#define CLOUD_STEPS    (3 + 3 * CLOUD_QUALITY)   // 6 / 9 / 12 / 15 marching steps

// ---- cheap value noise (no textures needed) -------------------------------------------------
// Sin-free integer-lattice hash (Dave Hoskins): only fract / multiply-add, no transcendental
// functions. The old fract(sin(dot(...)) * 43758.5453) cost one sin per lattice point and loses
// precision for large sine arguments on some GPU / fast-math combinations.
// mod() keeps the lattice coordinates small; the noise simply repeats after 512 cells, which is
// far beyond what is ever visible.
float chash2(vec2 p) {
    p = mod(p, 512.0);
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}
float chash3(vec3 p) {
    p = mod(p, 512.0);
    vec3 p3 = fract(p * 0.1031);
    p3 += dot(p3, p3.zyx + 31.32);
    return fract((p3.x + p3.y) * p3.z);
}
float cvn2(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = chash2(i);
    float b = chash2(i + vec2(1.0, 0.0));
    float c = chash2(i + vec2(0.0, 1.0));
    float d = chash2(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}
float cvn3(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = chash3(i);
    float b = chash3(i + vec3(1.0, 0.0, 0.0));
    float c = chash3(i + vec3(0.0, 1.0, 0.0));
    float d = chash3(i + vec3(1.0, 1.0, 0.0));
    float e = chash3(i + vec3(0.0, 0.0, 1.0));
    float g = chash3(i + vec3(1.0, 0.0, 1.0));
    float h = chash3(i + vec3(0.0, 1.0, 1.0));
    float k = chash3(i + vec3(1.0, 1.0, 1.0));
    return mix(mix(mix(a, b, f.x), mix(c, d, f.x), f.y),
               mix(mix(e, g, f.x), mix(h, k, f.x), f.y), f.z);
}

vec2 cloudWind() { return vec2(1.0, 0.30) * (frameTimeCounter * CLOUD_SPEED * 2.5); }

// ---- density -----------------------------------------------------------------------------------
// Large-scale cloud map: 0 = clear sky, 1 = full cloud. Depends only on the horizontal position.
// Single clouds are roughly 200-400 blocks across (CLOUD_SCALE stretches them) with clear sky
// in between; the coverage setting decides how many of them there are.
float cloudShape(vec2 xz, int octaves) {
    float cov = saturate(CLOUD_COVERAGE + 0.40 * rainStrength);
    if (cov < 0.005) return 0.0;
    vec2 q = (xz + cloudWind()) * (0.006 / CLOUD_SCALE);
    const mat2 rot = mat2(0.80, -0.60, 0.60, 0.80);
    float n = 0.0;
    float a = 0.5;
    float norm = 0.0;
    for (int i = 0; i < 4; i++) {
        if (i >= octaves) break;
        n    += a * cvn2(q);
        norm += a;
        q = rot * q * 2.03 + 17.3;
        a *= 0.5;
    }
    n /= norm;
    float th = mix(0.80, 0.28, cov);                  // coverage lowers the threshold
    return smoothstep(th, th + 0.08, n) * smoothstep(0.0, 0.08, cov);   // short ramp: solid, not wispy
}

// Cloud density at world position p. detailW (0..1) blends in the billow noise that erodes the edges;
// 0 gives the average erosion, so shadows and far clouds match the detailed sky clouds on average.
float cloudDensityAt(vec3 p, int shapeOctaves, float detailW) {
    float h01 = (p.y - CLOUD_BASE_Y) / CLOUD_THICK;
    if (h01 <= 0.0 || h01 >= 1.0) return 0.0;
    float shape = cloudShape(p.xz, shapeOctaves);
    if (shape <= 0.0) return 0.0;

    // flat bottom, rounded top; strong coverage grows taller clouds
    float ht   = mix(0.40, 1.0, shape);
    float prof = smoothstep(0.0, 0.10, h01) * (1.0 - smoothstep(ht * 0.5, ht, h01));
    float d = shape * prof;

    float det = 0.5;                                          // the average
    if (detailW > 0.0) {
        vec2 w = cloudWind();
        vec3 q = (p + vec3(w.x, 0.0, w.y)) * (0.035 / CLOUD_SCALE);
        det = mix(0.5, 0.65 * cvn3(q) + 0.35 * cvn2(q.xz * 2.7 + q.y * 1.3), detailW);
    }
    d = saturate(d * 1.8 - (1.0 - det) * 0.60);
    return d * CLOUD_DENSITY;
}

// ---- lighting helpers ----------------------------------------------------------------------
// Cloud scattering phase: strong forward lobe (silver lining) + weak back lobe, isotropic = 1.
float cloudPhase(float c) {
    float g1 = 0.60;
    float g2 = -0.20;
    float p1 = (1.0 - g1 * g1) / pow(max(1.0 + g1 * g1 - 2.0 * g1 * c, 1e-3), 1.5);
    float p2 = (1.0 - g2 * g2) / pow(max(1.0 + g2 * g2 - 2.0 * g2 * c, 1e-3), 1.5);
    return mix(p2, p1, 0.3);
}

// Sunlight reaching the clouds. Clouds sit high above the ground, so they keep glowing red and
// pink for a while after the sun has dipped below the horizon (afterglow).
vec3 cloudSunColor(float h) {
    vec3 cHor  = vec3(1.00, 0.22, 0.08);
    vec3 cLow  = vec3(1.00, 0.52, 0.22);
    vec3 cHigh = vec3(1.00, 0.97, 0.92);                // white clouds at noon
    vec3 c = mix(cHor, cLow, smoothstep(-0.04, 0.10, h));
    c = mix(c, cHigh, smoothstep(0.08, 0.45, h));
    float afterglow = smoothstep(-0.17, 0.0, h);
    float atmosphere = mix(0.55, 1.0, smoothstep(0.0, 0.30, h));
    return c * (1.4 * SUN_INTENSITY * atmosphere * afterglow);
}
// Moonlight: fades in while the sun's afterglow fades out (no pop when the light switches over)
vec3 cloudMoonColor(float h) {
    return vec3(0.62, 0.66, 0.76) * (0.30 * NIGHT_BRIGHTNESS * (1.0 - smoothstep(-0.30, -0.17, h)));
}
vec3 cloudAmbientColor() {
    float h = sunDirWorld().y;
    float day = smoothstep(-0.18, 0.10, h);
    // bright white-blue sky light, so the undersides stay light; rain turns the clouds dark grey
    vec3 a = mix(skyHorizon(), vec3(1.0), 0.45) * 1.35;
    // twilight: undersides pick up the rose / violet of the sky
    a = mix(a, vec3(0.55, 0.30, 0.50) * 0.8, saturate(0.45 * twilightAmount() * SUNSET_INTENSITY));
    return a * mix(min(0.08 * NIGHT_BRIGHTNESS, 0.4), 0.95, day) * mix(1.0, 0.30, rainStrength);
}

// ---- sky clouds ---------------------------------------------------------------------------------
// Returns vec4(in-scattered light, transmittance) for world-space view direction `dir`. Use:
//     sky * result.a + result.rgb
//
// Two ways to draw a cloud, blended smoothly by distance:
//  - NEAR (up to ~500 blocks): raymarch through the slab with real self-shadowing. The step length
//    is capped, so cloud structures are never skipped; the jitter pattern is fixed (no flicker).
//  - FAR: ONE sample of the cloud map per pixel, drawn as a thin lit layer. A single sample cannot
//    alias against a step length, so distant clouds are rock steady and cheap. Water and puddle
//    reflections (`fast`) use this path too.
vec4 cloudLayer(vec3 dir, float dither, bool fast) {
#ifdef CLOUDS
    if (abs(dir.y) < 0.0008) return vec4(0.0, 0.0, 0.0, 1.0);
    if (saturate(CLOUD_COVERAGE + 0.40 * rainStrength) < 0.005) return vec4(0.0, 0.0, 0.0, 1.0);

    float t0 = (CLOUD_BASE_Y - cameraPosition.y) / dir.y;
    float t1 = (CLOUD_BASE_Y + CLOUD_THICK - cameraPosition.y) / dir.y;
    float tmin = max(min(t0, t1), 0.0);
    float tmax = max(t0, t1);
    if (tmax <= 0.0 || tmin > CLOUD_FAR) return vec4(0.0, 0.0, 0.0, 1.0);
    float fullPath = tmax - tmin;                              // length of the ray inside the slab

    // light source: the sun while it still lights the clouds (also just below the horizon), else the moon
    vec3 sd = sunDirWorld();
    bool useSun = sd.y > -0.17;
    vec3 L = useSun ? sd : moonDirWorld();
    vec3 lightCol = (useSun ? cloudSunColor(sd.y) : cloudMoonColor(sd.y))
                  * ((1.0 - 0.75 * rainStrength) * CLOUD_BRIGHTNESS);
    vec3 ambCol = cloudAmbientColor() * CLOUD_BRIGHTNESS;
    float phase = cloudPhase(dot(dir, L));

    float farW = fast ? 1.0 : smoothstep(500.0, 1100.0, tmin);

    float T = 1.0;
    vec3  S = vec3(0.0);

    // ---- near: volumetric march
    if (farW < 1.0) {
        float maxStep = 28.0 + tmin * 0.05;                    // longest allowed step
        int steps = max(2, min(CLOUD_STEPS, int(ceil(fullPath / maxStep))));
        float marchEnd = min(tmax, tmin + maxStep * float(steps));
        float stepLen  = (marchEnd - tmin) / float(steps);
        int lightSamples = (CLOUD_QUALITY < 4) ? 1 : 2;
        // low sun: look further along the light direction (the neighbouring clouds do the shading)
        float lightStep  = CLOUD_THICK * (0.35 + 1.2 * (1.0 - saturate(L.y * 3.0)));
        float dth = ign(gl_FragCoord.xy);                      // fixed pattern: nothing flickers

        for (int i = 0; i < steps; i++) {
            float t = tmin + (float(i) + dth) * stepLen;
            vec3  p = cameraPosition + dir * t;

            int   oct     = (t > 900.0) ? 3 : 4;
            float detailW = 1.0 - smoothstep(80.0, 350.0, t);  // billows fade out smoothly with distance
            float d = cloudDensityAt(p, oct, detailW);
            if (d < 0.004) continue;

            // optical depth towards the light (one cheap sample, two on the highest quality)
            float od = 0.0;
            for (int j = 1; j <= 2; j++) {
                if (j > lightSamples) break;
                od += cloudDensityAt(p + L * (lightStep * float(j)), 2, 0.0);
            }
            od *= (lightStep * 2.5 * CLOUD_EXT) / float(lightSamples);

            // Beer-Lambert plus a cheap multiple-scattering term keeps dense cores from going black
            float lightAtt = exp(-od) + 0.50 * exp(-od * 0.22);

            float h01 = saturate((p.y - CLOUD_BASE_Y) / CLOUD_THICK);
            float ambAtt = mix(0.65, 1.0, h01) * mix(1.0, exp(-d * 0.5), 0.5);   // light underside, softly shaded core

            vec3  src = lightCol * (lightAtt * phase) + ambCol * ambAtt;
            float sT  = exp(-d * CLOUD_EXT * stepLen);
            S += T * (1.0 - sT) * src;
            T *= sT;
            if (T < 0.05) break;
        }
    }

    // ---- far: one sample of the cloud map, soft coverage -> opacity
    if (farW > 0.0) {
        vec3 pm = cameraPosition + dir * (0.5 * (tmin + tmax));
        float shape = cloudShape(pm.xz, tmin < 1500.0 ? 3 : 2);
        float cover = smoothstep(0.02, 0.45, saturate(shape * 1.2 - 0.30) * CLOUD_DENSITY);
        float Tp = 1.0 - 0.98 * cover;
        vec3  Sp = (lightCol * (phase * mix(1.0, 0.5, cover * cover)) + ambCol * 0.85) * (1.0 - Tp);
        S = mix(S, Sp, farW);
        T = mix(T, Tp, farW);
    }

    // aerial perspective: only the farthest clouds dissolve into the haze at the horizon
    float haze = max(1.0 - exp(-tmin * 0.00012), smoothstep(0.6 * CLOUD_FAR, CLOUD_FAR, tmin));
    S *= 1.0 - haze;
    T = mix(T, 1.0, haze);
    return vec4(S, T);
#else
    return vec4(0.0, 0.0, 0.0, 1.0);
#endif
}

// ---- cloud shadows ---------------------------------------------------------------------------------
// Fraction of the direct light that survives the clouds at world position wp (1 = full sun).
// L is the direction towards the light. `fast` = one sample (used inside the god-ray march).
float cloudShadow(vec3 wp, vec3 L, bool fast) {
#if defined(CLOUDS) && defined(CLOUD_SHADOWS)
    float fadeL = smoothstep(0.02, 0.10, L.y);
    if (fadeL <= 0.0 || wp.y >= CLOUD_BASE_Y + CLOUD_THICK) return 1.0;

    int n = fast ? 1 : 2;
    float sum = 0.0;
    for (int i = 0; i < 2; i++) {
        if (i >= n) break;
        float hf = fast ? 0.45 : (0.3 + 0.4 * float(i));     // heights inside the slab: 0.3 / 0.7
        float y  = CLOUD_BASE_Y + CLOUD_THICK * hf;
        float t  = (y - wp.y) / L.y;
        if (t < 0.0) continue;
        sum += cloudDensityAt(wp + L * t, 2, 0.0);
    }
    float seg = CLOUD_THICK / (float(n) * max(L.y, 0.25));
    float T = exp(-sum * seg * CLOUD_EXT);
    return mix(1.0, T, CLOUD_SHADOW_STRENGTH * fadeL);
#else
    return 1.0;
#endif
}
#endif
