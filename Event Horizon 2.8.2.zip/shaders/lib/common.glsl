#ifndef COMMON_GLSL
#define COMMON_GLSL
// Shared uniforms, constants, noise, packing and space-conversion helpers.
// Requires "/lib/settings.glsl" to be included first.

#define PI  3.14159265359
#define TAU 6.28318530718

// ---- dimension flags -------------------------------------------------------------------
// In current Minecraft versions the End reports hasSkylight = true, so the End cannot be told
// apart from the Overworld with uniforms. The copies of all programs in shaders/world1/
// (Iris loads that folder only in the End) define DIM_END before including this file; there
// the flags become compile-time constants: no skylight, no ceiling = End.
#ifdef DIM_END
const bool hasSkylight = false;
const bool hasCeiling  = false;
#else
uniform bool hasSkylight;   // Overworld
uniform bool hasCeiling;    // Nether
#endif

// ---- quality macros derived from the options ---------------------------------------
#if PCF_QUALITY == 0
  #define PCF_TAPS 1
#elif PCF_QUALITY == 1
  #define PCF_TAPS 6
#elif PCF_QUALITY == 2
  #define PCF_TAPS 12
#else
  #define PCF_TAPS 24
#endif
#define WAVE_COUNT (WAVE_QUALITY + 1)      // number of summed swell waves: 2..5

// ---- uniforms ----------------------------------------------------------------------------
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;
uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform vec3 shadowLightPosition;
uniform vec3 fogColor;
uniform vec3 skyColor;
uniform float frameTimeCounter;
uniform int   frameCounter;
uniform int   moonPhase;       // 0 = full moon ... 4 = new moon
uniform float viewWidth;
uniform float viewHeight;
uniform float near;
uniform float far;
uniform float rainStrength;
uniform float wetness;
uniform float nightVision;
uniform int   isEyeInWater;
uniform int   heldBlockLightValue;
uniform int   heldBlockLightValue2;
uniform ivec2 eyeBrightnessSmooth;

// ---- small helpers ----------------------------------------------------------------------------
float saturate(float x) { return clamp(x, 0.0, 1.0); }
vec2  saturate(vec2 x)  { return clamp(x, 0.0, 1.0); }
vec3  saturate(vec3 x)  { return clamp(x, 0.0, 1.0); }
float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
float sq(float x) { return x * x; }
vec3 toLinear(vec3 c) { return pow(max(c, vec3(0.0)), vec3(2.2)); }
vec3 toGamma(vec3 c)  { return pow(max(c, vec3(0.0)), vec3(1.0 / 2.2)); }

// Interleaved gradient noise (Jimenez): cheap and well distributed, ideal for dithering
float ign(vec2 p) { return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }
float ignAnimated(vec2 p) { return ign(p + 5.588238 * float(frameCounter % 64)); }

float hash13(vec3 p3) {
    p3 = fract(p3 * 0.1031);
    p3 += dot(p3, p3.zyx + 31.32);
    return fract((p3.x + p3.y) * p3.z);
}

// Vogel (golden-angle) disk: i-th of n points, rotated by phi
vec2 vogelDisk(int i, int n, float phi) {
    float r  = sqrt((float(i) + 0.5) / float(n));
    float th = float(i) * 2.39996323 + phi;
    return r * vec2(cos(th), sin(th));
}

// Same Vogel disk, but walked incrementally: `dir` starts as (cos phi, sin phi) and is turned by the
// golden angle after every tap. That is one cos/sin per PIXEL instead of one per TAP (the original
// vogelDisk needs sin + cos for every sample). Call it with i = 0, 1, 2 ... in order.
#define GA_COS (-0.73736888)    // cos(2.39996323)
#define GA_SIN ( 0.67549029)    // sin(2.39996323)
vec2 vogelNext(inout vec2 dir, int i, int n) {
    vec2 o = sqrt((float(i) + 0.5) / float(n)) * dir;
    dir = vec2(dir.x * GA_COS - dir.y * GA_SIN, dir.x * GA_SIN + dir.y * GA_COS);
    return o;
}

// ---- 3D simplex noise (Ian McEwan, Ashima Arts - MIT licence) ---------------------------
vec3 mod289(vec3 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
vec4 mod289(vec4 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
vec4 permute(vec4 x) { return mod289(((x * 34.0) + 1.0) * x); }
vec4 taylorInvSqrt(vec4 r) { return 1.79284291400159 - 0.85373472095314 * r; }

float snoise(vec3 v) {
    const vec2 C = vec2(1.0 / 6.0, 1.0 / 3.0);
    const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);
    vec3 i  = floor(v + dot(v, C.yyy));
    vec3 x0 = v - i + dot(i, C.xxx);
    vec3 g  = step(x0.yzx, x0.xyz);
    vec3 l  = 1.0 - g;
    vec3 i1 = min(g.xyz, l.zxy);
    vec3 i2 = max(g.xyz, l.zxy);
    vec3 x1 = x0 - i1 + C.xxx;
    vec3 x2 = x0 - i2 + C.yyy;
    vec3 x3 = x0 - D.yyy;
    i = mod289(i);
    vec4 p = permute(permute(permute(
              i.z + vec4(0.0, i1.z, i2.z, 1.0))
            + i.y + vec4(0.0, i1.y, i2.y, 1.0))
            + i.x + vec4(0.0, i1.x, i2.x, 1.0));
    float n_ = 0.142857142857;
    vec3 ns = n_ * D.wyz - D.xzx;
    vec4 j  = p - 49.0 * floor(p * ns.z * ns.z);
    vec4 x_ = floor(j * ns.z);
    vec4 y_ = floor(j - 7.0 * x_);
    vec4 x  = x_ * ns.x + ns.yyyy;
    vec4 y  = y_ * ns.x + ns.yyyy;
    vec4 h  = 1.0 - abs(x) - abs(y);
    vec4 b0 = vec4(x.xy, y.xy);
    vec4 b1 = vec4(x.zw, y.zw);
    vec4 s0 = floor(b0) * 2.0 + 1.0;
    vec4 s1 = floor(b1) * 2.0 + 1.0;
    vec4 sh = -step(h, vec4(0.0));
    vec4 a0 = b0.xzyw + s0.xzyw * sh.xxyy;
    vec4 a1 = b1.xzyw + s1.xzyw * sh.zzww;
    vec3 p0 = vec3(a0.xy, h.x);
    vec3 p1 = vec3(a0.zw, h.y);
    vec3 p2 = vec3(a1.xy, h.z);
    vec3 p3 = vec3(a1.zw, h.w);
    vec4 norm = taylorInvSqrt(vec4(dot(p0, p0), dot(p1, p1), dot(p2, p2), dot(p3, p3)));
    p0 *= norm.x; p1 *= norm.y; p2 *= norm.z; p3 *= norm.w;
    vec4 m = max(0.6 - vec4(dot(x0, x0), dot(x1, x1), dot(x2, x2), dot(x3, x3)), 0.0);
    m = m * m;
    return 42.0 * dot(m * m, vec4(dot(p0, x0), dot(p1, x1), dot(p2, x2), dot(p3, x3)));
}

// ---- octahedral normal packing (2 channels) ------------------------------------------------
vec2 octEncode(vec3 n) {
    n /= (abs(n.x) + abs(n.y) + abs(n.z));
    vec2 s = vec2(n.x >= 0.0 ? 1.0 : -1.0, n.y >= 0.0 ? 1.0 : -1.0);
    vec2 e = n.z >= 0.0 ? n.xy : (1.0 - abs(n.yx)) * s;
    return e * 0.5 + 0.5;
}
vec3 octDecode(vec2 f) {
    f = f * 2.0 - 1.0;
    vec3 n = vec3(f.x, f.y, 1.0 - abs(f.x) - abs(f.y));
    float t = saturate(-n.z);
    n.xy += vec2(n.x >= 0.0 ? -t : t, n.y >= 0.0 ? -t : t);
    return normalize(n);
}

// ---- space conversion ---------------------------------------------------------------------------
vec3 screenToView(vec2 uv, float depth) {
    vec4 v = gbufferProjectionInverse * vec4(vec3(uv, depth) * 2.0 - 1.0, 1.0);
    return v.xyz / v.w;
}
vec3 viewToScreen(vec3 vp) {
    vec4 c = gbufferProjection * vec4(vp, 1.0);
    return (c.xyz / c.w) * 0.5 + 0.5;
}
vec3 viewToFeet(vec3 vp) { return (gbufferModelViewInverse * vec4(vp, 1.0)).xyz; }
vec3 viewDirToWorld(vec3 d) { return mat3(gbufferModelViewInverse) * d; }
float linearDepth(float d) {
    return (2.0 * near * far) / (far + near - (d * 2.0 - 1.0) * (far - near));
}
#endif
