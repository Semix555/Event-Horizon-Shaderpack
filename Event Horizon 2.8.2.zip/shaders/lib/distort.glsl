#ifndef DISTORT_GLSL
#define DISTORT_GLSL
// Shadow-space warp: dense texels near the player, coarse far away. It acts like a
// continuous single-pass cascade chain, and its quality scales with shadowMapResolution.
// Must be applied identically in shadow.vsh and in every shadow lookup.
#define SHADOW_WARP 0.85
#define SHADOW_Z_SCALE 0.2     // squeezes depth so tall occluders stay inside the map
vec2 distortShadow(vec2 ndc) {
    float f = (1.0 - SHADOW_WARP) + length(ndc) * SHADOW_WARP;
    return ndc / f;
}
#endif
