// ============================================================================
//  EVENT HORIZON - option definitions
//  Iris scans every  "#define NAME value // [allowed values]"  and
//  "//#define NAME"  line of the pack and shows it in the settings menu
//  (menu layout: shaders.properties, labels: lang/en_us.lang).
//  No include guard on purpose. Every program includes this file once.
// ============================================================================

// ---- [Performance] / shadows -------------------------------------------------
#define SHADOWS
const int   shadowMapResolution = 2048;   // [512 1024 2048 4096]
const float shadowDistance      = 128.0;  // [64.0 96.0 128.0 160.0 192.0 256.0]
#define PCF_QUALITY 2                     // [0 1 2 3]
#define SHADOW_SOFTNESS 1.5               // [0.5 1.0 1.5 2.0 3.0 4.0]
#define COLORED_SHADOWS
#define GLASS_SHADOW_STRENGTH 1.0         // [0.5 0.75 1.0 1.25 1.5]

// hidden constants (not shown in the menu)
const bool  shadowtex0Nearest   = true;
const bool  shadowtex1Nearest   = true;
const bool  shadowcolor0Nearest = true;

// ---- [Lighting] ----------------------------------------------------------------
#define TORCH_INTENSITY 1.0               // [0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define TORCH_WARMTH 1.0                  // [0.0 0.5 1.0]
#define DYNAMIC_HAND_LIGHT
#define AMBIENT_LIGHT 1.0                 // [0.5 0.75 1.0 1.25 1.5 2.0]
#define SUN_INTENSITY 1.0                 // [0.5 0.75 1.0 1.25 1.5 2.0]
#define EMISSIVE_STRENGTH 1.0             // [0.5 1.0 1.5 2.0 3.0]
#define CAVE_BRIGHTNESS 1.0               // [0.0 0.5 1.0 1.5 2.0 3.0]
#define LAMP_GLOW 0.85                    // [0.5 0.6 0.7 0.85 1.0]
#define ORE_GLOW
#define ORE_GLOW_STRENGTH 1.0             // [0.5 0.75 1.0 1.5 2.0]
#define COLOR_BLEEDING
#define COLOR_BLEED_QUALITY 2             // [1 2 3 4]
#define COLOR_BLEED_STRENGTH 1.0          // [0.5 1.0 1.5 2.0]

// ---- [Block Reflections] - metals, gems, polished quartz, waxed copper -------------------
// Reflective blocks (ids in block.properties) mirror the sky, the sun / moon, torches, lava and
// everything else that is on screen. Needs no other option (works with SSR off).
#define BLOCK_REFLECTIONS
#define BLOCK_REFL_STRENGTH 1.0           // [0.25 0.5 0.75 1.0 1.25 1.5 2.0]
#define BLOCK_REFL_STEPS 16               // [6 8 12 16 24 32 48]
#define BLOCK_REFL_DISTANCE 48            // [16 24 32 48 64 96]
// Waxed, unoxidised copper only (faint, half the ray steps: cheap in copper-heavy places)
#define BLOCK_REFL_COPPER

// ---- [Nether Dimension] ------------------------------------------------------------
#define STEM_GLOW 0.7                     // [0.0 0.3 0.5 0.7 0.85 1.0]
#define STEM_PULSE 1.0                    // [0.0 0.5 1.0 1.5]
#define NETHER_AMBIENT 2.0                // [0.5 1.0 1.5 2.0 2.5 3.0 4.0]

// ---- [Atmosphere] ---------------------------------------------------------------
#define VL_STEPS 12                       // [4 6 8 12 16 24 32]
#define VL_INTENSITY 1.0                  // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define FOG_DENSITY 1.0                   // [0.0 0.25 0.5 1.0 1.5 2.0 3.0]
#define BLOOM
#define BLOOM_QUALITY 2                   // [1 2 3]
#define BLOOM_INTENSITY 1.0               // [0.25 0.5 1.0 1.5 2.0 3.0]
#define EXPOSURE 1.0                      // [0.5 0.75 1.0 1.25 1.5 2.0]
#define SATURATION 1.0                    // [0.6 0.8 1.0 1.2 1.4]
#define VIGNETTE
//#define FILM_GRAIN
//#define CHROMATIC_ABERRATION
#define CHROMATIC_STRENGTH 1.0            // [0.25 0.5 1.0 1.5 2.0]

// ---- [Clouds] ---------------------------------------------------------------------------
#define CLOUDS
#define CLOUD_COVERAGE 0.3                // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define CLOUD_DENSITY 1.0                 // [0.5 0.75 1.0 1.25 1.5 2.0]
#define CLOUD_HEIGHT 160                  // [128 160 192 224 256]
#define CLOUD_THICKNESS 64                // [32 48 64 96 128 160]
#define CLOUD_SCALE 1.0                   // [0.5 0.75 1.0 1.5 2.0]
#define CLOUD_SPEED 1.0                   // [0.0 0.25 0.5 1.0 2.0 4.0]
#define CLOUD_BRIGHTNESS 1.0              // [0.5 0.75 1.0 1.25 1.5]
#define CLOUD_QUALITY 2                   // [1 2 3 4]
#define CLOUD_SHADOWS
#define CLOUD_SHADOW_STRENGTH 0.8         // [0.25 0.5 0.8 1.0]

// ---- [Sky] sunrise / sunset ---------------------------------------------------------------
#define SUNSET_INTENSITY 1.0              // [0.0 0.5 0.75 1.0 1.25 1.5 2.0]
#define TWILIGHT_RAYS 1.0                 // [0.0 0.5 1.0 1.5 2.0 3.0]
#define SKY_BLUE 1.0                      // [0.5 0.75 1.0 1.25 1.5 2.0]
#define SUN_SIZE 0.8                      // [0.5 0.6 0.7 0.8 0.9 1.0]
#define NIGHT_BRIGHTNESS 1.0              // [0.5 0.75 1.0 1.5 2.0 3.0]
#define MOON_SIZE 0.04                    // [0.025 0.035 0.04 0.05 0.065 0.08]

// ---- [Sky] milky way (night, Overworld) -------------------------------------------------
#define MILKY_WAY
#define MILKY_WAY_STARS
#define MILKY_WAY_INTENSITY 1.0           // [0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define MILKY_WAY_SIZE 1.0                // [0.6 0.8 1.0 1.25 1.5 2.0]

// ---- [Water] ----------------------------------------------------------------------
#define WATER_WAVES
#define WAVE_QUALITY 3                    // [1 2 3 4]
#define WAVE_HEIGHT 1.0                   // [0.25 0.5 0.75 1.0 1.5 2.0]
#define WAVE_SPEED 1.0                    // [0.25 0.5 1.0 1.5 2.0]
#define WATER_CLARITY 1.0                 // [0.25 0.5 1.0 1.5 2.0 3.0]
//#define WATER_FOAM
#define WATER_REFRACTION
#define SSR
#define SSR_STEPS 24                      // [8 12 16 24 32 48 64 96]
#define SSR_STRENGTH 1.0                  // [0.25 0.5 0.75 1.0 1.5]
#define PUDDLES
// Wet look of the whole world (not just puddles): while it rains and for WET_DURATION seconds after it,
// blocks under the open sky get darker and mirror the sky. Costs nothing while the weather is dry.
#define WET_BLOCKS
#define WET_BLOCKS_STRENGTH 1.0           // [0.25 0.5 0.75 1.0 1.5 2.0]
#define WET_DURATION 60                   // [30 45 60 90 120]
#define WATERFALL_FLOW
#define WATERFALL_STRENGTH 1.0            // [0.5 0.75 1.0 1.5 2.0]

// ---- [Water] / underwater experience (camera below the surface) -----------------------
// Biome look: warm oceans turquoise and clear, cold / deep water darker, saturated blue
#define UW_BIOME_LOOK
// Visibility range of the water veil (1.0 = about 125 blocks in warm, 70 in cold water)
#define UW_VISIBILITY 1.0                 // [0.5 0.75 1.0 1.25 1.5 2.0]
#define UW_CAUSTICS
#define UW_CAUSTIC_STRENGTH 1.0           // [0.25 0.5 0.75 1.0 1.25 1.5 2.0]
// Sun shafts under water (needs SHADOWS)
#define UW_GODRAYS
#define UW_RAY_STRENGTH 0.25              // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define UW_RAY_STEPS 10                   // [6 8 10 12 16]

// ---- [Additional Effects] - all OFF by default and in every preset ---------------------
// Each effect is its own full-screen pass; a switched-off effect costs nothing (shaders.properties).
#define DOF_STRENGTH 1.0                  // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define DOF_QUALITY 12                    // [8 12 16 24]
//#define DEPTH_OF_FIELD
#define MB_STRENGTH 1.0                   // [0.25 0.5 0.75 1.0 1.5 2.0]
#define MB_SAMPLES 8                      // [4 6 8 12 16]
//#define MOTION_BLUR
#define RAIN_DROP_AMOUNT 1.0              // [0.5 0.75 1.0 1.5 2.0]
#define RAIN_DROP_SIZE 1.0                // [0.6 0.8 1.0 1.3 1.6]
//#define LENS_RAIN_DROPS

// ---- [End Dimension] - black hole ---------------------------------------------------
#define BLACK_HOLE
#define BH_STEPS 96                       // [24 40 64 96 128 192]
#define BH_INTENSITY 1.0                  // [0.25 0.5 0.75 1.0 1.5 2.0 3.0 4.0]
#define BH_DISK_COLOR_R 1.0               // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define BH_DISK_COLOR_G 0.55              // [0.0 0.1 0.2 0.3 0.4 0.5 0.55 0.6 0.7 0.8 0.9 1.0]
#define BH_DISK_COLOR_B 0.18              // [0.0 0.1 0.18 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define BH_HORIZON_SIZE 1.75              // [0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0]
#define BH_DISK_TILT 12.0                 // [0.0 5.0 12.0 20.0 30.0 45.0 60.0]
#define BH_SPIN_SPEED 1.0                 // [0.0 0.5 1.0 2.0 4.0]
#define BH_GLOW 1.5                       // [0.0 0.5 1.0 1.5 2.0 3.0]

// ---- [End Dimension] - nebula & aurora ------------------------------------------------
#define NEBULA
#define NEBULA_LAYERS 3                   // [2 3]
#define NEBULA_INTENSITY 1.0              // [0.25 0.5 0.75 1.0 1.25 1.5 2.0]
#define NEBULA_SPEED 1.0                  // [0.0 0.25 0.5 1.0 2.0 3.0]
#define NEBULA_BH_MASK 4.0                // [2.0 3.0 4.0 5.0 6.0 8.0]

// ---- [End Dimension] - original sky -----------------------------------------------------
// OFF by default and in every preset. ON = the End sky of version 1.7 (violet base, violet/teal nebula).
//#define OG_END
