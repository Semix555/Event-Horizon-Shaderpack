#ifndef SKY_GLSL
#define SKY_GLSL
// Sun / moon geometry, analytic sky with sunrise / sunset colours, ambient light and
// exponential height fog.
// Requires settings.glsl + common.glsl. Zenith and horizon colours come from the vanilla
// uniforms skyColor / fogColor, so day-night, weather and biome tints work automatically.

#define SKY_BRIGHTNESS 2.0
#define FOG_FALLOFF 0.045      // height fog e-folding rate per block
#define FOG_REF_LEVEL 62.0     // fog is densest at / below this world height

vec3 sunDirWorld()   { return normalize(mat3(gbufferModelViewInverse) * sunPosition); }
vec3 moonDirWorld()  { return normalize(mat3(gbufferModelViewInverse) * moonPosition); }
vec3 lightDirWorld() { return normalize(mat3(gbufferModelViewInverse) * shadowLightPosition); }

// 0 at night, 1 in full daylight (based on sun height)
float dayAmount() { return smoothstep(-0.12, 0.18, sunDirWorld().y); }

// 1 while the sun is close to the horizon (sunrise / sunset / blue hour), 0 at noon and at night.
// Peaks at about 2 degrees elevation, is already small again at 20 degrees.
float twilightAmount() {
    float h = sunDirWorld().y;
    return exp(-sq((h - 0.03) * 5.0)) * (1.0 - 0.75 * rainStrength);
}

// Our own daytime sky colours: a clear blue sky instead of the (often grey) vanilla sky uniforms.
// Vanilla colours take over in the rain, at night and around sunrise / sunset, where they carry
// the weather and twilight tints.
float customSkyWeight() { return smoothstep(0.05, 0.35, sunDirWorld().y) * (1.0 - rainStrength); }
vec3 skyZenith() {
    vec3 pale  = vec3(0.030, 0.160, 0.680);
    vec3 vivid = vec3(0.015, 0.075, 0.550);                      // deep royal blue overhead
    vec3 blue = max(mix(pale, vivid, SKY_BLUE), vec3(0.0));      // SKY_BLUE > 1 goes even deeper
    return mix(toLinear(skyColor), blue, customSkyWeight());
}
vec3 skyHorizon() {
    vec3 pale  = vec3(0.300, 0.520, 0.880);
    vec3 vivid = vec3(0.160, 0.340, 0.850);                      // blue haze, not turquoise
    vec3 blue = max(mix(pale, vivid, SKY_BLUE), vec3(0.0));
    return mix(toLinear(fogColor), blue, customSkyWeight());
}

// Colour of the direct light: red-orange at the horizon, golden when low, warm white at noon,
// blue moonlight at night. The sun is dimmed near the horizon (long path through the air).
vec3 directLightColor() {
    float h = sunDirWorld().y;
    float day = smoothstep(-0.10, 0.12, h);
    vec3 cHor  = vec3(1.00, 0.30, 0.10);
    vec3 cLow  = vec3(1.00, 0.56, 0.26);
    vec3 cHigh = vec3(1.00, 0.93, 0.80);
    vec3 sunC  = mix(cHor, cLow, smoothstep(0.0, 0.12, h));
    sunC = mix(sunC, cHigh, smoothstep(0.10, 0.45, h));
    sunC *= 3.0 * SUN_INTENSITY * mix(0.60, 1.0, smoothstep(0.0, 0.30, h));
    vec3 moonC = vec3(0.70, 0.74, 0.82) * (0.38 * NIGHT_BRIGHTNESS);   // soft, neutral grey moonlight
    return mix(moonC, sunC, day) * (1.0 - 0.85 * rainStrength);
}

// Extra light of the sky around the sun at sunrise / sunset, for a view direction `dir`.
//  sun side      : golden orange at the horizon -> rose -> violet higher up
//  opposite side : "belt of Venus" (pink band) above the blue Earth shadow
vec3 twilightGlow(vec3 dir, vec3 sd) {
    float az = dot(normalize(dir.xz + vec2(1e-4)), normalize(sd.xz + vec2(1e-4)));   // -1 .. 1
    float el = max(dir.y, 0.0);
    float sunSide = pow(saturate(az * 0.5 + 0.5), 1.6);

    vec3 c0 = vec3(1.00, 0.46, 0.10);   // golden orange
    vec3 c1 = vec3(0.95, 0.22, 0.30);   // rose red
    vec3 c2 = vec3(0.45, 0.20, 0.65);   // violet
    vec3 warm = mix(c0, c1, smoothstep(0.00, 0.20, el));
    warm = mix(warm, c2, smoothstep(0.12, 0.60, el));

    vec3 venus = mix(vec3(0.95, 0.52, 0.62), vec3(0.28, 0.26, 0.58), smoothstep(0.0, 0.40, el));

    vec3 glow = warm  * (sunSide * exp(-el * 3.0) * 1.15)
              + venus * ((1.0 - sunSide) * exp(-el * 4.5) * 0.45);
    return glow;
}

// Analytic sky radiance in world direction `dir` (unit length).
vec3 atmosphereSky(vec3 dir) {
    vec3 zenith  = skyZenith();
    vec3 horizon = skyHorizon();
    float t = pow(saturate(1.0 - max(dir.y, 0.0)), 3.2);       // 0 = zenith, 1 = horizon
    vec3 c = mix(zenith, horizon, t);

    vec3 sd = sunDirWorld();
    float day = dayAmount();
    float tw  = twilightAmount();

    // night sky: a soft blue-grey glow instead of pitch black, brighter towards the horizon
    float night = 1.0 - day;
    vec3 nightSky = mix(vec3(0.008, 0.013, 0.028), vec3(0.032, 0.042, 0.074), pow(1.0 - saturate(dir.y), 2.0));
    c += nightSky * (night * NIGHT_BRIGHTNESS * (1.0 - 0.5 * rainStrength));

    // sunrise / sunset colours
    c += twilightGlow(dir, sd) * (tw * SUNSET_INTENSITY * 0.9);

    c = mix(c, horizon * 0.55, saturate(-dir.y * 4.0));        // below the horizon: darker haze

    float cs = max(dot(dir, sd), 0.0);
    // forward-scattering glow around the sun (broad aureole + tight halo + inner core)
    float glow = pow(cs, 5.0) * 0.14 + pow(cs, 60.0) * 0.55 + pow(cs, 900.0) * 2.0;
    glow *= 1.0 + 1.6 * tw;                                    // bigger halo when the sun is low
    vec3 sunTint = mix(vec3(1.0, 0.42, 0.14), vec3(1.0, 0.86, 0.62), smoothstep(0.0, 0.40, sd.y));
    c += sunTint * glow * max(day, 0.6 * tw) * (1.0 - 0.9 * rainStrength);

    return c * SKY_BRIGHTNESS;
}

// Procedural sun disc (replaces the vanilla sun sprite): angular radius 0.085 rad * SUN_SIZE,
// soft edge, orange near the horizon and warm white when high. Works anywhere on the screen.
vec3 sunDisc(vec3 dir) {
    vec3 sd = sunDirWorld();
    float cs = dot(dir, sd);
    if (cs < 0.97) return vec3(0.0);
    float R = 0.085 * SUN_SIZE;
    float ang = acos(min(cs, 1.0));
    float edge = 1.0 - smoothstep(R * 0.80, R, ang);
    vec3 col = mix(vec3(1.00, 0.50, 0.18), vec3(1.00, 0.94, 0.78), smoothstep(0.0, 0.35, sd.y));
    return col * (14.0 * edge * smoothstep(-0.02, 0.02, dir.y) * (1.0 - 0.7 * rainStrength));
}

// ---- custom moon ---------------------------------------------------------------------------------
// soft elliptical blob in moon-disc coordinates (-1..1), used to paint the lunar maria
float moonBlob(vec2 p, vec2 c, vec2 r) {
    vec2 d = (p - c) / r;
    return exp(-dot(d, d) * 2.2);
}

// Small realistic moon: the dark maria of the near side (Imbrium, Serenitatis, Tranquillitatis,
// Crisium, Procellarum ...), rayed craters (Tycho, Copernicus, Aristarchus), finer crater texture,
// limb darkening, the real phase from moonPhase, earthshine and a soft glow around it.
// Returns final radiance; add it to the sky before the clouds so they can cover it.
vec3 moonDisc(vec3 dir) {
    vec3 f = moonDirWorld();
    float c = dot(dir, f);
    if (c < 0.9) return vec3(0.0);
    float vis = smoothstep(-0.03, 0.04, dir.y)
              * (0.10 + 0.90 * (1.0 - dayAmount()))            // faintly visible by day, bright at night
              * (1.0 - 0.8 * rainStrength);

    // glow: tight corona + soft aureole in cool grey-blue
    vec3 col = vec3(0.60, 0.68, 0.88) * (pow(c, 400.0) * 0.45 + pow(c, 60.0) * 0.10 + pow(c, 10.0) * 0.012);

    float R = MOON_SIZE;                                       // angular radius in radians
    if (c > cos(R)) {
        vec3 upRef = abs(f.y) > 0.98 ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
        vec3 rt = normalize(cross(f, upRef));                  // screen-right, north up
        vec3 up = cross(rt, f);
        vec2 p = vec2(dot(dir, rt), dot(dir, up)) / sin(R);    // -1 .. 1 across the disc
        float rr = dot(p, p);
        if (rr < 1.0) {
            vec3 n = vec3(p, sqrt(1.0 - rr));                  // sphere normal as seen from here

            // phase: moonPhase 0 = full, 4 = new; waning phases are lit on the left, waxing on the right
            float k = float(moonPhase);
            float alpha = (k <= 4.0 ? k : 8.0 - k) * (PI * 0.25);
            vec3 Lm = vec3((k <= 4.0 ? -1.0 : 1.0) * sin(alpha), 0.0, cos(alpha));
            float lit = smoothstep(-0.04, 0.16, dot(n, Lm));

            // maria with ragged coastlines
            float maria = 0.0;
            maria += moonBlob(p, vec2(-0.30,  0.42), vec2(0.30, 0.24));   // Imbrium
            maria += moonBlob(p, vec2( 0.10,  0.42), vec2(0.17, 0.15));   // Serenitatis
            maria += moonBlob(p, vec2( 0.30,  0.14), vec2(0.24, 0.17));   // Tranquillitatis
            maria += moonBlob(p, vec2( 0.72,  0.30), vec2(0.12, 0.10));   // Crisium
            maria += moonBlob(p, vec2( 0.60, -0.12), vec2(0.17, 0.15));   // Fecunditatis
            maria += moonBlob(p, vec2(-0.62,  0.02), vec2(0.30, 0.38));   // Oceanus Procellarum
            maria += moonBlob(p, vec2(-0.22, -0.40), vec2(0.22, 0.14));   // Nubium
            maria += moonBlob(p, vec2(-0.55, -0.42), vec2(0.12, 0.11));   // Humorum
            maria += moonBlob(p, vec2( 0.28, -0.22), vec2(0.09, 0.08));   // Nectaris
            maria += moonBlob(p, vec2(-0.02,  0.84), vec2(0.35, 0.07));   // Frigoris
            maria = smoothstep(0.28, 0.60, maria + snoise(vec3(p * 3.2, 1.7)) * 0.22);

            // crater texture and brighter highlands
            float rough = snoise(vec3(p * 9.0, 3.3)) * 0.5 + snoise(vec3(p * 19.0, 5.1)) * 0.25;
            float alb = mix(0.88, 0.40, maria) + rough * 0.09;

            // bright rayed craters
            alb += 0.55 * moonBlob(p, vec2(-0.12, -0.72), vec2(0.045, 0.045));   // Tycho
            alb += 0.25 * moonBlob(p, vec2(-0.33,  0.12), vec2(0.030, 0.030));   // Copernicus
            alb += 0.22 * moonBlob(p, vec2(-0.54,  0.29), vec2(0.025, 0.025));   // Aristarchus
            vec2 tp = p - vec2(-0.12, -0.72);
            alb += 0.10 * pow(abs(sin(atan(tp.y, tp.x) * 7.0 + 1.3)), 8.0) * exp(-length(tp) * 2.2) * (1.0 - maria);

            alb *= 0.80 + 0.20 * sqrt(n.z);                    // limb darkening

            vec3 surf = vec3(0.92, 0.93, 0.97) * alb * (lit + 0.03) + vec3(0.010, 0.014, 0.024);   // + earthshine
            float edge = 1.0 - smoothstep(0.92, 1.0, rr);
            col = mix(col, surf * 2.4, edge);
        }
    }
    return col * vis;
}

// ---- Milky Way -------------------------------------------------------------------------------------
// Procedural galaxy band in the style of dark-sky astrophotography. It is fixed to the same
// rotating celestial sphere as the vanilla stars and the moon, so it turns with the world time
// (one turn per Minecraft day, exactly in step with sun, moon and stars).
//   * fades in only in real darkness (sun far below the horizon), fades out again before sunrise
//   * galactic centre (bulge, Great Rift dust lane, ochre-brown core, rust / blue nebula tints)
//   * soft, noise-shifted edges so the band flows into the night sky
//   * resolved star clouds inside the band on top of the diffuse glow
#define MW_SUNPATH_ROT (-20.0)   // must equal sunPathRotation in final.fsh

// Galactic axes (centre, rotation direction, north pole) expressed in the celestial frame.
// Positioned so that the galactic centre culminates ~41 degrees high in the south during the evening.
const vec3 MW_GX = vec3( 0.48384, -0.69893, -0.52668);
const vec3 MW_GY = vec3(-0.74698, -0.64338,  0.16758);
const vec3 MW_GZ = vec3(-0.45598,  0.31234, -0.83338);

// Visibility 0..1: tied to the sun height (sin of the elevation) with a long, soft transition,
// weaker under a bright high moon and in rain.
float mwVisibility() {
    float h = sunDirWorld().y;
    // 0 while the sun is above about -10 degrees (day, sunset, dusk), 1 below about -27 degrees
    float dark = 1.0 - smoothstep(-0.45, -0.17, h);
    dark = dark * dark * (3.0 - 2.0 * dark);                        // extra soft start and end
    float illum  = 0.5 + 0.5 * cos(float(moonPhase) * (PI * 0.25)); // 1 = full moon, 0 = new moon
    float moonUp = smoothstep(-0.10, 0.45, moonDirWorld().y);
    float wash   = 1.0 - 0.45 * illum * moonUp;
    return dark * wash * (1.0 - 0.95 * rainStrength);
}

// World direction -> celestial (star) frame: undo the sun path rotation and the time angle.
vec3 mwStarFrame(vec3 dir) {
    float f  = -MW_SUNPATH_ROT * 0.0174532925;
    float cf = cos(f);
    float sf = sin(f);
    vec3 v  = vec3(dir.z, dir.y, -dir.x);
    vec3 sd = sunDirWorld();
    vec3 s  = vec3(sd.z, sd.y, -sd.x);
    vec3 q  = vec3(v.x * cf - v.y * sf, v.x * sf + v.y * cf, v.z);
    vec3 sr = vec3(s.x * cf - s.y * sf, s.x * sf + s.y * cf, s.z);
    vec2 cs = normalize(sr.yz);                                     // (cos, sin) of the time angle
    return vec3(q.x, q.y * cs.x + q.z * cs.y, -q.y * cs.y + q.z * cs.x);
}

float mwFbm(vec3 p, int oct) {
    float a = 0.5;
    float s = 0.0;
    for (int i = 0; i < 4; i++) {
        if (i >= oct) break;
        s += a * snoise(p);
        p = p * 2.03 + vec3(11.7, 3.1, 7.9);
        a *= 0.5;
    }
    return s;
}

// one layer of point stars on a 3D grid (p = unit direction, scale = cells per radian)
vec3 mwStarLayer(vec3 p, float scale, float dens, float amp) {
    vec3 q  = p * scale;
    vec3 id = floor(q);
    if (hash13(id) < 1.0 - dens) return vec3(0.0);
    vec3 f   = fract(q) - 0.5;
    vec3 off = (vec3(hash13(id + 7.1), hash13(id + 13.7), hash13(id + 3.3)) - 0.5) * 0.3;
    float r   = length(f - off);
    float mag = hash13(id + 21.3);
    float t   = hash13(id + 33.9);
    vec3 tint = mix(vec3(0.65, 0.78, 1.00), vec3(1.00, 0.82, 0.62), t);
    return tint * (smoothstep(0.30, 0.0, r) * amp * (0.2 + 0.8 * mag * mag));
}

// Radiance of the Milky Way in world direction `dir`. `fast` = cheaper version for reflections.
vec3 milkyWay(vec3 dir, bool fast) {
#ifdef MILKY_WAY
    float vis = mwVisibility();
    if (vis < 0.003) return vec3(0.0);                              // daytime: no work at all
    float hz = smoothstep(0.0, 0.30, dir.y);                        // extinction near the horizon
    if (hz <= 0.0) return vec3(0.0);

    vec3 w = mwStarFrame(dir);
    vec3 g = vec3(dot(w, MW_GX), dot(w, MW_GY), dot(w, MW_GZ));     // galactic frame
    float b = asin(clamp(g.z, -1.0, 1.0));                          // galactic latitude
    float l = atan(g.y, g.x);                                       // galactic longitude, 0 = centre
    float S = MILKY_WAY_SIZE;

    // ---- envelope (cheap, so the empty sky returns before any noise) ----------------------------
    float lw    = exp(-0.5 * sq(l / 1.15));                         // 1 towards the centre
    float sigD  = 0.17 * S * (1.0 + 0.5 * lw);                      // band is wider near the centre
    float disc  = exp(-0.5 * sq(b / sigD));
    float bulge = exp(-0.5 * (sq(l / (0.50 * S)) + sq(b / (0.30 * S))));
    // the ragged edge below reaches a little further than sigD, so the early-out uses that reach
    float reach = exp(-0.5 * sq(b / (sigD * 1.3)));
    if (max(reach, bulge) < 0.002) return vec3(0.0);

    // ---- structure: clumps, dust, nebulae (noise stretched along the band) ----------------------
    vec3 np = vec3(g.xy * 2.4, g.z * 5.5);
    vec3 wp = np;
    if (!fast) wp += 0.55 * vec3(snoise(np * 0.8 + 4.1), snoise(np * 0.8 + 9.7), snoise(np * 0.8 + 15.3));
    int oct = fast ? 2 : 4;
    float n1 = mwFbm(wp, oct);                                      // star clouds
    float n2 = mwFbm(np * 1.7 + 21.0, oct);                         // dust
    float clump = clamp(0.80 + 0.75 * n1, 0.25, 1.6);

    // Great Rift: dark lane just off the plane, strongest near the centre, plus dark patches
    float dustN      = clamp(0.5 + 0.9 * n2, 0.0, 1.0);
    float laneCentre = 0.035 * S * sin(l * 2.3 + 0.8);
    float lane = exp(-0.5 * sq((b - laneCentre) / (0.055 * S)))
               * (0.35 + 0.65 * smoothstep(0.30, 0.75, dustN))
               * (0.5 + 0.5 * exp(-0.5 * sq(l / 1.6)));
    float patches = smoothstep(0.42, 0.92, dustN) * disc * 0.45;
    float dust = clamp(1.0 - 0.88 * lane - patches, 0.04, 1.0);

    // ---- diffuse light ---------------------------------------------------------------------------------
    // ragged, noise-shifted edge: the band's width varies across the sky, so it dissolves
    // gradually into the night instead of ending on a clean line
    float edgeN  = clamp(0.5 + 0.5 * n2, 0.0, 1.0);
    float sigE   = sigD * (0.80 + 0.40 * edgeN);
    float soft   = exp(-0.5 * sq(b / sigE));
    float thin  = exp(-0.5 * sq(b / (sigD * 0.38)));                // bright narrow inner disc
    float diskL = (0.55 * soft + 0.45 * thin) * mix(0.28, 1.0, lw);
    float lum   = (0.060 * diskL * clump + 0.095 * bulge * (0.7 + 0.3 * clump)) * dust;
    lum += 0.012 * exp(-0.5 * sq(b / (sigD * 2.4))) * mix(0.4, 1.0, lw);   // faint halo

    // colour: cool blue outer disc -> soft white -> warm core
    vec3 cBlue  = vec3(0.52, 0.62, 0.90);    // night-blue / grey outer disc
    vec3 cWhite = vec3(0.98, 0.96, 0.92);
    vec3 cWarm  = vec3(1.00, 0.62, 0.36);    // ochre-brown core: warm earth tones, no magenta
    vec3 col = mix(cBlue, cWhite, smoothstep(0.10, 0.65, lw));
    col = mix(col, cWarm, saturate(bulge * 1.15) * 0.85);

    // subtle emission tints: rusty dust glow, ochre haze round the core, cool blue reflection nebulae
    float coreW = 0.35 + 0.65 * exp(-0.5 * sq(l / 1.3));
    float neb   = smoothstep(0.00, 0.80, 0.9 * n1 - 0.3 * n2) * soft * coreW;
    float neb2  = smoothstep(0.10, 0.80, -0.8 * n1 + 0.4 * n2) * soft * coreW;
    float haze  = exp(-0.5 * (sq(l / 0.9) + sq(b / (0.38 * S))));
    vec3 em = vec3(0.80, 0.40, 0.20) * (neb * 0.028)                  // rusty dust glow
            + vec3(0.85, 0.55, 0.30) * (haze * 0.022 * clump)         // ochre haze round the core
            + vec3(0.30, 0.42, 0.78) * (neb2 * 0.018);                // cool blue reflection nebulae

    em *= mix(0.6, 1.0, dust);

    vec3 result = col * lum + em;

    // ---- resolved stars inside the band --------------------------------------------------------------
#ifdef MILKY_WAY_STARS
    if (!fast) {
        float dens = saturate(disc * 0.6 + bulge * 0.8) * dust;
        result += mwStarLayer(g, 380.0, 0.18 * dens, 0.22);
        result += mwStarLayer(g, 140.0, 0.04 * dens, 0.60);
    }
#endif

    return result * (vis * hz * MILKY_WAY_INTENSITY);
#else
    return vec3(0.0);
#endif
}

// Hemispherical ambient light for a surface normal (world space)
vec3 skyAmbient(vec3 nW) {
    vec3 up  = skyZenith();
    vec3 hor = skyHorizon();
    vec3 ground = hor * 0.35 + vec3(0.012);
    float h = nW.y * 0.5 + 0.5;
    vec3 c = mix(ground, mix(hor, up, 0.65), h);
    // moonlit nights keep a blue-grey ambient floor
    c = max(c, vec3(0.07, 0.08, 0.12) * (NIGHT_BRIGHTNESS * (1.0 - dayAmount())));

    // twilight: warm fill light from the sun side, violet from the opposite side
    vec3 sd = sunDirWorld();
    float sideA = saturate(dot(normalize(nW.xz + vec2(1e-4)), normalize(sd.xz + vec2(1e-4))) * 0.5 + 0.5);
    c += mix(vec3(0.20, 0.14, 0.34), vec3(0.55, 0.26, 0.14), sideA) * (twilightAmount() * 0.35 * SUNSET_INTENSITY);

    return c * 1.1 * AMBIENT_LIGHT * (1.0 + 0.5 * nightVision);
}

// Scalar sky brightness used to light translucent surfaces (water, glass)
float skyBrightness(float skyLm) {
    float s = mix(min(0.30 * NIGHT_BRIGHTNESS, 0.9), 1.0, dayAmount()) * (1.0 - 0.6 * rainStrength);
    return mix(0.10, 1.0, smoothstep(0.1, 0.9, skyLm)) * s;
}

// ---- exponential height fog ----------------------------------------------------------------
//   density(y) = base * exp(-FOG_FALLOFF * max(y - FOG_REF_LEVEL, 0))
float skyExposure() { return smoothstep(0.0, 0.6, float(eyeBrightnessSmooth.y) / 240.0); }

float fogBaseDensity() {
    return 0.0009 * FOG_DENSITY * (1.0 + 2.0 * rainStrength) * mix(0.35, 1.0, skyExposure());
}
float fogDensityAt(float worldY) {
    return fogBaseDensity() * exp(-FOG_FALLOFF * max(worldY - FOG_REF_LEVEL, 0.0));
}

// Analytic optical depth from the camera along unit direction `dir` for length `t`
float fogOpticalDepth(vec3 dir, float t) {
    float base = fogBaseDensity();
    float k  = FOG_FALLOFF;
    float cy = cameraPosition.y - FOG_REF_LEVEL;
    float a  = k * dir.y;
    if (cy < 0.0) {                                   // below the reference level: constant density
        if (dir.y <= 1e-4) return base * t;
        float tc = min(t, -cy / dir.y);
        float rest = t - tc;
        return base * tc + base * (1.0 - exp(-a * rest)) / a;
    }
    float d0 = base * exp(-k * cy);
    if (dir.y >= -1e-4) return abs(a) < 1e-4 ? d0 * t : d0 * (1.0 - exp(-a * t)) / a;
    float tc = min(t, cy / -dir.y);                   // looking down: exponential, then constant
    return d0 * (1.0 - exp(-a * tc)) / a + base * (t - tc);
}

vec3 fogColorAt(vec3 dir) {
    vec3 d = normalize(vec3(dir.x, max(dir.y, 0.0) * 0.25, dir.z));
    vec3 f = atmosphereSky(d);
    f = mix(vec3(luma(f)), f, 0.8);                            // haze is a little greyer than the sky itself
    return f * mix(0.15, 1.0, skyExposure());
}
#endif
