#ifndef UNDERWATER_GLSL
#define UNDERWATER_GLSL
// ============================================================================
//  lib/underwater.glsl  -  Event Horizon 1.9.5
//  Water medium, underwater fog, caustics and shaft helpers. Pure math, no samplers.
//  Requires settings.glsl, common.glsl and sky.glsl (in that order).
//
//  How the underwater look is built
//   * Absorption and veil are separate. Absorption (sigmaA, per colour channel) turns far
//     objects blue / cyan but keeps them readable. The veil (visDist) is the haze that eats
//     contrast; it grows slowly (power 1.3) so the first 20-30 blocks stay crisp and the
//     view still reaches ~120 blocks in warm water.
//   * The water type comes from the vanilla water colours, so it follows the biome:
//       camera below the surface : fogColor   (ratios g/b and r/b are independent of the
//                                              brightness vanilla applies to it)
//       looking into water       : the biome tint stored in the G-buffer
//     warm   = warm / lukewarm ocean  -> turquoise, clear, long view
//     cold   = ocean, river, lake ... -> darker saturated blue, medium view
//     murky  = swamp, mangrove        -> keeps the vanilla green / brown
//   * The depth of the camera below the surface (skylight + sea level) makes everything
//     darker and bluer, like real water does.
// ============================================================================

#define UW_SEA_LEVEL   62.0
#define UW_FRESNEL_F0  0.02
#define UW_RAY_RANGE   80.0

// With shafts active, they carry the sunlight of the water volume, so the isotropic veil
// keeps only a small share of it (no double counting).
#if defined(UW_GODRAYS) && defined(SHADOWS)
  #define UW_VEIL_SUN 0.12
#else
  #define UW_VEIL_SUN 0.45
#endif

struct UWMedium {
    vec3  sigmaA;     // absorption of the scene seen through water, per block (rgb)
    vec3  kd;         // attenuation of daylight with depth, per block (rgb)
    vec3  veil;       // radiance of the water volume (horizontal view) at the camera depth
    float visDist;    // blocks at which the veil has taken about 80 % of the view
};

// ---- camera depth below the water surface (blocks, approximate) -----------------------
// Skylight under water drops by one level per block, so it is a good depth gauge for the
// first 15 blocks; below that the distance to sea level takes over.
float uwCameraDepth() {
    float sky = float(eyeBrightnessSmooth.y) / 240.0;
    return max((1.0 - sky) * 15.0, max(UW_SEA_LEVEL - cameraPosition.y, 0.0));
}

// ---- light that enters the water (neutral colour, the medium tints it) ---------------
vec3 uwSurfaceLight(vec3 lightCol, float lightY, float hFade) {
#ifdef DIM_END
    return vec3(0.16, 0.10, 0.26);
#else
    float skyLum = luma(skyAmbient(vec3(0.0, 1.0, 0.0)));
    vec3  sun    = lightCol * (hFade * saturate(lightY));
    return sun * UW_VEIL_SUN + vec3(skyLum * 1.5) + vec3(0.12, 0.14, 0.18) * nightVision;
#endif
}

// Fraction of the sunlight that gets through the surface (Fresnel, Schlick)
float uwSunTrans(float lightY) {
    float f  = 1.0 - saturate(lightY);
    float f2 = f * f;
    return 1.0 - (UW_FRESNEL_F0 + (1.0 - UW_FRESNEL_F0) * f2 * f2 * f);
}

// ---- the medium ----------------------------------------------------------------------------
//  warm : 0 = temperate / cold, 1 = tropical      murk : 1 = swamp-like water
//  hue  : colour (linear, brightest channel = 1) of the murky water
UWMedium uwBuildMedium(float warm, float murk, vec3 hue, float camDepth, vec3 E) {
#ifndef UW_BIOME_LOOK
    warm = 0.0;
    murk = 1.0;
#endif
    // palettes: x = red, y = green, z = blue (per block / linear light)
    vec3  sigW = vec3(0.060, 0.016, 0.008);      // warm: red dies after ~25 blocks, blue stays
    vec3  sigC = vec3(0.095, 0.030, 0.014);      // cold: a bit stronger, deep blue distance
    vec3  kdW  = vec3(0.100, 0.026, 0.014);
    vec3  kdC  = vec3(0.140, 0.045, 0.024);
    vec3  vlW  = vec3(0.030, 0.460, 0.500);      // turquoise
    vec3  vlC  = vec3(0.012, 0.150, 0.300);      // deep blue with a hint of teal
    vec3  sigM = vec3(0.070, 0.050, 0.120);      // murky: blue is absorbed first (tea colour)
    vec3  kdM  = vec3(0.100, 0.070, 0.120);
    vec3  vlM  = hue * 0.34;

    vec3  sigma = mix(mix(sigC, sigW, warm), sigM, murk);
    vec3  kd    = mix(mix(kdC,  kdW,  warm), kdM,  murk);
    vec3  veilP = mix(mix(vlC,  vlW,  warm), vlM,  murk);
    float vis   = mix(mix(70.0, 125.0, warm), 36.0, murk);

    // the deeper the camera, the bluer and darker the water (and a little shorter the view)
    float deep = smoothstep(4.0, 34.0, camDepth);
    veilP *= mix(vec3(1.0), vec3(0.55, 0.80, 1.0), deep);
    vis   *= mix(1.0, 0.80, deep);

    float clarity = max(WATER_CLARITY, 0.25);
    UWMedium m;
    m.sigmaA  = sigma / clarity;
    m.kd      = kd / clarity;
    m.visDist = vis * UW_VISIBILITY * clarity;
    m.veil    = veilP * (E * exp(-kd * camDepth)) + vec3(0.002, 0.005, 0.008);
    return m;
}

// camera below the surface: the vanilla fog colour is the biome water fog colour
UWMedium uwMediumFromFog(float camDepth, vec3 E) {
    vec3  f    = max(fogColor, vec3(0.0));
    float fb   = max(f.b, 1e-3);
    float warm = smoothstep(0.12, 0.60, f.g / fb);       // warm ocean 0.61, lukewarm 0.43, rest ~0.1
    float murk = smoothstep(0.30, 0.70, f.r / fb);       // swamp 1.5, mangrove 0.8, oceans < 0.1
    vec3  hue  = toLinear(f / max(max(f.r, max(f.g, f.b)), 1e-3));
    return uwBuildMedium(warm, murk, hue, camDepth, E);
}

// looking into water from above: the biome tint of the water surface (gamma encoded)
UWMedium uwMediumFromTint(vec3 tint, vec3 E) {
    float tb   = max(tint.b, 1e-3);
    float warm = smoothstep(0.50, 0.85, tint.g / tb);    // warm ocean 0.90, lukewarm 0.72, ocean 0.52
    float murk = smoothstep(0.45, 0.80, tint.r / tb);    // swamp 0.97
    vec3  hue  = toLinear(tint / max(max(tint.r, max(tint.g, tint.b)), 1e-3));
    return uwBuildMedium(warm, murk, hue, 0.0, E);
}

// Light field of the water: brighter looking up, darker looking down into the depth
float uwDirFactor(vec3 dirW) {
    return mix(0.55, 1.15, smoothstep(-0.85, 0.90, dirW.y));
}

// Underwater fog: spectral absorption of the scene + a slowly growing contrast veil.
vec3 uwFog(vec3 col, float dist, vec3 dirW, UWMedium m) {
    float d = min(dist, 192.0);
    vec3  T = exp(-m.sigmaA * d);
    float v = 1.0 - exp(-1.6 * pow(d / m.visDist, 1.3));
    return col * T * (1.0 - v) + m.veil * (uwDirFactor(dirW) * v);
}

// ---- caustics ------------------------------------------------------------------------------
// Warped sine lattice (after Dave Hoskins): thin bright filaments on a darker base.
// Value range 0 .. ~1, mean ~0.125 (measured), so  8 * value  has a mean of about 1.
float uwCausticLayer(vec2 p, float t) {
    vec2  q = mod(p, TAU) - 250.0;
    vec2  i = q;
    float c = 1.0;
    for (int n = 0; n < 4; n++) {
        float tt = t * (1.0 - 3.5 / float(n + 1));
        i = q + vec2(cos(tt - i.x) + sin(tt + i.y), sin(tt - i.y) + cos(tt + i.x));
        c += 1.0 / length(vec2(q.x / (sin(i.x + tt) * 200.0), q.y / (cos(i.y + tt) * 200.0)));
    }
    c *= 0.25;
    c = 1.17 - pow(c, 1.4);
    return pow(abs(c), 8.0);
}

// p = position (xz) where the light ray crossed the water surface. Two layers with different
// scale, direction and speed hide the tiling of a single layer.
float uwCausticFloor(vec2 p) {
    float t = frameTimeCounter;
    float a = uwCausticLayer(p * 0.55, t * 0.50 + 23.0);
    vec2  r = vec2(0.8 * p.x - 0.6 * p.y, 0.6 * p.x + 0.8 * p.y);
    float b = uwCausticLayer(r * 0.75 + vec2(3.0, -5.0), t * 0.43 + 61.0);
    return 4.0 * (a + b);
}

// Multiplier (mean ~1) for the sunlight that reaches the world position wp after `path`
// blocks of water along the light direction L. Sharpest in the first few blocks of water,
// fading out with depth (the light spreads).
float uwCausticMul(vec3 wp, vec3 L, float path, float depthV) {
#ifdef UW_CAUSTICS
    vec2  s = wp.xz + L.xz * path;
    float c = min(uwCausticFloor(s), 5.0);
    float k = smoothstep(0.0, 1.2, depthV) * (1.0 - smoothstep(10.0, 36.0, depthV)) * UW_CAUSTIC_STRENGTH;
    return max(1.0 + (c - 1.0) * k, 0.05);
#else
    return 1.0;
#endif
}

// Low-frequency, low-contrast variant for the shafts (fewer samples, so it must be smooth)
float uwRayMod(vec2 s, float path) {
    float c = min(8.0 * uwCausticLayer(s * 0.30, frameTimeCounter * 0.35 + 7.0), 4.0);
    float k = 0.6 * (1.0 - smoothstep(4.0, 30.0, path));
    return max(1.0 + (c - 1.0) * k, 0.0);
}

// Scattering phase function of the water, normalised so that an isotropic medium gives 1.
// Forward lobe (Henyey-Greenstein g = 0.55) plus a floor, so shafts stay visible from the side.
float uwPhase(float cosT) {
    const float g = 0.55;
    float d = max(1.0 + g * g - 2.0 * g * cosT, 1e-3);
    return 0.15 + (1.0 - g * g) / (d * sqrt(d));
}
#endif
