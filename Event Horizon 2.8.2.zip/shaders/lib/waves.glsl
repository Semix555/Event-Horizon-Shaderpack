// ============================================================================
//  lib/waves.glsl  -  Event Horizon 1.9.2
//  Ocean swell (Gerstner), fine ripples, waterfall flow and whitewater.
//  Requires settings.glsl + common.glsl first.
//
//  The SAME swell functions run in gbuffers_water.vsh (vertex height) and
//  gbuffers_water.fsh (per-pixel normal), so geometry and shading agree.
//
//  1.9.2 changes
//   * Organic ocean: 6 swell waves with golden-ratio wavelengths and non-parallel,
//     irrational travel directions (28, 65, -37, 138, -104, 119 deg). A slow gradient-noise
//     field bends the wave PHASE and modulates the AMPLITUDE of every wave, so crests are
//     no longer straight, endless and evenly spaced (no more tiling / grid look).
//   * Constants are pre-computed (k*dir, omega, 1/k): no cos/sin(angle), sqrt or division
//     per pixel. The waves run as vec4 / vec2 groups: one sin + one cos per group.
//   * Fine ripples use 2D gradient noise with ANALYTIC derivatives (1 noise tap per octave
//     instead of 3 simplex taps), rotated per octave so the lattice never lines up.
//   * Distance LOD: every wave and every ripple octave fades out (and is skipped) once it
//     is too fine for its distance. Far water only evaluates the 4 big waves.
//   * Waterfalls / steep flowing water: normals switch to a stretched, downward cascading
//     flow pattern; the ocean waves are blended out on steep faces (worldNormal.y).
// ============================================================================
#ifndef WAVES_GLSL
#define WAVES_GLSL

#define RIPPLE_OCTAVES (WAVE_QUALITY - 1)   // 0..3 octaves of fine ripples

// ---- 2D gradient noise with analytic derivative -------------------------------------
// Returns vec3(value, d/dx, d/dy). Value is about +-0.75, no sin() in the hash.
vec2 wvHash22(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.xx + p3.yz) * p3.zy) * 2.0 - 1.0;
}
vec3 wvNoise(vec2 x) {
    vec2 i  = floor(x);
    vec2 f  = x - i;
    vec2 u  = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);        // quintic fade
    vec2 du = 30.0 * f * f * (f * (f - 2.0) + 1.0);
    vec2 ga = wvHash22(i);
    vec2 gb = wvHash22(i + vec2(1.0, 0.0));
    vec2 gc = wvHash22(i + vec2(0.0, 1.0));
    vec2 gd = wvHash22(i + vec2(1.0, 1.0));
    float va = dot(ga, f);
    float vb = dot(gb, f - vec2(1.0, 0.0));
    float vc = dot(gc, f - vec2(0.0, 1.0));
    float vd = dot(gd, f - vec2(1.0, 1.0));
    float k1 = vb - va;
    float k2 = vc - va;
    float k3 = va - vb - vc + vd;
    float val = va + u.x * k1 + u.y * k2 + u.x * u.y * k3;
    vec2  der = ga + u.x * (gb - ga) + u.y * (gc - ga) + u.x * u.y * (ga - gb - gc + gd)
              + du * (vec2(u.y * k3 + k1, u.x * k3 + k2));
    return vec3(val, der);
}

// ============================================================================
//  Ocean swell
//  Wavelengths: 14.0 / phi^n blocks. Directions are spread over irrational angles, long waves
//  stay close to the wind direction, short waves scatter wider (like a real sea state).
//  Per wave i:  theta = k*d.p - w*t + phase + warp_i*N(p)      N = slow noise field
//               A_i   = (S_i / k_i) * (1 + env_i * N(p))       S = k*A = steepness
// ============================================================================
const vec2  SW_WARP_FREQ = vec2(0.05);      // noise field: one cell every ~20 blocks
const float SW_NSCALE    = 1.8;             // noise field gain (value about +-1)

// group A: the four big waves (always evaluated)
const vec4 SW_KX_A   = vec4( 0.39627,  0.30689,  0.93837, -1.41282);   // k * cos(angle)
const vec4 SW_KZ_A   = vec4( 0.21070,  0.65814, -0.70712,  1.27211);   // k * sin(angle)
const vec4 SW_OM_A   = vec4( 1.25832,  1.60060,  2.03600,  2.58983);   // omega (deep water, scaled)
const vec4 SW_PH_A   = vec4( 0.00000,  3.88322,  1.48326,  5.36648);   // golden-ratio start phases
const vec4 SW_SL_A   = vec4( 0.09500,  0.08500,  0.07500,  0.06500);   // steepness k*A
const vec4 SW_Q_A    = vec4( 0.65000,  0.60000,  0.55000,  0.50000);   // crest sharpening
const vec4 SW_IK_A   = vec4( 2.22817,  1.37708,  0.85108,  0.52600);   // 1 / k
const vec4 SW_WA_A   = vec4( 1.30000,  1.70000,  2.10000,  2.60000);   // phase warp strength
const vec4 SW_ENV_A  = vec4( 0.45000, -0.40000,  0.50000, -0.45000);   // amplitude envelope

// group B: the two short waves (WAVE_QUALITY 3+, close range only)
const vec2 SW_KX_B   = vec2(-0.74418, -2.41302);
const vec2 SW_KZ_B   = vec2(-2.98474,  4.35321);
const vec2 SW_OM_B   = vec2( 3.29432,  4.19044);
const vec2 SW_PH_B   = vec2( 2.96652,  0.56655);
const vec2 SW_SL_B   = vec2( 0.05500,  0.04500);
const vec2 SW_Q_B    = vec2( 0.45000,  0.42000);
const vec2 SW_IK_B   = vec2( 0.32509,  0.20091);
const vec2 SW_WA_B   = vec2( 3.00000,  3.40000);
const vec2 SW_ENV_B  = vec2( 0.40000, -0.35000);

// Swell height at the REST position p (world xz). n receives the analytic normal
// (unnormalised, y = up):  N = ( -dh/dx, 1 - sum(Q*k*A*sin), -dh/dz )
// including the exact derivative of the phase warp and the amplitude envelope.
float waveSwell(vec2 p, float t, float dist, out vec3 n) {
    vec3  wn = wvNoise(p * SW_WARP_FREQ + vec2(t * 0.011, -t * 0.007));
    float N  = wn.x * SW_NSCALE;
    vec2  dN = wn.yz * (SW_NSCALE * SW_WARP_FREQ.x);
    float H  = WAVE_HEIGHT * (1.0 + 0.6 * rainStrength);     // storms make steeper waves

    // ---- group A (one vec4 sin + cos)
    vec4 lodA = vec4(1.0, 1.0, 1.0, 1.0 - smoothstep(80.0, 200.0, dist));
    vec4 th   = SW_KX_A * p.x + SW_KZ_A * p.y - SW_OM_A * t + SW_PH_A + SW_WA_A * N;
    vec4 s    = sin(th);
    vec4 c    = cos(th);
    vec4 m    = 1.0 + SW_ENV_A * N;
    vec4 S    = SW_SL_A * m * (H * lodA);                     // k*A per wave
    vec4 A    = S * SW_IK_A;
    vec4 Ac   = A * c;
    float h   = dot(A, s);
    vec2  g   = vec2(dot(Ac, SW_KX_A + SW_WA_A * dN.x), dot(Ac, SW_KZ_A + SW_WA_A * dN.y));
    g        += dN * dot(s * A * SW_ENV_A / m, vec4(1.0));    // d(amplitude) term
    float q   = dot(SW_Q_A * S, s);

#if WAVE_QUALITY >= 3
    // ---- group B (vec2), skipped for far water
    if (dist < 120.0) {
        vec2 lodB = 1.0 - smoothstep(vec2(40.0, 25.0), vec2(120.0, 95.0), vec2(dist));
        vec2 thB  = SW_KX_B * p.x + SW_KZ_B * p.y - SW_OM_B * t + SW_PH_B + SW_WA_B * N;
        vec2 sB   = sin(thB);
        vec2 cB   = cos(thB);
        vec2 mB   = 1.0 + SW_ENV_B * N;
        vec2 SB   = SW_SL_B * mB * (H * lodB);
        vec2 AB   = SB * SW_IK_B;
        vec2 AcB  = AB * cB;
        h        += dot(AB, sB);
        g        += vec2(dot(AcB, SW_KX_B + SW_WA_B * dN.x), dot(AcB, SW_KZ_B + SW_WA_B * dN.y));
        g        += dN * dot(sB * AB * SW_ENV_B / mB, vec2(1.0));
        q        += dot(SW_Q_B * SB, sB);
    }
#endif

    n = vec3(-g.x, 1.0 - q, -g.y);
    return h;
}

// Vertex shader version: height only, the two biggest waves (same warp field as the pixels)
float waveHeightVS(vec2 p, float t) {
    float N  = wvNoise(p * SW_WARP_FREQ + vec2(t * 0.011, -t * 0.007)).x * SW_NSCALE;
    vec2  th = SW_KX_A.xy * p.x + SW_KZ_A.xy * p.y - SW_OM_A.xy * t + SW_PH_A.xy + SW_WA_A.xy * N;
    vec2  A  = SW_SL_A.xy * SW_IK_A.xy * (1.0 + SW_ENV_A.xy * N) * (WAVE_HEIGHT * (1.0 + 0.6 * rainStrength));
    return dot(A, sin(th));
}

// ============================================================================
//  Fine ripples: slope of layered gradient noise. Every octave has its own rotation
//  (37, -73, 109 deg), its own drift direction and a non-integer frequency step, so the
//  noise lattices never align with the block grid or with each other.
// ============================================================================
const float RIPPLE_GAIN = 1.9;   // matches the strength of the old simplex ripples
const float RIP_FREQ[3] = float[3](1.30, 2.80, 6.10);
const float RIP_AMP[3]  = float[3](0.055, 0.0275, 0.01375);
const vec2  RIP_VEL[3]  = vec2[3](vec2(0.34, 0.11), vec2(-0.27, 0.36), vec2(0.21, -0.52));
const mat2  RIP_ROT[3]  = mat2[3](mat2( 0.79864,  0.60182, -0.60182,  0.79864),    //  37 deg
                                  mat2( 0.29237, -0.95630,  0.95630,  0.29237),    // -73 deg
                                  mat2(-0.32557,  0.94552, -0.94552, -0.32557));   // 109 deg
// finer octaves vanish earlier: coarse octaves keep the mid-range alive, no shimmering far away
const float RIP_FADE0[3] = float[3](40.0, 22.0, 12.0);
const float RIP_FADE1[3] = float[3](110.0, 64.0, 36.0);

vec2 waveRipples(vec2 p, float t, float dist) {
#if RIPPLE_OCTAVES > 0
    vec2 slope = vec2(0.0);
    for (int i = 0; i < RIPPLE_OCTAVES; i++) {
        float fade = 1.0 - smoothstep(RIP_FADE0[i], RIP_FADE1[i], dist);
        if (fade <= 0.0) break;                               // all following octaves are finer: done
        mat2 R   = RIP_ROT[i];
        vec3 nz  = wvNoise(R * (p * RIP_FREQ[i]) + RIP_VEL[i] * t);
        slope   += (RIP_AMP[i] * RIP_FREQ[i] * fade) * (nz.yz * R);   // R^T * gradient
    }
    return slope * (RIPPLE_GAIN * WAVE_HEIGHT * (1.0 + 0.8 * rainStrength));
#else
    return vec2(0.0);
#endif
}

// Final world-space surface normal of calm water (flat or gently rolling surface).
vec3 waveNormal(vec2 p, float dist) {
    float t = frameTimeCounter * WAVE_SPEED;
    vec3 n;
    waveSwell(p, t, dist, n);
    n.xz -= waveRipples(p, t, dist);
    return normalize(n);
}

// ============================================================================
//  Waterfalls and steep flowing water
//  On steep faces the ocean waves make no sense. The pattern lives in a surface frame:
//    D = steepest descent on the face, T = across the stream.
//  Noise is stretched along D (long streaks), scrolls downhill and gets stepped ledges
//  that fall with it. Everything is the analytic slope of one height field.
// ============================================================================
#ifdef WATERFALL_FLOW
#define FALL_SPEED 4.0   // blocks per second the pattern falls

vec3 flowNormal(vec3 pos, vec3 nG, float t, float dist) {
    vec3 D = vec3(0.0, -1.0, 0.0) + nG * nG.y;                 // gravity projected onto the face
    D     *= inversesqrt(max(dot(D, D), 1e-4));
    vec3 T = cross(nG, D);
    float u  = dot(pos, T);
    float vb = dot(pos, D);

    float f1 = 1.0 - smoothstep(80.0, 200.0, dist);            // broad streaks + ledges
    float f2 = 1.0 - smoothstep(25.0, 75.0, dist);             // fine fast streaks

    vec2 hg = vec2(0.0);                                       // slope across (u) and along (v)
    if (f1 > 0.0) {
        // broad streaks, stretched 8:1 along the flow
        vec3 n1 = wvNoise(vec2(u * 2.3, (vb - t * FALL_SPEED) * 0.30));
        hg += 0.20 * vec2(2.3 * n1.y, 0.30 * n1.z) * f1;
        // stepped ledges that cascade downward, phase bent by the streak noise
        float ph = 1.55 * (vb - t * FALL_SPEED * 1.25) + 6.0 * n1.x;
        float cs = cos(ph) * 0.10 * f1;
        hg += cs * vec2(6.0 * 2.3 * n1.y, 1.55 + 6.0 * 0.30 * n1.z);
    }
    if (f2 > 0.0) {
        // fine, faster streaks
        vec3 n2 = wvNoise(vec2(u * 6.1 + 17.3, (vb - t * FALL_SPEED * 1.6) * 0.70));
        hg += 0.07 * vec2(6.1 * n2.y, 0.70 * n2.z) * f2;
    }
    return normalize(nG - (T * hg.x + D * hg.y) * (0.55 * WATERFALL_STRENGTH));
}

// Whitewater streaks for the composite pass (axis-aligned frame: stable although the
// normal it receives is already perturbed). Returns 0..1 coverage.
float waterfallFoam(vec3 pos, vec3 nW, float t, float dist) {
    float u = abs(nW.x) > abs(nW.z) ? pos.z : pos.x;
    float v = -pos.y - t * FALL_SPEED;
    float a = wvNoise(vec2(u * 2.9 + 3.7, v * 0.55)).x;
    float b = wvNoise(vec2(u * 7.3 + 11.1, (v - t * FALL_SPEED * 0.9) * 1.10)).x;
    return smoothstep(0.12, 0.42, a + 0.5 * b) * (1.0 - smoothstep(40.0, 110.0, dist));
}
#endif
#endif
