#version 330 compatibility

/* ============================================================================
   shadow.fsh  -  Event Horizon
   shadowcolor0:  rgb = light filter of the occluder (gamma encoded), a = 1 (see main()).
   composite.fsh multiplies the sunlight with this filter wherever a translucent occluder
   (water, stained glass) blocks the light but no opaque one does.
   ============================================================================ */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/blocks.glsl"

#ifndef ID_WATER
#define ID_WATER 10020
#endif

uniform sampler2D gtexture;

in vec2 texcoord;
in vec4 glcolor;
flat in int blockId;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

void main() {
    // ---- encoding of shadowcolor0 (read back in composite.fsh: shadowVisibilityB) ------------
    // rgb = the FINAL light filter of this occluder (gamma encoded), a = 1.
    // Alpha is deliberately fixed at 1: whatever blend state the shadow pass uses for translucent
    // geometry (alpha blending over the white clear colour, or none), a source alpha of 1
    // overwrites the texel completely, so the filter colour arrives unchanged and never washed out.
    if (blockId == ID_WATER) {
        // water lets most light through, tinted by the biome water colour (45 % filter strength)
        vec3 filt = mix(vec3(1.0), toLinear(glcolor.rgb), 0.45);
        outColor = vec4(toGamma(filt), 1.0);
        return;
    }

    if (blockId == ID_PORTAL) {
        // nether portal: a plain purple filter over the whole plane, whatever the swirl texture does
        vec3 filt = mix(vec3(1.0), vec3(0.60, 0.12, 1.0), saturate(0.9 * GLASS_SHADOW_STRENGTH));
        outColor = vec4(toGamma(filt), 1.0);
        return;
    }

    vec4 tex = texture(gtexture, texcoord);
    float cutoff = (blockId == ID_LEAVES) ? 0.5 : 0.1;     // same cutoffs as the terrain pass
    if (tex.a < cutoff) discard;

    vec3 col = tex.rgb * glcolor.rgb;

    if (blockId == ID_GLASS_TINT) {
        // Stained / tinted glass: a clearly coloured shadow (same filter as looking through the glass)
        outColor = vec4(toGamma(glassFilter(toLinear(col), tex.a, GLASS_SHADOW_STRENGTH)), 1.0);
        return;
    }

    // Fully opaque texel (almost every block): mix(white, colour, 1) is the colour itself and
    // toGamma(toLinear(x)) is x, so the six pow() calls of the round trip are skipped.
    if (tex.a > 0.999) {
        outColor = vec4(col, 1.0);
        return;
    }

    // everything else (ice, slime, honey, partly transparent texels): plain colour * opacity
    outColor = vec4(toGamma(mix(vec3(1.0), toLinear(col), tex.a)), 1.0);
}
