#version 330 compatibility
#define DIM_END 1   // set only in shaders/world1 (End copies of the programs)

/* ============================================================================
   composite.fsh  -  Event Horizon, deferred lighting pass
   Reads  : colortex0 = albedo (water pixels: sea-floor albedo)
            colortex1 = RG octahedral view normal, B = AO, A = material id / 4
                        (water: B = tint.r)
            colortex2 = R block light, G sky light, B emissive (water: tint.g),
                        A entity flag = 1 (water: tint.b; terrain: block reflectivity)
            depthtex0 = all geometry, depthtex1 = opaque only, shadow maps
   Writes : colortex0 = lit HDR scene in linear light

   Needs in shaders.properties:
     separateAo = true
     blend.gbuffers_water.colortex1/2/5 = alpha blend (water alpha 1, glass alpha 0), see shaders.properties
     blend.gbuffers_textured.colortex1 = off
     blend.gbuffers_textured.colortex2 = off

   Dimension check at runtime via the Iris uniforms
     Overworld = hasSkylight   Nether = hasCeiling   End = neither
   ============================================================================ */

#include "/lib/settings.glsl"
#include "/lib/buffers.glsl"
#include "/lib/common.glsl"
#include "/lib/distort.glsl"
#include "/lib/sky.glsl"
#include "/lib/clouds.glsl"
// End sky (only used in the End copy of this pass)
#include "/lib/blackhole.glsl"
#include "/lib/blocks.glsl"
#include "/lib/waves.glsl"
#include "/lib/underwater.glsl"

// Sky pixels must start black: stars, sun and moon are ADDED on top of the analytic sky.
const vec4 colortex0ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
const vec4 colortex3ClearColor = vec4(0.0, 0.0, 0.0, 0.0);   // no glass where nothing was drawn
const vec4 colortex4ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
const vec4 colortex5ClearColor = vec4(0.0, 0.0, 0.0, 0.0);

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;       // translucent glass layer: rgb = linear glass colour, a = opacity
uniform sampler2D colortex4;       // glass layer: rg = view normal, ba = block / sky light
uniform sampler2D colortex5;       // water surface: r = view distance, a = 1 (also behind glass)
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform sampler2D shadowtex0;      // all occluders (incl. water, glass)
uniform sampler2D shadowtex1;      // opaque occluders only
uniform sampler2D shadowcolor0;    // light filter of the translucent occluder (rgb, gamma encoded)


in vec2 texcoord;
flat in vec3  lightDirW;
flat in vec3  lightColor;
flat in float horizonFade;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

#define F0_WATER 0.02

// ============================================================================
//  helpers
// ============================================================================
ivec2 toPx(vec2 uv) {
    return ivec2(clamp(uv * vec2(viewWidth, viewHeight), vec2(0.0), vec2(viewWidth, viewHeight) - 1.0));
}
float fetchDepth1(vec2 uv) { return texelFetch(depthtex1, toPx(uv), 0).r; }
float depth1At(ivec2 q) {
    return texelFetch(depthtex1, clamp(q, ivec2(0), ivec2(viewWidth, viewHeight) - 1), 0).r;
}
bool isWaterMat(float m) { return abs(m - MAT_WATER) < 0.5; }

// Water medium of the current view: camera below the surface -> from the vanilla fog colour;
// looking down into water -> from the biome tint (set by shadeOpaque for the sea floor).
UWMedium gUW;

// Set while a screen-space reflection HIT is being lit (see ssrMarch): the mirror image is blurry and
// low contrast, so the hit gets 4 shadow taps and no cloud shadow instead of the full treatment.
bool gCheap = false;

// End: the black hole is the only light source. Its direction is the shadow light direction
// (lightDirW), its colour follows the disk colour; the strength is about that of the sun.
vec3 endLightColor() {
    vec3 c = vec3(BH_DISK_COLOR_R, BH_DISK_COLOR_G, BH_DISK_COLOR_B);
    c = mix(vec3(1.0), c / max(max(c.r, c.g), max(c.b, 0.001)), 0.75);
    return c * (2.4 * min(BH_INTENSITY, 2.0));
}

// ============================================================================
//  G-buffer
// ============================================================================
struct GData {
    vec3  albedo;     // linear
    vec3  nView;      // view-space normal
    float ao;
    float mat;        // 0 none, 1 terrain, 2 water, 3 particle, 4 foliage, 5 entity (see MAT_ENTITY)
    vec2  lm;         // x = block light, y = sky light
    float emissive;
    vec3  tint;       // water only: biome colour, gamma encoded
    float refl;       // terrain only: block reflectivity (see applyBlockReflection)
};

GData readGBuffer(ivec2 p) {
    vec4 c0 = texelFetch(colortex0, p, 0);
    vec4 c1 = texelFetch(colortex1, p, 0);
    vec4 c2 = texelFetch(colortex2, p, 0);
    GData g;
    g.albedo   = c0.rgb;
    g.nView    = octDecode(c1.rg);
    g.ao       = c1.b;
    g.mat      = floor(c1.a * 4.0 + 0.5);
    // gbuffers_entities writes the particle id plus colortex2.a = 1 -> mobs get their own lighting
    if (abs(g.mat - MAT_PARTICLE) < 0.5 && c2.a > 0.5) g.mat = MAT_ENTITY;
    // gbuffers_water writes material 4 plus colortex2.a = 1 for water (alpha 1 is its blend mask);
    // block light is not stored for water, colortex2.r holds tint.b
    bool water = (g.mat > MAT_FOLIAGE - 0.5) && c2.a > 0.5;
    if (water) g.mat = MAT_WATER;
    g.lm       = water ? vec2(0.0, c2.g) : c2.rg;
    g.emissive = water ? 0.0 : c2.b;
    g.tint     = water ? vec3(c1.b, c2.b, c2.r) : vec3(c1.b, c2.b, c2.a);
    g.refl     = (abs(g.mat - MAT_TERRAIN) < 0.5) ? c2.a : 0.0;
    return g;
}

// Is the pixel a water surface? (same rule as in readGBuffer)
bool isWaterPx(ivec2 q) {
    return texelFetch(colortex1, q, 0).a * 4.0 > MAT_FOLIAGE - 0.5 && texelFetch(colortex2, q, 0).a > 0.5;
}

// Geometric normal from the opaque depth buffer (view space, facing the camera).
// Used for the sea floor under water, where the G-buffer holds the water surface instead.
vec3 normalFromDepth(ivec2 p, float d) {
    vec2 inv = 1.0 / vec2(viewWidth, viewHeight);
    vec2 uvc = (vec2(p) + 0.5) * inv;
    vec3 c  = screenToView(uvc, d);
    vec3 r  = screenToView(uvc + vec2(inv.x, 0.0), depth1At(p + ivec2(1, 0)));
    vec3 l  = screenToView(uvc - vec2(inv.x, 0.0), depth1At(p - ivec2(1, 0)));
    vec3 u  = screenToView(uvc + vec2(0.0, inv.y), depth1At(p + ivec2(0, 1)));
    vec3 dn = screenToView(uvc - vec2(0.0, inv.y), depth1At(p - ivec2(0, 1)));
    // pick the neighbour with the smaller depth jump on each axis (keeps edges clean)
    vec3 dx = (abs(r.z - c.z) < abs(c.z - l.z))  ? (r - c) : (c - l);
    vec3 dy = (abs(u.z - c.z) < abs(c.z - dn.z)) ? (u - c) : (c - dn);
    vec3 n  = normalize(cross(dx, dy) + vec3(0.0, 0.0, 1e-6));
    return (n.z > 0.0) ? n : -n;
}

// ============================================================================
//  shadows: warped shadow map, normal-offset bias, vogel-disk PCF, coloured glass
// ============================================================================
// biasMul > 1 pushes the lookup further along the normal (entities: thin boxes that would
// otherwise shadow their own faces and show acne)
// taps = number of PCF samples (PCF_TAPS normally, fewer for reflected surfaces, see gCheap)
vec3 shadowVisibilityT(vec3 feetPos, vec3 nW, float NoL, float dither, bool opaqueOnly, float biasMul, int taps) {
#ifdef SHADOWS
    vec3  sv0  = (shadowModelView * vec4(feetPos, 1.0)).xyz;
    float len0 = length((shadowProjection * vec4(sv0, 1.0)).xy);

    // World-space size of one shadow texel at this spot. The warp d(x')/dx = (1-W)/f^2
    // makes texels small near the player and large far away.
    float fw     = (1.0 - SHADOW_WARP) + len0 * SHADOW_WARP;
    float texelW = (2.0 * shadowDistance / float(shadowMapResolution)) * fw * fw / (1.0 - SHADOW_WARP);

    // normal-offset bias, scaled with the local texel size, larger at grazing angles
    vec3 offFeet = feetPos + nW * texelW * (0.9 + 1.4 * (1.0 - NoL)) * biasMul;
    vec3 sv      = (shadowModelView * vec4(offFeet, 1.0)).xyz;
    vec3 ndc     = (shadowProjection * vec4(sv, 1.0)).xyz;
    ndc.xy = distortShadow(ndc.xy);          // identical to shadow.vsh
    ndc.z *= SHADOW_Z_SCALE;
    vec3 coord = ndc * 0.5 + 0.5;

    // small slope-dependent depth bias, converted from blocks to depth units
    float zBias = 0.5 * SHADOW_Z_SCALE * abs(shadowProjection[2][2]) * (0.03 + 0.10 * (1.0 - NoL)) * biasMul;
    float z      = coord.z - zBias;
    float radius = SHADOW_SOFTNESS * 1.3 / float(shadowMapResolution);
    float rot    = dither * TAU;
    vec2  dir0   = vec2(cos(rot), sin(rot));

    vec3 vis;
    {
        vec3 acc = vec3(0.0);
        vec2 dir = dir0;
        for (int i = 0; i < taps; i++) {
            vec2  suv  = coord.xy + vogelNext(dir, i, taps) * radius;
            float lit1 = step(z, textureLod(shadowtex1, suv, 0.0).r);
            vec3  tap  = vec3(lit1);
#ifdef COLORED_SHADOWS
            if (!opaqueOnly && lit1 > 0.5) {
                // not blocked by anything opaque: a translucent occluder in front filters the light by its colour
                float lit0 = step(z, textureLod(shadowtex0, suv, 0.0).r);
                if (lit0 < 0.5) tap = toLinear(textureLod(shadowcolor0, suv, 0.0).rgb);   // already the final filter (see shadow.fsh)
            }
#else
            if (!opaqueOnly) tap = vec3(step(z, textureLod(shadowtex0, suv, 0.0).r));
#endif
            acc += tap;
        }
        vis = acc / float(taps);
    }
    return mix(vis, vec3(1.0), smoothstep(0.80, 0.97, len0));   // beyond the map: assume lit
#else
    return vec3(1.0);
#endif
}

vec3 shadowVisibilityB(vec3 feetPos, vec3 nW, float NoL, float dither, bool opaqueOnly, float biasMul) {
    return shadowVisibilityT(feetPos, nW, NoL, dither, opaqueOnly, biasMul, PCF_TAPS);
}

vec3 shadowVisibility(vec3 feetPos, vec3 nW, float NoL, float dither, bool opaqueOnly) {
    return shadowVisibilityT(feetPos, nW, NoL, dither, opaqueOnly, 1.0, PCF_TAPS);
}

// Slant distance (blocks) that the light travels through water before it reaches `feet`:
// the first occluder of shadowtex0 (the water surface) against the depth of the point itself.
// Beyond the shadow map the sky light of the lightmap is used instead.
float uwLightPath(vec3 feet, vec2 lm) {
    float fallback = (isEyeInWater == 1) ? (1.0 - lm.y) * 15.0 / max(lightDirW.y, 0.35) : 6.0;
#ifdef SHADOWS
    vec3  sv  = (shadowModelView * vec4(feet, 1.0)).xyz;
    vec3  ndc = (shadowProjection * vec4(sv, 1.0)).xyz;
    float len = length(ndc.xy);
    ndc.xy = distortShadow(ndc.xy);
    ndc.z *= SHADOW_Z_SCALE;
    vec3  sc  = ndc * 0.5 + 0.5;
    float perBlock = 0.5 * SHADOW_Z_SCALE * abs(shadowProjection[2][2]);
    float path = max(sc.z - texture(shadowtex0, sc.xy).r, 0.0) / perBlock;
    return mix(path, fallback, smoothstep(0.80, 0.97, len));
#else
    return fallback;
#endif
}

// ============================================================================
//  light sources
// ============================================================================
vec3 ambientTerm(vec3 nW, vec2 lm) {
    vec3 a;
    if (hasSkylight) {
        a = skyAmbient(nW) * skyBrightness(lm.y) + vec3(0.006, 0.007, 0.011) * AMBIENT_LIGHT;
        // caves: cool floor light that does not depend on the time of day (night caves were pitch black)
        a += vec3(0.045, 0.050, 0.070) * CAVE_BRIGHTNESS * (1.0 - smoothstep(0.0, 0.45, lm.y)) * (1.0 - 0.5 * lm.x);
    } else if (hasCeiling) {
        a = vec3(0.26, 0.12, 0.08) * NETHER_AMBIENT;                                  // Nether: constant warm glow (own option)
    } else {
        a = mix(vec3(0.045, 0.028, 0.075), vec3(0.120, 0.072, 0.190),
                nW.y * 0.5 + 0.5) * AMBIENT_LIGHT;                                    // End: violet hemisphere
    }
    return a + vec3(0.30, 0.32, 0.38) * nightVision;
}

// Strength of placed light sources (was 2.4, then 2.15; a little lower so dark rooms with a few glowstone
// blocks are not too bright). The light level of the vanilla lightmap cannot tell a torch from
// glowstone, so torches get the same small reduction; the Torch Intensity slider adjusts both.
#define BLOCK_LIGHT_GAIN 2.05

// Strength of the light of a torch / lamp held in the hand (was 2.4: a bit too bright)
#define HAND_LIGHT_GAIN 1.6

// Torch colour: bright core, deeper orange towards the edge of the light radius.
vec3 blockLightColor(float lmx) {
    vec3 core = vec3(1.00, 0.72, 0.42);
    vec3 edge = vec3(1.00, 0.36, 0.11);
    vec3 warm = mix(edge, core, lmx * lmx);
    return mix(vec3(1.0, 0.85, 0.70), warm, TORCH_WARMTH);
}

#ifdef COLOR_BLEEDING
// Screen-space colour bleeding: nearby surfaces that stand "above" this surface tint its
// ambient and block light with their own colour (red wall -> reddish floor next to it).
vec3 bleedTint(vec2 uv, vec3 viewPos, vec3 nV, float dither) {
    const int N = 4 * COLOR_BLEED_QUALITY;
    // search radius: about 1.6 blocks projected onto the screen (uv units)
    float rad = clamp(1.6 * gbufferProjection[1][1] * 0.5 / max(-viewPos.z, 0.5), 0.004, 0.06);
    vec2  asp = vec2(viewHeight / viewWidth, 1.0);
    vec3  acc = vec3(0.0);
    float wsum = 0.0;
    vec2  bdir = vec2(cos(dither * TAU), sin(dither * TAU));
    for (int i = 0; i < N; i++) {
        vec2 suv = uv + vogelNext(bdir, i, N) * rad * asp;
        if (suv.x < 0.0 || suv.x > 1.0 || suv.y < 0.0 || suv.y > 1.0) continue;
        ivec2 sp = toPx(suv);
        float sd = texelFetch(depthtex1, sp, 0).r;
        if (sd >= 1.0) continue;
        vec3  dv = screenToView(suv, sd) - viewPos;
        float dl = length(dv);
        if (dl < 0.05 || dl > 2.5) continue;
        float side = saturate(dot(nV, dv / dl) * 2.0);
        float w    = side * sq(1.0 - dl / 2.5);
        acc  += texelFetch(colortex0, sp, 0).rgb * w;
        wsum += w;
    }
    if (wsum < 1e-3) return vec3(1.0);
    vec3  avg    = acc / wsum;
    vec3  chroma = clamp(avg / max(luma(avg), 0.03), 0.35, 2.2);    // colour only, no brightness change
    float amount = saturate(wsum / float(N) * 1.5) * 0.55 * COLOR_BLEED_STRENGTH;
    return mix(vec3(1.0), chroma, saturate(amount));
}
#endif

// ============================================================================
//  entity lighting helpers
// ============================================================================
#define ENTITY_WRAP        0.25   // soft light terminator (0 = hard Lambert)
#define ENTITY_SHADOW_BIAS 2.5    // shadow-map normal offset multiplier (kills self-shadow acne)
#define ENTITY_SHEEN       0.8    // strength of the light reflection on skin, fur and feathers

// Clean, broad reflection of the direct light on a mob: a soft Blinn-Phong lobe with a Fresnel
// term, so the lit side gets a gentle sheen and backlit edges a thin rim. Sun and moon both
// work because lightDirW / lightColor always hold whichever of the two is the current light.
// The result is a scale for the light colour; it is added WITHOUT the albedo (a reflection is
// the colour of the light, not of the pig).
float entitySheen(vec3 nW, vec3 viewPos, vec3 L) {
    vec3  Vw  = -viewDirToWorld(normalize(viewPos));
    vec3  H   = normalize(L + Vw);
    float NoH = saturate(dot(nW, H));
    if (NoH < 0.35) return 0.0;                         // far outside the lobe: skip the pow
    float VoH = saturate(dot(Vw, H));
    float f   = 1.0 - VoH;
    float f2  = f * f;
    float F   = min(0.07 + 0.93 * (f2 * f2 * f), 0.25);   // Schlick, capped so rims never glare
    float D   = exp2(log2(NoH) * 20.0);
    return D * F * ENTITY_SHEEN;
}

// ============================================================================
//  deferred surface lighting
// ============================================================================
vec3 shadeSurface(vec3 albedo, vec3 nV, vec2 lm, float ao, float emissive, float mat,
                  vec3 viewPos, vec2 uv, float dither, bool bleed, bool uw) {
    vec3 feet = viewToFeet(viewPos);
    vec3 nW   = viewDirToWorld(nV);
    bool foliage = abs(mat - MAT_FOLIAGE) < 0.5;
    bool ent     = abs(mat - MAT_ENTITY) < 0.5;
    int  shadeTaps = gCheap ? min(4, PCF_TAPS) : PCF_TAPS;

    // ---- ambient + block light ------------------------------------------------------
    vec3 ambient = ambientTerm(nW, lm);
    vec3 block   = blockLightColor(lm.x) * (pow(lm.x, 3.6) * BLOCK_LIGHT_GAIN * TORCH_INTENSITY);

#ifdef DYNAMIC_HAND_LIGHT
    // torch in hand: point light at the camera
    float held = float(max(heldBlockLightValue, heldBlockLightValue2));
    if (held > 0.5) {
        float dist   = length(viewPos);
        float atten  = sq(saturate(1.0 - dist / (held * 0.95 + 1.0)));
        float facing = saturate(dot(nV, -viewPos / max(dist, 1e-3)) * 0.7 + 0.3);
        block += blockLightColor(1.0) * (atten * facing * (held / 15.0) * HAND_LIGHT_GAIN * TORCH_INTENSITY);
    }
#endif

    // ---- under water: the surface lies below the water line (camera inside the water, or seen
    // through the surface). The vanilla light level is replaced by a depth model: sunlight is
    // filtered per colour channel by the water above, caustics modulate it, and the ambient
    // light fades with depth. Sunlight reaches the sea floor at any depth if nothing shades it.
    bool  uwSun    = uw && hasSkylight;
    vec3  uwDirect = vec3(0.0);
    if (uwSun) {
        float wPath  = uwLightPath(feet, lm);
        float depthV = max(wPath * saturate(lightDirW.y), (1.0 - lm.y) * 15.0);
        float open   = smoothstep(0.0, 0.25, lm.y);
        float NoLw   = saturate(dot(nW, lightDirW));
        if (NoLw > 0.0 && horizonFade > 0.0) {
            vec3  vis    = shadowVisibility(feet, nW, NoLw, dither, true);
            float cloudS = cloudShadow(feet + cameraPosition, lightDirW, false);
            vec3  tSun   = exp(-gUW.kd * (1.25 * wPath));
            float caus   = uwCausticMul(feet + cameraPosition, lightDirW, wPath, depthV);
            uwDirect = lightColor * (NoLw * horizonFade * uwSunTrans(lightDirW.y)) * tSun * (vis * (cloudS * caus));
            open = max(open, luma(vis) * cloudS);          // open water above: the floor gets fill light too
        }
        ambient  = (skyAmbient(nW) * skyBrightness(1.0) + vec3(0.006, 0.007, 0.011) * AMBIENT_LIGHT)
                 * exp(-gUW.kd * depthV) * open;
        ambient += vec3(0.30, 0.32, 0.38) * nightVision;
    }

#ifdef COLOR_BLEEDING
    if (bleed) {
        vec3 tint = bleedTint(uv, viewPos, nV, dither);
        ambient *= tint;
        block   *= mix(vec3(1.0), tint, 0.7);
    }
#endif

    // ---- direct light -----------------------------------------------------------------
    vec3 direct = vec3(0.0);
    vec3 sheen  = vec3(0.0);     // entity-only light reflection, added on top of the albedo-tinted light
    if (uwSun) {
        direct = uwDirect;
    } else if (hasSkylight) {
        float NoL  = dot(nW, lightDirW);
        float wrap = foliage ? 0.5 : (ent ? ENTITY_WRAP : 0.0);   // leaves and grass glow when backlit; mobs get a soft terminator
        float diff = saturate((NoL + wrap) / (1.0 + wrap));
        if (diff > 0.0 && horizonFade > 0.0) {
            vec3 vis = shadowVisibilityT(feet, nW, saturate(NoL), dither, false, ent ? ENTITY_SHADOW_BIAS : 1.0, shadeTaps);
            // a mob's own body must not shade its terminator zone (that is where acne shows up)
            if (ent) vis = mix(vec3(1.0), vis, smoothstep(0.0, 0.25, NoL));
            // sky-light mask hides shadow-map leaks in caves and under overhangs
            // shadows of the clouds (only where the sky is open)
            // (skipped where the sun is already blocked: the result would be multiplied by 0)
            float cloudS = (lm.y > 0.5 && !gCheap && max(vis.r, max(vis.g, vis.b)) > 0.002)
                         ? cloudShadow(feet + cameraPosition, lightDirW, false) : 1.0;
            float skyMask = smoothstep(0.5, 0.95, lm.y);
            direct = lightColor * (diff * horizonFade * skyMask) * (vis * cloudS);
            // moonlight is ~10x dimmer than sunlight, so the sheen is boosted at night to stay visible
            if (ent && NoL > 0.0) sheen = lightColor * (entitySheen(nW, viewPos, lightDirW) * mix(3.5, 1.0, dayAmount()) * horizonFade * skyMask) * (vis * cloudS);
        }
    } else if (!hasCeiling) {
        // End: light of the black hole, shadowed by the pillars and the island (shadow map)
        float NoL = dot(nW, lightDirW);
        if (NoL > 0.0 && horizonFade > 0.0) {
            vec3 vis = shadowVisibilityT(feet, nW, saturate(NoL), dither, false, ent ? ENTITY_SHADOW_BIAS : 1.0, shadeTaps);
            direct = endLightColor() * (saturate(NoL) * horizonFade) * vis;
            if (ent) sheen = endLightColor() * (entitySheen(nW, viewPos, lightDirW) * horizonFade) * vis;
        }
    }

    float aoF = mix(1.0, ao, 0.9);
    vec3 lit  = albedo * ((ambient + block) * aoF + direct * mix(1.0, ao, 0.35));
    lit += sheen;
    lit += albedo * (emissive * EMISSIVE_STRENGTH * 3.5);        // glowing blocks, lava, flames
    return lit;
}

// ============================================================================
//  atmosphere
// ============================================================================
// Atmosphere + clouds in world direction dirW (used for sky pixels and for reflections)
vec3 skyWithClouds(vec3 dirW, float dither, bool fast) {
    vec3 sky = atmosphereSky(dirW) + moonDisc(dirW);
#ifdef CLOUDS
    vec4 cl = cloudLayer(dirW, dither, fast);
    sky = sky * cl.a + cl.rgb;
#endif
    return sky;
}

vec3 skyPixel(vec3 dirW, vec3 c0, float dither, bool fast) {
    if (hasSkylight) {
        vec3  col = atmosphereSky(dirW);
        // colortex0 holds stars, sun and moon sprites on black. The vanilla sun sprite is cut out
        // and replaced by a procedural disc (no lookups, so it behaves at the screen edges too)
        float cs = dot(dirW, sunDirWorld());
        float cm = dot(dirW, moonDirWorld());
        vec3 sprite = (cs > 0.97 || cm > 0.985) ? vec3(0.0) : c0;   // sun and moon sprites are replaced
        vec3 sky = col + sprite + sunDisc(dirW) + moonDisc(dirW);
#ifdef CLOUDS
        // clouds in front of the whole sky: they dim the sun disc and the blue behind them
        vec4 cl = cloudLayer(dirW, dither, fast);
        sky = sky * cl.a + cl.rgb;
#endif
        return sky;
    }
    if (hasCeiling) return toLinear(fogColor);
#ifdef DIM_END
    // End: the whole sky is rebuilt HERE for every pixel without geometry. The vanilla fog of the
    // Ender Dragon fight covers the sky box, but it cannot cover what is drawn after it; and since
    // this runs before the final pass, bloom picks up the black hole glow.
    return endSky(dirW);
#else
    return c0;
#endif
}

vec3 applyFog(vec3 col, vec3 viewPos) {
    float dist = length(viewPos);
    vec3  dirW = viewDirToWorld(viewPos / max(dist, 1e-4));
    if (hasSkylight) {
        float T = exp(-fogOpticalDepth(dirW, dist));
        T *= 1.0 - smoothstep(0.92 * far, 1.0 * far, dist) * saturate(FOG_DENSITY);   // thin haze only at the very edge of the render distance (0 = off)
        return mix(fogColorAt(dirW), col, T);
    }
    if (hasCeiling) {                                          // Nether: thick warm haze
        float T = exp(-dist * 0.011 * FOG_DENSITY);
        return mix(toLinear(fogColor) * 1.4, col, T);
    }
    return col;                                                // End: clear void
}

// ============================================================================
//  lit opaque surface at a screen position (depthtex1).
//  Used for the sea floor behind water and for SSR hits.
// ============================================================================
vec3 shadeOpaque(vec2 uv, float dither, out vec3 viewPos) {
    ivec2 p = toPx(uv);
    float d = texelFetch(depthtex1, p, 0).r;
    viewPos = screenToView(uv, d);
    vec3 dirW = viewDirToWorld(normalize(viewPos));
    if (d >= 1.0) return skyPixel(dirW, texelFetch(colortex0, p, 0).rgb, dither, true);

    GData g = readGBuffer(p);
    bool uwFloor = false;
    if (isWaterMat(g.mat)) {
        // The G-buffer holds the water surface here; approximate the sea floor:
        // normal from depth, water's light levels (absorption handles the darkening).
        g.nView    = normalFromDepth(p, d);
        g.ao       = 1.0;
        g.emissive = 0.0;
        g.mat      = MAT_TERRAIN;
        // the water cell's sky light dips next to the shore and under ledges; the depth model below handles
        // all darkening with depth, so open water counts as fully open (no extra darkening towards the shore)
        g.lm.y     = mix(g.lm.y, 1.0, smoothstep(0.4, 0.8, g.lm.y));
        // seen from outside, what lies behind water is below the water line (caustics, depth
        // model); seen from inside it is the world above the surface
        uwFloor = (isEyeInWater == 0);
        if (uwFloor) gUW = uwMediumFromTint(g.tint, vec3(1.0));
    }
    vec3 c = shadeSurface(g.albedo, g.nView, g.lm, g.ao, g.emissive, g.mat, viewPos, uv, dither, false, uwFloor);
    return applyFog(c, viewPos);
}

// ============================================================================
//  glass layer helpers
// ============================================================================
vec2 unpackLm(float v) { return vec2(floor(v / 16.0 + 0.001), mod(v + 0.001, 16.0)) / 15.0; }

// glass colour / opacity of a pixel, from the premultiplied layer (rgb = colour, a = opacity)
vec4 glassAt(ivec2 q) {
    vec4 c = texelFetch(colortex3, q, 0);
    return vec4(c.rgb / max(c.a, 1e-4), c.a);
}

// the world `behind` seen through one glass layer: filtered by the glass colour, light glass gets a milky
// veil, and the pane's own lit colour `lit` adds a little sheen
vec3 throughGlass(vec3 behind, vec4 glass, vec3 lit) {
    float veil = glass.a * 0.45 * smoothstep(0.08, 0.45, luma(glass.rgb));   // white / yellow / light grey
    return behind * glassFilter(glass.rgb, glass.a, 1.0) * (1.0 - veil) + lit * (veil + glass.a * 0.22);
}

// a glass pane (portal, ice ...) that lies BEHIND a water surface: laid over what the water shows
vec3 glassBehindWater(vec3 col, ivec2 q, vec2 uvq, vec3 vpWater, float dither) {
    vec4 gl = glassAt(q);
    if (gl.a <= 0.002) return col;
    vec4 gn  = texelFetch(colortex4, q, 0);
    vec3 lit = shadeSurface(gl.rgb, octDecode(gn.rg), unpackLm(gn.b), 1.0, 0.0, MAT_TERRAIN, vpWater, uvq, dither, false, false);
    return throughGlass(col, gl, lit);
}

// ============================================================================
//  screen-space reflections (view-space march, binary refinement)
//  returns vec4(colour, confidence)
// ============================================================================
// nSteps: ray steps (SSR_STEPS for water and puddles, BLOCK_REFL_STEPS for block reflections)
vec4 ssrMarch(vec3 viewPos, vec3 dirV, float dither, int nSteps) {
    // rays heading back at the camera cannot be answered from the depth buffer
    if (dirV.z > 0.05) return vec4(0.0);

    // distance LOD: far water gets half the steps (same reach, coarser steps)
    int   steps   = (length(viewPos) > 96.0) ? max(nSteps / 2, 6) : nSteps;
    float stepLen = 0.30;
    float grow    = 1.0 + 3.2 / float(steps);            // geometric growth: far reach with few steps
    vec3  pos     = viewPos + dirV * (stepLen * dither); // jitter hides banding
    vec3  prev    = pos;

    for (int i = 0; i < 96; i++) {                       // 96 = largest step count offered in the menu
        if (i >= steps) break;
        prev = pos;
        pos += dirV * stepLen;
        float thickness = stepLen * 1.2 + 0.25;
        stepLen *= grow;

        if (pos.z > -near) break;                        // crossed the camera plane
        vec3 sp = viewToScreen(pos);
        if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0) break;

        float sd = fetchDepth1(sp.xy);
        if (sd >= 1.0) continue;                         // sky: nothing to hit yet
        float sceneZ = screenToView(sp.xy, sd).z;
        float diff   = pos.z - sceneZ;                   // < 0: the ray is behind the surface
        if (diff < 0.0 && diff > -thickness) {
            vec3 lo = prev;
            vec3 hi = pos;
            for (int j = 0; j < 5; j++) {                // binary refinement of the hit
                vec3  mid = 0.5 * (lo + hi);
                vec3  ms  = viewToScreen(mid);
                float md  = fetchDepth1(ms.xy);
                float mz  = screenToView(ms.xy, md).z;
                if (mid.z < mz) hi = mid; else lo = mid;
            }
            vec3 hs = viewToScreen(hi);
            vec3 hitVP;
            gCheap = true;
            vec3 col = shadeOpaque(hs.xy, dither, hitVP);
            gCheap = false;
            float edge  = smoothstep(0.0, 0.08, min(min(hs.x, 1.0 - hs.x), min(hs.y, 1.0 - hs.y)));
            float reach = 1.0 - smoothstep(30.0, 90.0, length(hi - viewPos));
            return vec4(col, edge * reach);
        }
    }
    return vec4(0.0);
}

vec4 ssrTrace(vec3 viewPos, vec3 dirV, float dither) {
#ifdef SSR
    return ssrMarch(viewPos, dirV, dither, SSR_STEPS);
#else
    return vec4(0.0);
#endif
}

// ============================================================================
//  water
// ============================================================================
// glassBehind: a glass layer (nether portal ...) lies behind the surface and is drawn over what the water shows
vec3 shadeWater(vec2 uv, float d0, GData g, vec3 viewPos0, float dither, bool glassBehind) {
    vec3  V     = normalize(viewPos0);                  // camera -> surface, view space
    vec3  n     = g.nView;                              // wave normal, already flipped towards the viewer
    float NoV   = saturate(dot(n, -V));
    float dist  = length(viewPos0);
    vec3  feet0 = viewToFeet(viewPos0);
    vec3  wp0   = feet0 + cameraPosition;
    vec3  nW    = viewDirToWorld(n);
    vec3  tint  = toLinear(g.tint);

    // ---- refraction: waves tilt the lookup; reject targets that are not water behind the surface
    vec2 ruv = uv;
#ifdef WATER_REFRACTION
    if (isEyeInWater == 0) {
        vec3 upV  = normalize(gbufferModelView[1].xyz);
        vec2 tilt = (n - upV).xy;                       // zero for a flat surface
        vec2 cand = uv + tilt * (0.045 / (1.0 + 0.05 * dist)) * vec2(viewHeight / viewWidth, 1.0);
        if (cand.x > 0.002 && cand.x < 0.998 && cand.y > 0.002 && cand.y < 0.998) {
            ivec2 cp  = toPx(cand);
            float cd1 = texelFetch(depthtex1, cp, 0).r;
            if (cd1 > d0 && isWaterPx(cp)) ruv = cand;
        }
    }
#endif

    // ---- what lies behind the surface
    vec3  floorVP;
    vec3  floorCol = shadeOpaque(ruv, dither, floorVP);
    float fd1      = fetchDepth1(ruv);
    if (glassBehind) floorCol = glassBehindWater(floorCol, toPx(ruv), ruv, viewPos0, dither);

    // ---- camera below the surface: refracted view of the world above + total internal reflection
    if (isEyeInWater == 1) {
        vec3 above = floorCol;
#ifndef DIM_END
        // Looking up through the surface: the plain sky (no clouds, no fish-eye) seen through the
        // moving waves. The wave normal only wobbles the view direction a little, so sun, moon and
        // sky shimmer with the water and stay where they really are when you move.
        if (fd1 >= 1.0 && hasSkylight) {
            vec3 Vw   = viewDirToWorld(V);
            vec3 tilt = nW - vec3(0.0, -1.0, 0.0);              // zero for a flat surface seen from below
            vec3 Rf   = normalize(Vw + tilt * 0.5);
            above = atmosphereSky(Rf) + sunDisc(Rf) + moonDisc(Rf);
        }
#endif
        if (glassBehind) above = glassBehindWater(above, toPx(ruv), ruv, viewPos0, dither);
        return above;
    }

    float thick = (fd1 >= 1.0) ? 48.0 : min(length(floorVP - viewPos0), 48.0);

    // ---- Beer-Lambert absorption (red dies first) + in-scattered light
    vec3 sigma = (vec3(1.05) - tint) * vec3(0.45, 0.25, 0.10) / WATER_CLARITY;
    // Absorption follows the VERTICAL water depth (height of the surface above the floor), not the path
    // along the view ray: with the path length the floor turned darker and darker the farther / the flatter
    // you looked (longer path = more absorption), although the water is not any deeper there.
    // A small share of the path stays, so a flat view still looks a little more tinted.
    float vertDepth = max(feet0.y - viewToFeet(floorVP).y, 0.0);
    float thickA    = (fd1 >= 1.0) ? thick : min(vertDepth + 0.12 * max(thick - vertDepth, 0.0), 48.0);
    vec3 T     = exp(-sigma * thickA);

    vec3 lightIn = ambientTerm(vec3(0.0, 1.0, 0.0), g.lm);
    if (hasSkylight) {
        lightIn += lightColor * (horizonFade * 0.55 * saturate(lightDirW.y)) * smoothstep(0.5, 0.95, g.lm.y);
    }
    vec3 scatter   = tint * lightIn * (vec3(1.0) - T) * 0.5;
    vec3 refracted = floorCol * T + scatter;

    // ---- reflection: SSR with analytic sky fallback
    vec3 R  = reflect(V, n);
    vec3 Rw = viewDirToWorld(R);
    vec3 skyRefl;
    if (hasSkylight)      skyRefl = skyWithClouds(Rw, dither, true) * mix(0.10, 1.0, smoothstep(0.1, 0.9, g.lm.y));
    else if (hasCeiling)  skyRefl = toLinear(fogColor) * 0.5;
    else                  skyRefl = vec3(0.030, 0.018, 0.060);
    vec3 reflection = skyRefl;
#ifdef SSR
    if (Rw.y > 0.02 && dist < 256.0) {                  // never trace rays that dive into the water; far water uses the sky
        vec4 s = ssrTrace(viewPos0, R, dither);
        reflection = mix(skyRefl, s.rgb, saturate(s.a * SSR_STRENGTH));
    }
#endif
    float fr = 1.0 - NoV;
    float fr2 = fr * fr;
    float F = F0_WATER + (1.0 - F0_WATER) * (fr2 * fr2 * fr);          // Schlick (x^5 without pow)

    // ---- shore foam: thin water + moving noise
    float foam = 0.0;
#ifdef WATER_FOAM
    float shore = 1.0 - smoothstep(0.0, 0.9, thick);
    float t     = frameTimeCounter;
    // Open water deeper than 0.9 blocks (shore = 0) can never reach the foam threshold: the noise
    // alone peaks at 0.35 < 0.45. So the two 3D simplex taps are only paid for near the shore.
    if (shore > 0.0) {
        float nz1 = snoise(vec3(wp0.xz * 1.6, t * 0.35)) * 0.5 + 0.5;
        float nz2 = snoise(vec3(wp0.xz * 4.5 + 9.0, t * 0.6)) * 0.5 + 0.5;
        float lap = 0.5 + 0.5 * sin(t * 1.6 + thick * 5.0 + nz1 * 4.0);    // foam laps in and out
        foam = saturate(smoothstep(0.45, 0.80, shore * (0.55 + 0.45 * lap) + (nz1 * 0.6 + nz2 * 0.4 - 0.5) * 0.7));
    }
#if defined(WATERFALL_FLOW) && defined(WATER_WAVES)
    // whitewater streaks on steep, falling water (only evaluated on waterfalls, close range)
    float steep = 1.0 - smoothstep(0.30, 0.55, abs(nW.y));
    if (steep > 0.0 && dist < 110.0) {
        foam = max(foam, 0.55 * steep * waterfallFoam(wp0, nW, frameTimeCounter * WAVE_SPEED, dist));
    }
#endif
#endif
    vec3 foamCol = vec3(0.92, 0.96, 1.0) * (lightIn * 0.75 + 0.05);

    // ---- sun / moon glints (shadowed by opaque geometry only, so the water cannot shadow itself)
    vec3 glint = vec3(0.0);
    if (hasSkylight && horizonFade > 0.0) {
        vec3  Lv  = normalize(shadowLightPosition);
        vec3  H   = normalize(Lv - V);
        float NoH = saturate(dot(n, H));
        float NoL = saturate(dot(n, Lv));
        float spec = 0.0;
        if (NoH > 0.92) {                               // below this both lobes are < 1e-3: skip the pow work
            float lg = log2(NoH);
            spec = exp2(lg * 900.0) * 110.0 + exp2(lg * 90.0) * 0.5;
        }
        if (spec > 1e-3 && NoL > 0.0) {
            vec3 vis = shadowVisibility(feet0, nW, NoL, dither, true);
            glint = lightColor * vis * (spec * F * horizonFade * smoothstep(0.5, 0.95, g.lm.y) * cloudShadow(wp0, lightDirW, true));
        }
    }

    vec3 col = mix(refracted, reflection, F * (1.0 - foam));
    col = mix(col, foamCol, foam * 0.9);
    col += glint * (1.0 - foam);
    return col;
}

// ============================================================================
//  wet world: every block under the open sky looks wet while it rains and for a while after it,
//  plus puddles on flat ground
// ============================================================================
// How wet the world still looks, 0..1. 1 while it rains. Afterwards `wetness` (rainStrength smoothed with
// drynessHalfLife = 600 ticks = 30 s, see shaders.properties) halves every 30 s, so log2(wetness) falls
// along a straight line in time: 1 + log2(wetness) * 30 / WET_DURATION reaches exactly 0 WET_DURATION
// seconds after the rain has stopped (one minute by default) and fades out evenly until then.
float wetLook() {
    float dry = saturate(1.0 + log2(max(wetness, 1e-4)) * (30.0 / float(WET_DURATION)));
    return max(dry, rainStrength);
}

vec3 applyWetness(vec3 color, GData g, vec3 viewPos, float dither) {
    if (!hasSkylight || isEyeInWater == 1 || (wetness < 0.02 && rainStrength < 0.02)) return color;
    float look = wetLook();
    if (look < 0.01) return color;

    vec3  nW   = viewDirToWorld(g.nView);
    vec3  V    = normalize(viewPos);
    vec3  wp   = viewToFeet(viewPos) + cameraPosition;
    float terr = step(abs(g.mat - MAT_TERRAIN), 0.5);               // plain terrain only

#ifdef WET_BLOCKS
    {
        float wb = look * smoothstep(0.80, 0.97, g.lm.y) * terr;    // open to the sky = open to the rain
        if (wb > 0.01) {
            float k = min(WET_BLOCKS_STRENGTH, 1.5);
            color *= 1.0 - 0.26 * k * wb;                           // wet stone and dirt are darker

            // a thin water film: weak when looking straight at the face, mirror-like at grazing angles;
            // a slow noise makes the wetness uneven instead of a perfectly even coat
            float NoV   = saturate(dot(g.nView, -V));
            float sheen = 0.75 + 0.25 * snoise(wp * 0.45);
            float F     = saturate((0.03 + 0.32 * pow(1.0 - NoV, 4.0)) * wb * WET_BLOCKS_STRENGTH * sheen);
            if (F > 0.015) {
                vec3 R    = reflect(V, g.nView);
                vec3 Rw   = viewDirToWorld(R);
                vec3 refl = skyWithClouds(Rw, dither, true) * smoothstep(0.1, 0.9, g.lm.y);
                refl = mix(color, refl, smoothstep(-0.12, 0.12, Rw.y));   // a ray into the ground shows no sky: keep the own colour
#ifdef SSR
                if (F > 0.04) {                                     // a short march is enough for a film of water
                    vec4 s = ssrMarch(viewPos, R, dither, min(BLOCK_REFL_STEPS, 8));
                    refl = mix(refl, s.rgb, saturate(s.a * SSR_STRENGTH));
                }
#endif
                color = mix(color, refl, F);
            }
        }
    }
#endif

#ifdef PUDDLES
    {
        float up   = smoothstep(0.85, 0.97, nW.y);                  // flat, upward facing
        float sky  = smoothstep(0.88, 1.0, g.lm.y);                 // open to the rain
        float gate = up * sky * terr;
        if (gate >= 0.01) {
            float big  = snoise(vec3(wp.xz * 0.28, 1.7)) * 0.5 + 0.5;       // puddle outlines
            float fine = snoise(vec3(wp.xz * 0.95, 9.1)) * 0.5 + 0.5;
            float mask = smoothstep(0.54, 0.66, big * 0.75 + fine * 0.25) * wetness * look * gate;
            if (mask >= 0.01) {
                // raindrop ripples perturb the puddle normal
                float t   = frameTimeCounter;
                vec2  rip = vec2(snoise(vec3(wp.xz * 5.0, t * 2.5)),
                                 snoise(vec3(wp.xz * 5.0 + 17.0, t * 2.5 + 4.0)));
                vec3  nP  = normalize(nW + vec3(rip.x, 0.0, rip.y) * 0.05 * rainStrength);
                vec3  nPV = normalize(mat3(gbufferModelView) * nP);

                float NoV = saturate(dot(nPV, -V));
                float F   = max(0.06 + 0.94 * pow(1.0 - NoV, 5.0), 0.10);   // lifted so puddles read when looking down
                vec3  R   = reflect(V, nPV);
                vec3  Rw  = viewDirToWorld(R);

                vec3 refl = skyWithClouds(Rw, dither, true) * smoothstep(0.1, 0.9, g.lm.y);
#ifdef SSR
                if (Rw.y > 0.02) {
                    vec4 s = ssrTrace(viewPos, R, dither);
                    refl = mix(refl, s.rgb, saturate(s.a * SSR_STRENGTH));
                }
#endif
                color = mix(color, refl, saturate(F * mask));
            }
        }
    }
#endif
    return color;
}

// How much of the sky the mirror ray of ONE block face can really see: 0 = the ray ends on a ceiling /
// wall / roof, 1 = it leaves into the open sky. The warped shadow map is a height field seen from the
// sun (moon), so a point lying under a roof is "in shadow" and a point in the open is lit. A few points
// along the reflected ray are tested; if ANY of them lies under a roof or inside a block, the ray never
// reaches the sky. This depends on the face and its mirror direction only - not on the camera and not on
// the vanilla light level of the block (which is high next to a window or under an open top).
float skyRayVisibility(vec3 feet, vec3 nW, vec3 Rw, float dither) {
#ifdef SHADOWS
    float perBlock = 0.5 * SHADOW_Z_SCALE * abs(shadowProjection[2][2]);   // depth units per block
    vec3  p0  = feet + nW * 0.06;
    float d   = 0.55 + 0.45 * dither;                                      // jittered start (hides banding)
    float vis = 1.0;
    for (int i = 0; i < 5; i++) {
        vec3  sv  = (shadowModelView * vec4(p0 + Rw * d, 1.0)).xyz;
        vec3  ndc = (shadowProjection * vec4(sv, 1.0)).xyz;
        float len = length(ndc.xy);
        ndc.xy = distortShadow(ndc.xy);                                   // identical to shadow.vsh
        ndc.z *= SHADOW_Z_SCALE;
        vec3  sc  = ndc * 0.5 + 0.5;
        float lit = step(sc.z - perBlock * 0.35, texture(shadowtex1, sc.xy).r);
        lit = mix(lit, 1.0, smoothstep(0.80, 0.97, len));                 // beyond the map: assume open
        vis = min(vis, lit);
        d  *= 2.1;                                                         // ~0.7, 1.5, 3, 6.5, 14 blocks
    }
    return vis;
#else
    return 1.0;
#endif
}

// ============================================================================
//  block reflections: metals, gems, polished quartz, waxed copper
//  colortex2.a of terrain pixels = reflectivity written by gbuffers_terrain.fsh:
//     0          matte
//     (0, 0.5]   polished dielectric (quartz): white Fresnel, strength = a * 2
//     (0.5, 1]   metal: Fresnel tinted by the albedo, strength = (a - 0.5) * 2
//  What is mirrored, from best to cheapest:
//     1. everything on screen (SSR: torches, lava, mobs, blocks - lit exactly like the real thing)
//     2. the analytic sky with clouds where the ray leaves the screen and the block sees the sky
//     3. a soft environment term (ambient + warm block light) so torch-lit rooms still glow
//     4. sharp sun / moon highlight (shadowed, so it never leaks into caves)
// ============================================================================
vec3 applyBlockReflection(vec3 color, GData g, vec3 viewPos, float dither) {
#ifdef BLOCK_REFLECTIONS
    if (g.refl < 0.004 || isEyeInWater == 1) return color;

    float dist = length(viewPos);
    float fade = 1.0 - smoothstep(0.65 * float(BLOCK_REFL_DISTANCE), float(BLOCK_REFL_DISTANCE), dist);
    if (fade < 0.01) return color;

    bool  metal = g.refl > 0.5;
    float str   = (metal ? (g.refl - 0.5) : g.refl) * 2.0;     // 0..1
    vec3  V     = viewPos / dist;
    vec3  n     = g.nView;
    vec3  nW    = viewDirToWorld(n);
    vec3  feet  = viewToFeet(viewPos);
    float NoV   = saturate(dot(n, -V));
    vec3  R     = reflect(V, n);
    vec3  Rw    = viewDirToWorld(R);

    // ---- Fresnel (Schlick, x^5 without pow): metals reflect in their own colour
    vec3  F0    = metal ? clamp(g.albedo * 1.25 + 0.06, vec3(0.05), vec3(0.95)) : vec3(0.10);
    float fr    = 1.0 - NoV;
    float fr2   = fr * fr;
    vec3  F     = F0 + (vec3(1.0) - F0) * (fr2 * fr2 * fr);
    vec3  reflW = min(F * (str * fade * BLOCK_REFL_STRENGTH), vec3(0.92));

    // ---- environment fallback (used wherever the screen-space ray finds nothing)
    vec3 env;
    float skyMask = smoothstep(0.35, 0.95, g.lm.y);
    if (hasSkylight) {
        vec3  ground = ambientTerm(vec3(0.0, 1.0, 0.0), g.lm) * 0.55;    // what lies below the horizon, roughly
        float above  = smoothstep(-0.25, 0.02, Rw.y);
        vec3  skyEnv = vec3(0.0);
        if (above > 0.0 && skyMask > 0.01) {
            // The off-screen part of the scene would be hit by the real ray (ceiling, walls, roof), so the sky
            // may only show up if THIS face's mirror ray really reaches it. Each of the six sides of a block is
            // tested with its own reflected ray, so a closed room never mirrors clouds, even if a wall is open
            // at the top or a window lets light in.
            float eyeSky = smoothstep(0.30, 0.80, float(eyeBrightnessSmooth.y) / 240.0);
#ifdef SHADOWS
            // the shadow map is only a usable height field while the light stands above the horizon
            float rayW = smoothstep(-0.05, 0.12, lightDirW.y);
            float vis  = (rayW > 0.001) ? skyRayVisibility(feet, nW, Rw, dither) : 1.0;
            skyMask *= mix(eyeSky, vis, rayW);
#else
            skyMask *= eyeSky;
#endif
            if (skyMask > 0.01) skyEnv = skyWithClouds(Rw, dither, true) * skyMask;
        }
        env = ground * (1.0 - 0.7 * above) + skyEnv * above;
    } else if (hasCeiling) {
        env = toLinear(fogColor) * 0.5;
    } else {
        env = ambientTerm(vec3(0.0, 1.0, 0.0), g.lm) * 0.8 + vec3(0.010);
    }
    // warm light of nearby torches / lava seen in the mirror even when the lamp itself is off screen
    env += blockLightColor(g.lm.x) * (pow(g.lm.x, 3.6) * 1.1 * TORCH_INTENSITY);

    // ---- screen-space reflection (faint copper gets half the steps)
    int   steps  = (metal && str < 0.5) ? max(BLOCK_REFL_STEPS / 2, 6) : BLOCK_REFL_STEPS;
    vec3  origin = viewPos + n * (0.02 + 0.006 * dist);              // lift off the surface: no self-hits
    vec4  s      = ssrMarch(origin, R, dither, steps);
    env = mix(env, s.rgb, saturate(s.a));

    // ---- sun / moon (End: black hole) highlight: tight core plus a soft halo
    vec3 glint = vec3(0.0);
    if (horizonFade > 0.0 && !hasCeiling) {
        vec3  Lv  = normalize(mat3(gbufferModelView) * lightDirW);
        vec3  H   = normalize(Lv - V);
        float NoH = saturate(dot(n, H));
        float NoL = saturate(dot(n, Lv));
        if (NoH > 0.85 && NoL > 0.0) {
            float lg   = log2(NoH);
            float spec = exp2(lg * 220.0) * 6.0 + exp2(lg * 28.0) * 0.30;
            vec3  Lc   = hasSkylight ? lightColor * mix(3.0, 1.0, dayAmount()) : endLightColor();   // moonlight is boosted to stay visible
            float msk  = hasSkylight ? smoothstep(0.5, 0.95, g.lm.y) * cloudShadow(feet + cameraPosition, lightDirW, true) : 1.0;
            if (msk > 0.01) {
                vec3 vis = shadowVisibility(feet, nW, NoL, dither, true);
                glint = Lc * vis * (spec * horizonFade * msk);
            }
        }
    }

    // metals have no diffuse light of their own: the base colour gives way to the mirror
    float keep = metal ? 0.80 : 0.50;
    return color * (1.0 - luma(reflW) * keep) + (env + glint) * reflW;
#else
    return color;
#endif
}

// ============================================================================
//  main
// ============================================================================
void main() {
    vec2  uv = texcoord;
    ivec2 p  = ivec2(gl_FragCoord.xy);
    float d0 = texelFetch(depthtex0, p, 0).r;
    float dither = ignAnimated(gl_FragCoord.xy);

    vec3 viewPos0 = screenToView(uv, d0);
    vec3 dirW     = viewDirToWorld(normalize(viewPos0));

    bool uwEye = (isEyeInWater == 1);
    if (uwEye) gUW = uwMediumFromFog(uwCameraDepth(), uwSurfaceLight(lightColor, lightDirW.y, horizonFade));

    vec3 color;
    if (d0 >= 1.0) {
        // ---- sky
        color = skyPixel(dirW, texelFetch(colortex0, p, 0).rgb, dither, false);
        if (uwEye) color = uwFog(color, 128.0, dirW, gUW);
    } else {
        GData g = readGBuffer(p);
        vec4 glass = glassAt(p);
        vec4 wz    = texelFetch(colortex5, p, 0);
        bool water = isWaterMat(g.mat);
        // is the water surface the nearest thing here? (its distance is stored in colortex5)
        bool waterFront = water && (wz.a < 0.5 || abs(-viewPos0.z - wz.r) < 0.1 + 0.004 * wz.r);

        // Glass and plain opaque surfaces are lit by ONE shadeSurface call below (instead of two call
        // sites): the shader is inlined, so every call site costs registers and compile time.
        bool  litSurface = false;     // does a surface still have to be lit?
        bool  viaGlass   = false;     // ... and is it a glass pane in front of something?
        vec3  behind     = vec3(0.0);
        vec3  sAlb = g.albedo;  vec3 sN = g.nView;  vec2 sLm = g.lm;
        float sAo  = g.ao;      float sEm = g.emissive;  float sMat = g.mat;
        bool  sBleed = true;

        if (glass.a > 0.002 && !waterFront) {
            // ---- glass / ice / slime / portal in front: the world behind it is shaded completely (sky, sun,
            // terrain, water, shadows), then filtered by the glass colour
            vec4 gn = texelFetch(colortex4, p, 0);
            if (water && wz.a > 0.5) {
                // water behind the pane: its data is still in the G-buffer, put it back at its own distance
                vec3 r   = screenToView(uv, 0.5);
                vec3 vpW = r * (wz.r / max(-r.z, 1e-4));
                behind   = shadeWater(uv, viewToScreen(vpW).z, g, vpW, dither, false);
            } else if (texelFetch(depthtex1, p, 0).r >= 1.0) {
                // exactly the sky that is drawn next to the pane (clouds included)
                behind = skyPixel(dirW, texelFetch(colortex0, p, 0).rgb, dither, false);
            } else {
                vec3 behindVP;
                behind = shadeOpaque(uv, dither, behindVP);
            }
            sAlb = glass.rgb;  sN = octDecode(gn.rg);  sLm = unpackLm(gn.b);
            sAo = 1.0;  sEm = 0.0;  sMat = MAT_TERRAIN;  sBleed = false;
            litSurface = true;  viaGlass = true;
        } else if (water) {
            color = shadeWater(uv, d0, g, viewPos0, dither, glass.a > 0.002);
        } else {
            litSurface = true;
        }

        if (litSurface) {
            vec3 lit = shadeSurface(sAlb, sN, sLm, sAo, sEm, sMat, viewPos0, uv, dither, sBleed, uwEye);
            if (viaGlass) {
                color = throughGlass(behind, glass, lit);
            } else {
                color = applyWetness(lit, g, viewPos0, dither);
                color = applyBlockReflection(color, g, viewPos0, dither);
            }
        }
        // atmosphere between the camera and the first surface
        if (uwEye) color = uwFog(color, length(viewPos0), dirW, gUW);
        else       color = applyFog(color, viewPos0);
    }

    // sanitise: NaN or Inf would smear through bloom later
    if (any(isnan(color)) || any(isinf(color))) color = vec3(0.0);
    color = clamp(color, vec3(0.0), vec3(60000.0));
    outColor = vec4(color, 1.0);
}
