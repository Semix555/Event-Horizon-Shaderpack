#version 330 compatibility
#define DIM_END 1   // set only in shaders/world1 (End copies of the programs)

/* ============================================================================
   composite1.fsh  -  Event Horizon: volumetric light shafts (god rays)
   Marches from the camera to the first surface (or 320 blocks into the sky) through the
   height fog of lib/sky.glsl and accumulates sunlight that reaches each sample:
     - shadow map lookups  -> shafts behind trees, pillars, terrain
     - cloud shadows       -> shafts through gaps in the clouds (crepuscular rays)
   At sunrise and sunset the air is hazier, the rays are stronger and take the colour of
   the low sun (TWILIGHT_RAYS). Runs only if SHADOWS is on (see shaders.properties);
   VL_INTENSITY = 0 switches the shafts off.

   Camera below the water surface: underwaterRays() draws the sun shafts of the water.
   Few samples (UW_RAY_STEPS) with per-pixel jitter; every sample asks the shadow map two
   things: is it behind terrain (shadowtex1) and how much water is above it along the light
   (shadowtex0 vs the sample depth). The water filters the light per colour channel, and the
   caustic pattern of the wavy surface modulates the beams. UW_RAY_STRENGTH = 0.25 .. 3.
   ============================================================================ */

#include "/lib/settings.glsl"
#include "/lib/buffers.glsl"
#include "/lib/common.glsl"
#include "/lib/distort.glsl"
#include "/lib/sky.glsl"
#include "/lib/clouds.glsl"
#include "/lib/underwater.glsl"

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform sampler2D shadowtex0;     // all occluders (water surface, glass, terrain)
uniform sampler2D shadowtex1;     // opaque occluders only

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

// Henyey-Greenstein phase function: g > 0 favours forward scattering (towards the sun)
float hgPhase(float c, float g) {
    float g2 = g * g;
    return (1.0 - g2) / (4.0 * PI * pow(max(1.0 + g2 - 2.0 * g * c, 1e-3), 1.5));
}

#ifdef UW_GODRAYS
// Sun shafts seen from inside the water. Returns the light that is scattered into the camera.
vec3 underwaterRays(vec2 uv, ivec2 p, vec3 lightDir, float dither) {
    if (!hasSkylight) return vec3(0.0);
    float hf = smoothstep(0.02, 0.14, lightDir.y);        // sun or moon above the horizon
    if (hf <= 0.0) return vec3(0.0);

    float d0      = texelFetch(depthtex0, p, 0).r;
    vec3  feetEnd = viewToFeet(screenToView(uv, d0));
    float dist    = length(feetEnd);
    vec3  dir     = feetEnd / max(dist, 1e-4);
    float maxDist = min(dist, UW_RAY_RANGE);

    float camDepth = uwCameraDepth();
    UWMedium m     = uwMediumFromFog(camDepth, vec3(1.0));     // only the absorption is needed here
    vec3  kdS      = m.kd * 1.25;                              // sunbeams fade a bit faster than diffuse light
    vec3  extV     = m.sigmaA + vec3(1.8 / m.visDist);         // view path: absorption + scattering

    float perBlock = 0.5 * SHADOW_Z_SCALE * abs(shadowProjection[2][2]);   // shadow depth units per block
    float zBias    = 0.5 * perBlock;

    // the shadow-space position is affine in the ray length: one matrix product per pixel instead of two per step
    mat4 SM   = shadowProjection * shadowModelView;
    vec3 ndc0 = SM[3].xyz;
    vec3 ndcD = mat3(SM) * dir;

    vec3 acc = vec3(0.0);
    for (int i = 0; i < UW_RAY_STEPS; i++) {
        float fa = float(i)     / float(UW_RAY_STEPS);
        float fb = float(i + 1) / float(UW_RAY_STEPS);
        float a  = fa * sqrt(fa) * maxDist;                    // x^1.5 without pow
        float b  = fb * sqrt(fb) * maxDist;
        float t  = mix(a, b, dither);                          // jitter hides the banding
        float dl = b - a;
        vec3 feet = dir * t;

        // same warp as shadow.vsh
        vec3  ndc = ndc0 + ndcD * t;
        float len = length(ndc.xy);
        ndc.xy = distortShadow(ndc.xy);
        ndc.z *= SHADOW_Z_SCALE;
        vec3  sc  = ndc * 0.5 + 0.5;

        float z0   = texture(shadowtex0, sc.xy).r;            // first occluder: the water surface
        float z1   = texture(shadowtex1, sc.xy).r;            // first opaque occluder
        float lit  = step(sc.z - zBias, z1) * step(z0, sc.z); // not behind terrain, and below the surface
        float path = max(sc.z - z0, 0.0) / perBlock;          // blocks of water above, along the light

        // beyond the shadow map: assume lit, water depth from the camera depth
        float edge = smoothstep(0.80, 0.97, len);
        float fbPath = max(camDepth - feet.y, 0.0) / max(lightDir.y, 0.35);
        path = mix(path, fbPath, edge);
        lit  = mix(lit, 1.0, edge);

        if (lit > 0.0) {                                       // shadowed samples add nothing: skip the pattern
            vec3 w = exp(-kdS * path - extV * t);
            vec2 s = (feet.xz + cameraPosition.xz) + lightDir.xz * path;   // where the ray crossed the surface
            acc += w * (lit * uwRayMod(s, path) * dl);
        }
    }

    float phase = uwPhase(dot(dir, lightDir));
    float night = 1.0 + 2.0 * (1.0 - dayAmount());                 // moon shafts need a boost to be seen
    vec3  rad   = directLightColor() * (hf * uwSunTrans(lightDir.y) * night * UW_RAY_STRENGTH * 0.035);
    vec3  rays  = rad * acc * phase;
    return any(isnan(rays)) ? vec3(0.0) : rays;
}
#endif

void main() {
    ivec2 p     = ivec2(gl_FragCoord.xy);
    vec2  uv    = gl_FragCoord.xy / vec2(viewWidth, viewHeight);
    vec3  color = texelFetch(colortex0, p, 0).rgb;

#ifdef SHADOWS
    vec3  lightDir = lightDirWorld();
    // the shafts stay alive down to about 3 degrees: that is where sunset rays are longest
    float fade     = smoothstep(0.0, 0.05, lightDir.y);

    if (isEyeInWater == 1) {
#ifdef UW_GODRAYS
        color += underwaterRays(uv, p, lightDir, ignAnimated(gl_FragCoord.xy));
#endif
    } else if (hasSkylight && fade > 0.0 && VL_INTENSITY > 0.0) {   // intensity 0 = off
        float d0      = texelFetch(depthtex0, p, 0).r;
        vec3  feetEnd = viewToFeet(screenToView(uv, d0));
        float dist    = length(feetEnd);
        vec3  dir     = feetEnd / max(dist, 1e-4);
        float maxDist = min(dist, 320.0);
        float dither  = ignAnimated(gl_FragCoord.xy);
        float tw      = twilightAmount();

        // depth bias of about 1.5 blocks, converted to shadow-map depth units
        float zBias = 0.75 * SHADOW_Z_SCALE * abs(shadowProjection[2][2]);

        // the shadow-space position is affine in the ray length: one matrix product per pixel instead of two per step
        mat4 SM   = shadowProjection * shadowModelView;
        vec3 ndc0 = SM[3].xyz;
        vec3 ndcD = mat3(SM) * dir;

        float aPrev  = 0.0;  // start of the current step = end of the previous one (one pow per step)
        float cloudS = 1.0;  // last evaluated cloud shadow
        float acc = 0.0;     // in-scattered light, not yet multiplied by colour and phase
        float T   = 1.0;     // transmittance from the camera to the current sample

        for (int i = 0; i < VL_STEPS; i++) {
            // sample spacing grows with distance (fine near the camera, coarse far away)
            float a  = aPrev;
            float b  = pow(float(i + 1) / float(VL_STEPS), 1.6) * maxDist;
            float t  = mix(a, b, dither);                      // jitter hides the banding
            float dl = b - a;
            vec3 feet = dir * t;

            // same warp as shadow.vsh
            vec3  ndc = ndc0 + ndcD * t;
            float len = length(ndc.xy);
            ndc.xy = distortShadow(ndc.xy);
            ndc.z *= SHADOW_Z_SCALE;
            vec3  sc  = ndc * 0.5 + 0.5;

            float vis = step(sc.z - zBias, texture(shadowtex1, sc.xy).r);
            vis = mix(vis, 1.0, smoothstep(0.80, 0.97, len));  // beyond the map: assume lit

            // clouds block the light too: this is what draws the light shafts through cloud gaps
            // (evaluated on every second sample only: cloud shadows change slowly along the ray)
            if ((i & 1) == 0) cloudS = cloudShadow(feet + cameraPosition, lightDir, true);
            vis *= cloudS;

            // sunset air is hazier, which makes the low rays visible
            float dens = fogDensityAt(feet.y + cameraPosition.y) * (1.0 + 1.6 * tw);
            acc += T * dens * dl * vis;
            T   *= exp(-dens * dl);
            aPrev = b;
        }

        float cosT  = dot(dir, lightDir);
        float phase = 0.05 + hgPhase(cosT, 0.72);              // glow towards the sun + faint haze

        float twBoost = 1.0 + TWILIGHT_RAYS * 2.2 * tw;         // colourful, strong rays at sunrise / sunset
        float nightBoost = 1.0 + 2.0 * (1.0 - dayAmount());     // clearly visible grey shafts in the moonlight
        vec3 vl = directLightColor() * (acc * phase * VL_INTENSITY * 2.2 * fade * twBoost * nightBoost);
        color += vl;
    }
#endif

    outColor = vec4(color, 1.0);
}
