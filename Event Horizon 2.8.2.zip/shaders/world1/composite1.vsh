#version 330 compatibility
#define DIM_END 1   // set only in shaders/world1 (End copies of the programs)

void main() {
    gl_Position = ftransform();
}
