#version 330 compatibility
#define DIM_END 1   // set only in shaders/world1 (End copies of the programs)

/* ============================================================================
   composite2.fsh  -  Event Horizon: depth of field (option DEPTH_OF_FIELD)
   Auto focus: the distance under the crosshair (centerDepthSmooth, already smoothed over time)
   stays sharp, everything much nearer or farther is blurred like in a camera.
   Gather blur with a golden-angle disk (DOF_QUALITY samples). A sample only contributes if its
   own blur radius reaches the pixel, so sharp objects do not bleed into blurred backgrounds.
   Runs on the HDR scene before bloom, so bright lights turn into soft bokeh.
   The pass is skipped completely while the option is off (shaders.properties).
   ============================================================================ */

#include "/lib/settings.glsl"
#include "/lib/buffers.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform float centerDepthSmooth;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

const float DOF_MAX_RADIUS = 0.0125;   // largest blur radius at strength 1.0, in screen heights (about 13 px at 1080p)
const float DOF_MIN_FOCUS  = 4.0;      // focus distance limits (blocks): looking at a block right in front of you
const float DOF_MAX_FOCUS  = 96.0;     // must not blur the whole world, and neither must looking at the horizon
const float DOF_APERTURE   = 2.0;      // bigger = shallower depth of field (smaller sharp zone)
const float DOF_TOLERANCE  = 0.15;     // everything closer than this to the focus plane stays completely sharp

// Blur amount 0..1 of a pixel with depth buffer value d, for a focus distance in blocks.
// Thin-lens style: the blur follows the difference of 1/distance, so the sharp zone grows with distance.
float cocAt(float d, float focus) {
    if (d < 0.56) return 0.0;                                   // first-person hand stays sharp
    bool  sky = d >= 1.0;
    float inv = sky ? 0.0 : 1.0 / max(linearDepth(d), 0.05);
    float c   = smoothstep(DOF_TOLERANCE, 1.0, abs(inv - 1.0 / focus) * DOF_APERTURE);
    return sky ? c * 0.35 : c;                                  // sky (stars, black hole) only blurs a little
}

void main() {
#ifdef DEPTH_OF_FIELD
    ivec2 p    = ivec2(gl_FragCoord.xy);
    vec2  size = vec2(viewWidth, viewHeight);
    vec2  px   = 1.0 / size;
    vec2  uv   = gl_FragCoord.xy * px;
    ivec2 pmax = ivec2(size) - 1;

    vec3  center = texelFetch(colortex0, p, 0).rgb;
    // auto focus on whatever is under the crosshair (no value yet / sky: focus far away)
    float focus  = (centerDepthSmooth <= 0.0 || centerDepthSmooth >= 1.0)
                 ? DOF_MAX_FOCUS
                 : clamp(linearDepth(centerDepthSmooth), DOF_MIN_FOCUS, DOF_MAX_FOCUS);
    float maxPx  = DOF_MAX_RADIUS * DOF_STRENGTH * viewHeight;

    float R = cocAt(texelFetch(depthtex0, p, 0).r, focus) * maxPx;   // blur radius of this pixel, in pixels
    if (R < 0.75) {                                                   // in focus: nothing to do
        outColor = vec4(center, 1.0);
        return;
    }

    float rot  = ign(gl_FragCoord.xy) * TAU;                          // rotating the pattern per pixel hides banding
    vec3  acc  = center;
    float wsum = 1.0;
    for (int i = 0; i < DOF_QUALITY; i++) {
        vec2  o   = vogelDisk(i, DOF_QUALITY, rot) * R;
        vec2  suv = uv + o * px;
        ivec2 sp  = clamp(ivec2(suv * size), ivec2(0), pmax);
        float sR  = cocAt(texelFetch(depthtex0, sp, 0).r, focus) * maxPx;
        float w   = saturate(sR - length(o) + 1.0);                   // does the sample's own blur reach this pixel?
        acc  += texture(colortex0, suv).rgb * w;
        wsum += w;
    }
    outColor = vec4(acc / wsum, 1.0);
#else
    outColor = texelFetch(colortex0, ivec2(gl_FragCoord.xy), 0);
#endif
}
