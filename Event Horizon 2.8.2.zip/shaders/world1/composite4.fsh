#version 330 compatibility
#define DIM_END 1   // set only in shaders/world1 (End copies of the programs)

/* ============================================================================
   composite4.fsh  -  Event Horizon: raindrops on the camera lens (option LENS_RAIN_DROPS)
   Drops sit on the lens (screen space), not in the world. Each one refracts the picture behind
   it: inverted, a little fish-eyed, with a dark rim and a small highlight.

   Wetness: lensRain (custom uniform in shaders.properties) = rainStrength smoothed over time,
   it rises while it rains and falls slowly afterwards. Every grid cell carries a random threshold:
   a drop exists once the wetness exceeds it. So drops arrive one after another while the lens gets
   wet and vanish one after another while it dries - never all at once, and never too many.
   On top of that every drop has a life cycle: it appears, slides slowly down and dries away; then
   a new drop (new place, new size) can start in the same cell.
   No drops indoors (sky light), under water, or in dimensions without sky.
   The pass is skipped completely while the option is off (shaders.properties).
   ============================================================================ */

#include "/lib/settings.glsl"
#include "/lib/buffers.glsl"
#include "/lib/common.glsl"

uniform sampler2D colortex0;
uniform float lensRain;          // 0 = dry lens, 1 = soaked (smoothed rainStrength)

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

vec2 hash22(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.xx + p3.yz) * p3.zy);
}

struct Drop {
    vec2  off;     // refraction offset in screen-height units
    float mask;    // 0 = no drop here, 1 = inside the drop
    float rim;     // dark edge of the drop
    float spec;    // highlight
};

// One grid layer of drops. p = screen position in screen heights (x already multiplied by the aspect ratio).
// share = fraction of the grid cells that carry a drop right now (0..1).
Drop dropLayer(vec2 p, float scale, float share, vec2 seed) {
    Drop D = Drop(vec2(0.0), 0.0, 0.0, 0.0);

    vec2 g  = p * scale;
    vec2 id = floor(g);
    vec2 f  = fract(g) - 0.5;                           // position inside the cell, -0.5 .. 0.5

    vec2  hA   = hash22(id + seed);                     // x: wetness threshold of this cell, y: life-cycle offset
    float grow = saturate((share - hA.x) * 6.0);        // 0 -> 1: the drop swells in while the wetness passes its threshold
    if (grow <= 0.0) return D;

    float period = 40.0 + 40.0 * hash22(id * 1.37 + seed + 17.0).x;   // seconds per life cycle
    float t      = frameTimeCounter / period + hA.y;
    float ph     = fract(t);
    float cyc    = floor(t);
    float life   = smoothstep(0.0, 0.10, ph) * (1.0 - smoothstep(0.82, 1.0, ph));
    float a      = grow * life;
    if (a <= 0.0) return D;

    vec2 hC = hash22(id + seed + cyc * 3.71 + 5.0);           // new place and size for every new drop
    vec2 hD = hash22(id * 0.73 + seed + cyc * 1.91 + 11.0);

    float r = (0.13 + 0.12 * hD.x) * (0.45 + 0.55 * a);       // radius in cell units, stays inside the cell
    vec2  c = vec2((hC.x - 0.5) * 0.36,
                   0.12 + (hC.y - 0.5) * 0.10 - 0.26 * ph * ph);   // slowly slides down during its life

    vec2  qv = f - c;
    vec2  q  = vec2(qv.x, qv.y * 0.82);                       // a little taller than wide
    float dist = length(q) / r;                               // 0 = centre, 1 = edge
    if (dist >= 1.0) return D;

    D.mask = (1.0 - smoothstep(0.88, 1.0, dist)) * saturate(a * 3.0);
    // a drop is a tiny lens: the picture inside is flipped and squeezed together towards the edge
    D.off  = -qv * mix(1.5, 2.6, dist * dist) / scale;
    D.rim  = smoothstep(0.60, 0.95, dist);
    D.spec = 1.0 - smoothstep(0.0, 0.28, length(q / r - vec2(-0.35, 0.40)));
    return D;
}

void main() {
#ifdef LENS_RAIN_DROPS
    ivec2 p     = ivec2(gl_FragCoord.xy);
    vec3  scene = texelFetch(colortex0, p, 0).rgb;
    outColor = vec4(scene, 1.0);

    if (!hasSkylight || isEyeInWater != 0) return;
    // under a roof or in a cave the lens is not rained on (sky light is smoothed by the game)
    float wet = lensRain * smoothstep(0.35, 0.85, float(eyeBrightnessSmooth.y) / 240.0);
    if (wet < 0.002) return;

    vec2 aspect = vec2(viewWidth / viewHeight, 1.0);
    vec2 uv     = gl_FragCoord.xy / vec2(viewWidth, viewHeight);
    vec2 pp     = uv * aspect;

    // big drops (few) and small drops (a few more); RAIN_DROP_SIZE scales the grid, RAIN_DROP_AMOUNT the share of filled cells
    Drop d1 = dropLayer(pp,  5.0 / RAIN_DROP_SIZE, wet * 0.22 * RAIN_DROP_AMOUNT, vec2(0.0));
    Drop d2 = dropLayer(pp, 12.0 / RAIN_DROP_SIZE, wet * 0.12 * RAIN_DROP_AMOUNT, vec2(37.0, 11.0));
    Drop D  = d1;
    if (d2.mask > d1.mask) D = d2;
    if (D.mask <= 0.0) return;

    vec2 off = D.off / aspect;                          // screen-height units -> uv
    vec3 refr;                                          // slight colour split, strongest at the drop edge
    refr.r = texture(colortex0, uv + off * 1.04).r;
    refr.g = texture(colortex0, uv + off       ).g;
    refr.b = texture(colortex0, uv + off * 0.96).b;
    refr *= 1.0 - 0.30 * D.rim;
    refr += (0.02 + 0.10 * luma(refr)) * D.spec;

    outColor = vec4(mix(scene, refr, D.mask), 1.0);
#else
    outColor = texelFetch(colortex0, ivec2(gl_FragCoord.xy), 0);
#endif
}
