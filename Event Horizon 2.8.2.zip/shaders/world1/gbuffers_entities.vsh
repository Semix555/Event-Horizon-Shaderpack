#version 330 compatibility
#define DIM_END 1   // set only in shaders/world1 (End copies of the programs)

/* ============================================================================
   gbuffers_entities.vsh  -  Event Horizon
   Used for: every mob, player, armor stand, item entity, boat, minecart ...

   Before this file existed, entities fell back to gbuffers_textured (the particle
   program): no hit flash, and every face carried a fixed "up" normal, so a pig was lit
   like a flat sheet and its own body threw acne into the shadow map.

   Outputs to gbuffers_entities.fsh:
     texcoord  entity texture UV
     lmcoord   vanilla lightmap remapped to 0..1  (x = block light, y = sky light)
     glcolor   vertex colour (dyed leather, sheep wool, ...)
     normal    REAL view-space face normal (falls back to "up" if the model has none)
     viewPosV  view-space position, used in the fsh to flip back faces
   ============================================================================ */

uniform mat4 gbufferModelView;

out vec2 texcoord;
out vec2 lmcoord;
out vec4 glcolor;
out vec3 normal;
out vec3 viewPosV;

void main() {
    gl_Position = ftransform();

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

    // Vanilla lightmap UVs span [1/32, 31/32]. Remap so 0.0 = light level 0, 1.0 = level 15.
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    lmcoord = clamp((lmcoord - 0.03125) * 1.0666667, 0.0, 1.0);

    glcolor  = gl_Color;
    viewPosV = (gl_ModelViewMatrix * gl_Vertex).xyz;

    vec3 n = gl_NormalMatrix * gl_Normal;
    // Some entity geometry (name tags, flat sprites) has no usable normal: use world "up"
    // (gbufferModelView[1].xyz == view-space up) instead of normalizing a zero vector.
    normal = (dot(n, n) > 1e-4) ? normalize(n) : normalize(gbufferModelView[1].xyz);
}
