#version 330 compatibility
#define DIM_END 1   // set only in shaders/world1 (End copies of the programs)

/* ============================================================================
   gbuffers_water.vsh  -  Event Horizon
   Translucent terrain layer: water (id 10020) plus glass, ice, slime ...

   Clean wave normals: the vertex shader only displaces surface vertices with the
   low-frequency Gerstner swell and passes the UNDISTORTED geometric normal plus the
   rest position. The fragment shader rebuilds the analytic normal from the same
   wave functions per pixel, so normals always match the motion.

   block.properties needs:   block.10020 = water
   shaders.properties needs: separateAo = true
   ============================================================================ */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/waves.glsl"

#ifndef ID_WATER
#define ID_WATER 10020
#endif

in vec4 mc_Entity;   // x = block id

out vec2 texcoord;
out vec2 lmcoord;
out vec4 glcolor;
out vec3 normal;     // view-space geometric normal (not displaced)
out vec3 worldPos;   // rest position in world space, input for the pixel waves
out float vertDist;  // distance to camera, used for the wave level of detail
out vec3 vViewPos;   // view-space position (back-face test in the fragment shader)
flat out int blockId;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

    // Vanilla lightmap UVs span [1/32, 31/32]; remap to 0..1.
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    lmcoord = clamp((lmcoord - 0.03125) * 1.0666667, 0.0, 1.0);

    glcolor = gl_Color;
    blockId = int(mc_Entity.x + 0.5);
    normal  = normalize(gl_NormalMatrix * gl_Normal);

    vec3 feetPos = viewToFeet((gl_ModelViewMatrix * gl_Vertex).xyz);
    worldPos = feetPos + cameraPosition;
    vertDist = length(feetPos);

#ifdef WATER_WAVES
    if (blockId == ID_WATER && vertDist < 192.0) {
        // Surface vertices sit at fractional heights (source water = 8/9 etc.).
        // Vertices at integer heights are water-on-water joints or the sea floor and stay put.
        // Displacement depends only on world position, so neighbouring faces stay watertight
        // (waterfall sides and sloped flow share their vertices with the surface).
        float yf = fract(worldPos.y);
        if (yf > 0.02 && yf < 0.98) {
            float h = waveHeightVS(worldPos.xz, frameTimeCounter * WAVE_SPEED);
            feetPos.y += h * 0.35 * (1.0 - smoothstep(120.0, 192.0, vertDist));   // keep it small: the shore must not clip
        }
    }
#endif

    vec4 viewPos4 = gbufferModelView * vec4(feetPos, 1.0);
    vViewPos      = viewPos4.xyz;
    gl_Position   = gl_ProjectionMatrix * viewPos4;
}
