#version 330 compatibility
#define DIM_END 1   // set only in shaders/world1 (End copies of the programs)

/* ============================================================================
   gbuffers_skybasic.fsh  -  Event Horizon (Overworld sky pass)

   Vanilla draws the sky dome, void plane, sunrise fan and stars through this program.
   The pack renders the atmosphere analytically in the composite pass (lib/sky.glsl,
   for every pixel with depth == 1.0), so only the stars are kept here.

   Writes colortex0 only. Sky pixels are recognised later by depth == 1.0.
   ============================================================================ */

uniform int renderStage;

in vec2 texcoord;
in vec4 glcolor;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

void main() {
#ifdef MC_RENDER_STAGE_STARS
    if (renderStage == MC_RENDER_STAGE_STARS) {
        // glcolor already carries vanilla's star brightness (time of day and rain)
        outColor = vec4(glcolor.rgb * glcolor.a * 3.0, 1.0);
        return;
    }
#endif
    discard;   // dome, void and sunrise fan are replaced by the analytic sky
}
