#version 330 compatibility
#define DIM_END 1   // set only in shaders/world1 (End copies of the programs)

/* ============================================================================
   gbuffers_skybasic.vsh  -  Event Horizon
   Pass-through vertex shader for the sky programs.
   An identical copy is used as gbuffers_skytextured.vsh (root and world1/).
   ============================================================================ */

out vec2 texcoord;
out vec4 glcolor;

void main() {
    gl_Position = ftransform();
    texcoord    = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor     = gl_Color;
}
