#version 330 compatibility
#define DIM_END 1   // set only in shaders/world1 (End copies of the programs)

/* ============================================================================
   gbuffers_skytextured.fsh  -  Event Horizon
   Vanilla draws the sun, the moon AND the End sky box through this program.

   Overworld / Nether : sun and moon sprites, written to colortex0 on black;
                        composite.fsh adds them on top of the analytic sky.
   End                : skipped, the procedural End sky with the black hole is drawn in composite.fsh.

   The End is detected at runtime (no skylight and no ceiling). There is deliberately NO
   world1/ folder: a dimension folder replaces the complete program set for that
   dimension, which removed the terrain and composite passes in the End.
   ============================================================================ */

#include "/lib/settings.glsl"
#include "/lib/buffers.glsl"
#include "/lib/common.glsl"

uniform sampler2D gtexture;

in vec2 texcoord;
in vec4 glcolor;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

void main() {
    if (!hasSkylight && !hasCeiling) {
        // End: nothing to draw here. composite.fsh builds the End sky for every pixel without
        // geometry, which keeps it visible during the Ender Dragon fight (vanilla fog) and
        // computes the black hole only once.
        outColor = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }

    // ---- sun / moon sprite
    vec4 tex = texture(gtexture, texcoord) * glcolor;
    if (tex.a < 0.01) discard;
    // linear, not premultiplied: the vanilla blend state already multiplies by alpha
    outColor = vec4(pow(tex.rgb, vec3(2.2)), tex.a);
}
