#version 330 compatibility
#define DIM_END 1   // set only in shaders/world1 (End copies of the programs)

/* ============================================================================
   gbuffers_terrain.fsh  -  Event Horizon
   Writes the G-buffer only; all lighting happens in the deferred/composite passes.

   Writes (same layout as gbuffers_textured):
     colortex0  RGB = linear albedo, A = 1
     colortex1  RG = octahedral view-space normal, B = AO, A = material id / 4
     colortex2  R = block light, G = sky light, B = emissive mask, A = block reflectivity

   Needs in shaders.properties:   separateAo = true
   ============================================================================ */

#include "/lib/settings.glsl"
#include "/lib/buffers.glsl"
#include "/lib/common.glsl"
#include "/lib/blocks.glsl"

uniform sampler2D gtexture;

in vec2 texcoord;
in vec2 lmcoord;
in vec4 glcolor;
in vec3 normal;
flat in int blockId;

/* RENDERTARGETS: 0,1,2 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outNormal;
layout(location = 2) out vec4 outLight;

void main() {
    vec4 tex = texture(gtexture, texcoord);

    // Cutout test on the TEXTURE alpha only (glcolor.a carries AO here).
    // Leaves use the vanilla 0.5 cutoff, everything else 0.1.
    float cutoff = (blockId == ID_LEAVES) ? 0.5 : 0.1;
    if (tex.a < cutoff) discard;

    // Gamma-encoded texture * tint -> linear for lighting
    vec3 albedo = toLinear(tex.rgb * glcolor.rgb);
    float ao = saturate(glcolor.a);

    // Rain: exposed surfaces darken as they get wet
    float wet = wetness * smoothstep(0.8, 1.0, lmcoord.y);
    albedo *= 1.0 - 0.30 * wet;

    // Material id (foliage gets fake subsurface scattering in the composite pass)
    float mat = MAT_TERRAIN;
    if (blockId == ID_PLANT || blockId == ID_LEAVES ||
        blockId == ID_TALL_LOWER || blockId == ID_TALL_UPPER) mat = MAT_FOLIAGE;

    // Emissive mask
    float emissive = 0.0;
    if (blockId == ID_EMISSIVE || blockId == ID_LAMP) {
        // only the bright texels glow: flame of a torch, not its stick
        float peak = max(tex.r, max(tex.g, tex.b));
        emissive = smoothstep(0.55, 0.85, peak) * 0.9;
        if (blockId == ID_LAMP) albedo *= LAMP_GLOW;   // full-block lamps: whole surface brightness (light, glow, bloom) scales with the option
    } else if (blockId == ID_HOT) {
        emissive = 1.0;   // lava, fire, magma
    }

    // ---- Nether stems: the veins glow (crimson red, warped turquoise), the bark does not
    if (blockId == ID_STEM_CRIMSON || blockId == ID_STEM_WARPED) {
        // The veins are told apart from the bark by their colour (raw texture colour, vanilla textures):
        //   crimson: veins are strongly red   (red is more than 2.5x the blue)
        //   warped:  veins are blue / green   (little red, blue clearly above red and green)
        // Only the veins glow; the bark keeps its colour and stays dark.
        float vein;
        float lvl;                                                        // brightness of the vein right now (the texture pulses)
        if (blockId == ID_STEM_CRIMSON) {
            vein = smoothstep(2.2, 2.8, tex.r / max(tex.b, 0.004));
            lvl  = tex.r;
            albedo = mix(albedo, albedo * vec3(1.0, 0.35, 0.35), vein);      // redder, more saturated veins
        } else {
            vein = max(smoothstep(-0.02, 0.03, 0.37 * tex.b - tex.r),
                       smoothstep(-0.05, 0.05, 3.4 * tex.b - (tex.r + 3.0 * tex.g)));
            lvl  = tex.g + 0.2 * tex.b;
            vein *= 0.7;                                                  // warped glows a bit less than crimson
        }
        // The vanilla texture is animated: the veins pulse between bright and dark. Let the glow follow
        // that pulse (bright phase = full glow, dark phase = much weaker) so the pulsing is easy to see.
        float norm  = clamp(lvl / 0.8, 0.0, 1.0);
        float pulse = max(mix(1.0, norm * norm, STEM_PULSE), 0.0);
        emissive = max(emissive, vein * STEM_GLOW * pulse);
    }

    // ---- block reflections: how mirror-like is this texel? (decoded in composite.fsh)
    //   0 = matte | (0, 0.5] = polished dielectric (quartz) | (0.5, 1] = metal (tinted Fresnel)
    float reflA = 0.0;
#ifdef BLOCK_REFLECTIONS
    if (blockId >= ID_REFL_METAL && blockId <= ID_REFL_OBSIDIAN) {
        float rs    = 0.0;
        bool  metal = (blockId != ID_REFL_QUARTZ && blockId != ID_REFL_OBSIDIAN);
        if (blockId == ID_REFL_METAL)       rs = 1.0;
        else if (blockId == ID_REFL_QUARTZ) rs = 0.75;
        else if (blockId == ID_REFL_OBSIDIAN) rs = 0.40;   // gentle: dark glass, not a mirror
#ifdef BLOCK_REFL_COPPER
        else                                rs = 0.35;   // waxed copper: faint on purpose
#endif
        if (rs > 0.0) {
            // fine texture detail: texels darker than their surroundings (seams, grooves) reflect less
            float lum    = dot(tex.rgb, vec3(0.299, 0.587, 0.114));
            float lumAvg = dot(textureLod(gtexture, texcoord, 2.0).rgb, vec3(0.299, 0.587, 0.114));
            float rel    = lum / max(lumAvg, 0.02);
            rs *= mix(0.45, 1.0, smoothstep(0.70, 1.00, rel));
            reflA = metal ? (0.5 + 0.5 * rs) : (0.5 * rs);
        }
    }
#endif

    outColor  = vec4(albedo, 1.0);
    outNormal = vec4(octEncode(normalize(normal)), ao, mat / 4.0);
    outLight  = vec4(lmcoord, emissive, reflA);
}
