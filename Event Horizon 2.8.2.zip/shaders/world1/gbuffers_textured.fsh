#version 330 compatibility
#define DIM_END 1   // set only in shaders/world1 (End copies of the programs)

/* ============================================================================
   gbuffers_textured.fsh  -  Event Horizon
   Used for: particles (and whatever Iris routes to the "textured" program).
   Writes the G-buffer only; all lighting happens in the deferred/composite passes.

   Writes:
     colortex0  RGB = linear albedo, A = coverage
     colortex1  RG = octahedral view-space normal, B = AO, A = material id / 4
     colortex2  R = block light, G = sky light, B = emissive flag, A = ambient floor

   Material ids:  0 = sky / none   1 = terrain   2 = water   3 = particle

   Required in shaders.properties, otherwise alpha blending corrupts the data
   buffers on semi-transparent particles:
     blend.gbuffers_textured.colortex1 = off
     blend.gbuffers_textured.colortex2 = off
   ============================================================================ */

#include "/lib/settings.glsl"
#include "/lib/buffers.glsl"
#include "/lib/common.glsl"

#define MAT_PARTICLE 3.0

uniform sampler2D gtexture;

in vec2 texcoord;
in vec2 lmcoord;   // 0..1, x = block light, y = sky light (remapped in the .vsh)
in vec4 glcolor;
in vec3 normal;    // view space

/* RENDERTARGETS: 0,1,2 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outNormal;
layout(location = 2) out vec4 outLight;

void main() {
    vec4 tex = texture(gtexture, texcoord) * glcolor;

    // Vanilla particle alpha cutoff
    if (tex.a < 0.1) discard;

    // Vanilla textures and vertex colours are gamma encoded -> linear for lighting
    vec3 albedo = toLinear(tex.rgb);

    // Full-bright particles (flames, lava sparks, ...) are submitted with lightmap
    // coordinates of 15/15. Flag them as emissive; the composite pass scales the
    // glow with EMISSIVE_STRENGTH.
    float fullbright = smoothstep(0.97, 1.0, min(lmcoord.x, lmcoord.y));

    outColor  = vec4(albedo, tex.a);
    outNormal = vec4(octEncode(normalize(normal)), 1.0, MAT_PARTICLE / 4.0);
    outLight  = vec4(lmcoord, fullbright, 0.0);
}
