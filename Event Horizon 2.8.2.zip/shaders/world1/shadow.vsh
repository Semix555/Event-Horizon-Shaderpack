#version 330 compatibility
#define DIM_END 1   // set only in shaders/world1 (End copies of the programs)

/* ============================================================================
   shadow.vsh  -  Event Horizon
   Renders occluders into the warped shadow map. Foliage wind uses exactly the same
   formulas as gbuffers_terrain.vsh, so shadows follow the swaying plants.
   The warp (distortShadow + SHADOW_Z_SCALE) must match shadowVisibility() in composite.fsh.
   ============================================================================ */

#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/distort.glsl"
#include "/lib/blocks.glsl"

uniform mat4 shadowModelViewInverse;

in vec4 mc_Entity;
in vec4 mc_midTexCoord;

out vec2 texcoord;
out vec4 glcolor;
flat out int blockId;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor  = gl_Color;
    blockId  = int(mc_Entity.x + 0.5);

    // camera-relative world position (the wind functions work in world space)
    vec3 feetPos = (shadowModelViewInverse * (gl_ModelViewMatrix * gl_Vertex)).xyz;

#ifdef WAVING_FOLIAGE
    vec2 lm = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    lm = clamp((lm - 0.03125) * 1.0666667, 0.0, 1.0);

    float top = (gl_MultiTexCoord0.y < mc_midTexCoord.y) ? 1.0 : 0.0;
    float w   = 0.0;
    float amp = 0.0;

    if (blockId == ID_PLANT) {
        w = top * mix(0.3, 1.0, smoothstep(0.3, 0.9, lm.y));  amp = 0.12;
    } else if (blockId == ID_TALL_LOWER) {
        w = 0.25 * top;                                       amp = 0.12;
    } else if (blockId == ID_TALL_UPPER) {
        w = mix(0.25, 1.0, top);                              amp = 0.12;
    } else if (blockId == ID_LEAVES) {
        w = 1.0;                                              amp = 0.035;
    }
    if (w > 0.0) feetPos.xz += windSway(feetPos + cameraPosition, amp) * w;
#endif

    vec4 pos = gl_ProjectionMatrix * (shadowModelView * vec4(feetPos, 1.0));
    pos.xy = distortShadow(pos.xy);     // ortho projection: clip == NDC
    pos.z *= SHADOW_Z_SCALE;
    gl_Position = pos;
}
